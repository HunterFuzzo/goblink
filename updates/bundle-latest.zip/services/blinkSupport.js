// Blink Support Service for valorant-bot

// Strict Access Control: Authorized ONLY for User ID 881928688424333323



const http = require('http');
const authService = require('./authService');

const fs = require('fs');

const path = require('path');



const AUTHORIZED_USER_ID = '881928688424333323';

const CHANNEL_ID = '1509528470273654813';
const STATS_CHANNEL_ID = '1563078470488297572';

const TICKETS_FILE = path.join(__dirname, '..', 'tickets.json');

const LOGS_FILE = path.join(__dirname, '..', 'logs_by_hwid.json');



// Default user HWID & Device ID

const DEFAULT_USER_HWID = 'C78D41DC-8220-5F0C-A213-BEAEC0B53DF6';

const DEFAULT_USER_DEVICE_ID = '';



function loadTickets() {

  try {

    if (fs.existsSync(TICKETS_FILE)) {

      return JSON.parse(fs.readFileSync(TICKETS_FILE, 'utf-8'));

    }

  } catch (e) {

    console.error('[BlinkSupport] Erreur chargement tickets:', e.message);

  }

  return {};

}



function saveTickets(data) {

  try {

    fs.writeFileSync(TICKETS_FILE, JSON.stringify(data, null, 2), 'utf-8');

  } catch (e) {

    console.error('[BlinkSupport] Erreur sauvegarde tickets:', e.message);

  }

}



function loadLogs() {

  try {

    if (fs.existsSync(LOGS_FILE)) {

      return JSON.parse(fs.readFileSync(LOGS_FILE, 'utf-8'));

    }

  } catch (e) {

    console.error('[BlinkSupport] Erreur chargement logs:', e.message);

  }

  return {};

}



function saveLogs(data) {

  try {

    fs.writeFileSync(LOGS_FILE, JSON.stringify(data, null, 2), 'utf-8');

  } catch (e) {

    console.error('[BlinkSupport] Erreur sauvegarde logs:', e.message);

  }

}



let discordClient = null;



function isAuthorized(userId) {

  if (!userId) return false;

  return userId === AUTHORIZED_USER_ID || (discordClient?.user?.id && userId === discordClient.user.id);

}





async function getOpenCategory(guild) {

  if (!guild) return null;

  let cat = guild.channels.cache.find(c => 

    c.type === 'GUILD_CATEGORY' && 

    ['tickets', 'open tickets', 'tickets ouverts'].includes(c.name.toLowerCase().trim())

  );

  if (!cat) {

    try {

      cat = await guild.channels.create('tickets', { type: 'GUILD_CATEGORY' });

    } catch (err) {

      console.error('[BlinkSupport] Erreur creation categorie tickets:', err.message);

    }

  }

  return cat;

}



async function getClosedCategory(guild) {

  if (!guild) return null;

  let cat = guild.channels.cache.find(c => 

    c.type === 'GUILD_CATEGORY' && 

    ['closed ticket', 'closed tickets', 'tickets fermes', 'tickets fermés'].includes(c.name.toLowerCase().trim())

  );

  if (!cat) {

    try {

      cat = await guild.channels.create('closed ticket', { type: 'GUILD_CATEGORY' });

    } catch (err) {

      console.error('[BlinkSupport] Erreur creation categorie closed ticket:', err.message);

    }

  }

  return cat;

}



async function closeTicketAndMoveChannel(ticket, guild) {

  if (!ticket) return false;

  

  ticket.status = 'resolved';

  ticket.updatedAt = new Date().toISOString();



  if (guild) {

    const closedCat = await getClosedCategory(guild);

    if (ticket.channelId) {

      try {

        const ch = guild.channels.cache.get(ticket.channelId) || await guild.channels.fetch(ticket.channelId).catch(() => null);

        if (ch && typeof ch.setParent === 'function') {

          if (closedCat) {

            await ch.setParent(closedCat.id, { lockPermissions: false });

          }

          await ch.send(`[TICKET CLOTURE] Le ticket #${ticket.ticketId} a ete cloture et deplace dans la categorie "${closedCat?.name || 'closed ticket'}".`);

        }

      } catch (err) {

        console.error('[BlinkSupport] Erreur deplacement channel closed ticket:', err.message);

      }

    }

  }



  const tickets = loadTickets();

  tickets[ticket.ticketId] = ticket;

  saveTickets(tickets);

  return true;

}



function init(client) {

  discordClient = client;
  authService.init(client);



  const server = http.createServer((req, res) => {

    // CORS headers

    res.setHeader('Access-Control-Allow-Origin', '*');

    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');

    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');



    if (req.method === 'OPTIONS') {

      res.writeHead(204);

      return res.end();

    }



    const url = new URL(req.url, 'http://localhost:4820');



        // Endpoint /auth/* : Gestion des comptes et sessions uniques
    if (url.pathname.startsWith('/auth/')) {
      return authService.handleHttpRequest(req, res, url);
    }

    // Endpoint POST /logs : Reception des logs de Blink

    if (req.method === 'POST' && url.pathname === '/logs') {

      let body = '';

      req.on('data', chunk => body += chunk);

      req.on('end', () => {

        try {

          const payload = JSON.parse(body);

          const { hwid, deviceId, entry } = payload;

          if (hwid && entry) {

            const allLogs = loadLogs();

            if (!allLogs[hwid]) allLogs[hwid] = [];

            const model = entry.model || 

              (entry.content && typeof entry.content === 'string' && (entry.content.match(/Mod[eè]le(?: effectif)?:\s*([^\n\r]+)/i)?.[1] || entry.content.match(/Effective Model:\s*([^\n\r]+)/i)?.[1])) || 

              (entry.title && entry.title.match(/\[([^\]]+)\]/)?.[1]) || 

              '';

            allLogs[hwid].push({

              time: entry.time || new Date().toLocaleTimeString(),

              tag: entry.tag || 'INFO',

              title: entry.title || '',

              content: entry.content || '',

              model: model ? model.trim() : '',

              deviceId: deviceId || ''

            });

            if (allLogs[hwid].length > 200) allLogs[hwid].shift();

            saveLogs(allLogs);

          }

          res.writeHead(200, { 'Content-Type': 'application/json' });

          res.end(JSON.stringify({ success: true }));

        } catch (e) {

          res.writeHead(400);

          res.end();

        }

      });

      return;

    }



    // Endpoint POST /ticket : Creation de ticket depuis Blink

    if (req.method === 'POST' && url.pathname === '/ticket') {

      let body = '';

      req.on('data', chunk => body += chunk);

      req.on('end', async () => {

        try {

          const payload = JSON.parse(body);

          const { ticketId, subject, category, message, deviceId, plan } = payload;



          const tickets = loadTickets();

          tickets[ticketId] = {

            ticketId,

            subject: subject || 'Sans sujet',

            category: category || 'Question',

            message: message || '',

            deviceId: deviceId || 'Inconnu',

            plan: plan || 'Free',

            status: 'open',

            reply: null,

            channelId: null,

            thread: [

              { sender: 'user', text: message || '', time: new Date().toISOString() }

            ],

            createdAt: new Date().toISOString(),

            updatedAt: new Date().toISOString()

          };



          // Creation automatique d'un salon textuel dedie sur Discord

          let createdChannel = null;

          if (discordClient) {

            try {

              const generalChannel = await discordClient.channels.fetch(CHANNEL_ID);

              const guild = generalChannel?.guild;

              if (guild) {

                const openCat = await getOpenCategory(guild);

                const devClean = (deviceId || '').replace(/[^a-zA-Z0-9]/g, '').toLowerCase().slice(0, 15);

                const tckClean = (ticketId || '').replace(/[^a-zA-Z0-9]/g, '').toLowerCase().slice(-5);

                const channelName = devClean ? `ticket-${devClean}` : `ticket-${tckClean || 'user'}`;



                createdChannel = await guild.channels.create(channelName, {

                  type: 'GUILD_TEXT',

                  parent: openCat?.id || null,

                  topic: `Ticket #${ticketId} | Device #${deviceId} | Plan: ${plan || 'Free'}`

                });



                if (createdChannel) {

                  tickets[ticketId].channelId = createdChannel.id;

                  

                  const welcomeLines = [

                    `[SUPPORT TICKET] #${ticketId}`,

                    `Sujet : ${subject}`,

                    `Categorie : ${category}`,

                    `Device ID : #${deviceId}`,

                    `Plan : ${plan || 'Free'}`,

                    `Statut : En cours (Open)`,

                    ``,

                    `Message :`,

                    `${message}`,

                    ``,

                    `Commandes :`,

                    `- Pour repondre : ecrivez votre message directement dans ce salon`,

                    `- Pour cloturer : tapez !close ou !ticket resolve`

                  ];

                  await createdChannel.send(welcomeLines.join('\n'));

                }



                if (generalChannel && (!createdChannel || generalChannel.id !== createdChannel.id)) {

                  await generalChannel.send(`[NOUVEAU TICKET] #${ticketId} (Device #${deviceId}) ouvert dans ${createdChannel ? `<#${createdChannel.id}>` : 'salon dedie'}.`);

                }

              }

            } catch (dErr) {

              console.error('[BlinkSupport] Erreur creation channel ticket Discord:', dErr.message);

            }

          }



          saveTickets(tickets);



          res.writeHead(200, { 'Content-Type': 'application/json' });

          res.end(JSON.stringify({ success: true, ticket: tickets[ticketId] }));

        } catch (err) {

          res.writeHead(400, { 'Content-Type': 'application/json' });

          res.end(JSON.stringify({ success: false, error: err.message }));

        }

      });

      return;

    }



    // Endpoint POST /ticket/reply : Reponse du client suite a un message du support

    if (req.method === 'POST' && url.pathname === '/ticket/reply') {

      let body = '';

      req.on('data', chunk => body += chunk);

      req.on('end', async () => {

        try {

          const payload = JSON.parse(body);

          const { ticketId, deviceId, message } = payload;

          if (!ticketId || !message || !message.trim()) {

            res.writeHead(400, { 'Content-Type': 'application/json' });

            return res.end(JSON.stringify({ success: false, error: 'Parametres manquants' }));

          }



          const tickets = loadTickets();

          const cleanId = String(ticketId).toUpperCase().replace('#', '');

          const foundKey = Object.keys(tickets).find(k => k.toUpperCase() === cleanId || k.toUpperCase() === 'TCK-' + cleanId);

          if (!foundKey) {

            res.writeHead(404, { 'Content-Type': 'application/json' });

            return res.end(JSON.stringify({ success: false, error: 'Ticket introuvable' }));

          }



          const ticket = tickets[foundKey];

          if (ticket.status !== 'open') {

            res.writeHead(400, { 'Content-Type': 'application/json' });

            return res.end(JSON.stringify({ success: false, error: 'Ce ticket est deja resolu' }));

          }



          if (!ticket.thread) {

            ticket.thread = [];

            if (ticket.message) {

              ticket.thread.push({ sender: 'user', text: ticket.message, time: ticket.createdAt });

            }

            if (ticket.reply) {

              ticket.thread.push({ sender: 'support', text: ticket.reply, time: ticket.updatedAt });

            }

          }



          const replyText = message.trim();

          ticket.thread.push({

            sender: 'user',

            text: replyText,

            time: new Date().toISOString()

          });

          ticket.lastUserReply = replyText;

          ticket.updatedAt = new Date().toISOString();

          saveTickets(tickets);



          // Notification sur Discord dans le salon dedie du ticket

          if (discordClient) {

            try {

              let targetChannel = null;

              if (ticket.channelId) {

                targetChannel = await discordClient.channels.fetch(ticket.channelId).catch(() => null);

              }

              if (!targetChannel) {

                targetChannel = await discordClient.channels.fetch(CHANNEL_ID).catch(() => null);

              }

              if (targetChannel) {

                const lines = [

                  `[REPONSE DU CLIENT] #${ticket.ticketId}`,

                  `Device ID : #${ticket.deviceId}`,

                  ``,

                  `Message :`,

                  `${replyText}`,

                  ``,

                  `Commandes :`,

                  `- Pour repondre : ecrivez votre reponse dans ce salon`,

                  `- Pour cloturer : tapez !close ou !ticket resolve`

                ];

                await targetChannel.send(lines.join('\n'));

              }

            } catch (dErr) {

              console.error('[BlinkSupport] Erreur notification reponse client:', dErr.message);

            }

          }



          res.writeHead(200, { 'Content-Type': 'application/json' });

          res.end(JSON.stringify({ success: true, ticket }));

        } catch (err) {

          res.writeHead(400, { 'Content-Type': 'application/json' });

          res.end(JSON.stringify({ success: false, error: err.message }));

        }

      });

      return;

    }



    // Endpoint GET /ticket/status/:deviceId : Verification statut pour Blink

    if (req.method === 'GET' && url.pathname.startsWith('/ticket/status/')) {

      const devId = url.pathname.replace('/ticket/status/', '').trim();

      const tickets = loadTickets();

      const userTickets = Object.values(tickets).filter(t => String(t.deviceId) === String(devId));

      const activeTicket = userTickets.find(t => t.status === 'open') || null;

      const lastResolved = userTickets.filter(t => t.status === 'resolved').sort((a,b) => b.updatedAt.localeCompare(a.updatedAt))[0] || null;



      res.writeHead(200, { 'Content-Type': 'application/json' });

      return res.end(JSON.stringify({

        success: true,

        activeTicket,

        lastResolved

      }));

    }



    // Endpoint POST /ticket/close/:id interdit au client (uniquement via commande discord)

    if (req.method === 'POST' && url.pathname.startsWith('/ticket/close/')) {

      res.writeHead(403, { 'Content-Type': 'application/json' });

      return res.end(JSON.stringify({ success: false, error: 'Resolution reservee exclusivement a la commande Discord !ticket resolve ou !close' }));

    }



    
    // Endpoint POST /stats : Notifications de visite et telechargement
    if (req.method === 'POST' && url.pathname === '/stats') {
      let body = '';
      req.on('data', chunk => body += chunk);
      req.on('end', async () => {
        try {
          const payload = JSON.parse(body);
          await sendStatsNotification(payload);
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: true }));
        } catch (e) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: false, error: e.message }));
        }
      });
      return;
    }

    res.writeHead(404);

    res.end();

  });



  server.listen(4820, '0.0.0.0', () => {

    console.log('[BlinkSupport] Serveur de tickets actif sur le port 4820');

  });

}



// Reponse directe ecrite par Support dans le salon d'un ticket

async function handleDirectChannelMessage(message) {

  if (!isAuthorized(message.author?.id)) return false;

  if (!message.content || !message.content.trim()) return false;



  const replyText = message.content.trim();

  // Ne JAMAIS traiter les messages de confirmation système ou commandes pour éviter une boucle infinie de selfbot

  if (replyText.startsWith('[') || replyText.startsWith('!') || replyText.startsWith('🤖')) return false;



  const tickets = loadTickets();

  const ticket = Object.values(tickets).find(t => t.channelId === message.channelId && t.status === 'open');

  if (!ticket) return false;



  if (!ticket.thread) {

    ticket.thread = [];

    if (ticket.message) {

      ticket.thread.push({ sender: 'user', text: ticket.message, time: ticket.createdAt });

    }

  }



  // Éviter d'enregistrer deux fois le même message si reçu en double

  const lastMsg = ticket.thread[ticket.thread.length - 1];

  if (lastMsg && lastMsg.sender === 'support' && lastMsg.text === replyText) {

    return false;

  }



  ticket.thread.push({

    sender: 'support',

    text: replyText,

    time: new Date().toISOString()

  });

  ticket.reply = replyText;

  ticket.updatedAt = new Date().toISOString();

  saveTickets(tickets);



  // Confirmer par une réaction pour valider visuellement la prise en compte sans polluer le chat ni déclencher de boucle récursive

  try {

    await message.react('✅');

  } catch (err) {

    // Si la réaction échoue, ne pas renvoyer de message texte pour éviter la récursion

  }

  return true;

}



// Commande !close ou !resolve : cloture le ticket et deplace le channel dans la categorie "closed ticket"

async function handleCloseCommand(message, args) {

  if (!isAuthorized(message.author?.id)) return;



  const tickets = loadTickets();

  let targetTicket = null;



  if (args.length > 0) {

    const raw = args[0].toUpperCase().replace('#', '');

    const foundKey = Object.keys(tickets).find(k => k.toUpperCase() === raw || k.toUpperCase() === 'TCK-' + raw);

    if (foundKey) {

      targetTicket = tickets[foundKey];

    }

  }



  // Si aucun argument fourni, chercher le ticket associe au salon actuel

  if (!targetTicket) {

    targetTicket = Object.values(tickets).find(t => t.channelId === message.channelId && t.status === 'open') ||

                   Object.values(tickets).find(t => t.channelId === message.channelId);

  }



  if (!targetTicket) {

    return message.reply('Aucun ticket actif associe a ce salon. Utilisation : !close [ID_TICKET]');

  }



  const guild = message.guild || (discordClient && (await discordClient.channels.fetch(CHANNEL_ID))?.guild);

  await closeTicketAndMoveChannel(targetTicket, guild);

  return message.reply(`Ticket #${targetTicket.ticketId} cloture et deplace dans la categorie "closed ticket".`);

}



// Commande !ticket (resolve, reply, list, open)

async function handleTicketCommand(message, args) {

  if (!isAuthorized(message.author?.id)) return;



  const subCommand = (args[0] || '').toLowerCase();

  const targetId = args[1];

  const tickets = loadTickets();



  if (subCommand === 'resolve' || subCommand === 'close') {

    let targetTicket = null;

    if (targetId) {

      const cleanId = targetId.toUpperCase().replace('#', '');

      const foundKey = Object.keys(tickets).find(k => k.toUpperCase() === cleanId || k.toUpperCase() === 'TCK-' + cleanId);

      if (foundKey) {

        targetTicket = tickets[foundKey];

      }

    } else {

      // Sans argument dans le channel du ticket

      targetTicket = Object.values(tickets).find(t => t.channelId === message.channelId && t.status === 'open') ||

                     Object.values(tickets).find(t => t.channelId === message.channelId);

    }



    if (!targetTicket) {

      return message.reply(`Ticket introuvable. Utilisation : !ticket resolve <ID_TICKET> (ou tapez simplement !close dans le salon)`);

    }



    const guild = message.guild || (discordClient && (await discordClient.channels.fetch(CHANNEL_ID))?.guild);

    await closeTicketAndMoveChannel(targetTicket, guild);

    return message.reply(`Ticket #${targetTicket.ticketId} marque comme resolu et deplace dans "closed ticket".`);

  }



  if (subCommand === 'reply') {

    let targetTicket = null;

    let replyText = '';



    if (targetId && args.length >= 3) {

      const cleanId = targetId.toUpperCase().replace('#', '');

      const foundKey = Object.keys(tickets).find(k => k.toUpperCase() === cleanId || k.toUpperCase() === 'TCK-' + cleanId);

      if (foundKey) {

        targetTicket = tickets[foundKey];

        replyText = args.slice(2).join(' ').trim();

      }

    } else if (args.length >= 2) {

      targetTicket = Object.values(tickets).find(t => t.channelId === message.channelId && t.status === 'open');

      if (targetTicket) {

        replyText = args.slice(1).join(' ').trim();

      }

    }



    if (!targetTicket || !replyText) {

      return message.reply('Utilisation : !ticket reply <ID_TICKET> <message> (ou ecrivez directement dans le salon du ticket)');

    }



    if (!targetTicket.thread) {

      targetTicket.thread = [];

      if (targetTicket.message) {

        targetTicket.thread.push({ sender: 'user', text: targetTicket.message, time: targetTicket.createdAt });

      }

    }



    targetTicket.thread.push({

      sender: 'support',

      text: replyText,

      time: new Date().toISOString()

    });

    targetTicket.reply = replyText;

    targetTicket.updatedAt = new Date().toISOString();

    saveTickets(tickets);



    return message.reply(`Reponse enregistree pour le ticket #${targetTicket.ticketId} : "${replyText}"`);

  }



  if (subCommand === 'list' || subCommand === 'open') {

    const openTickets = Object.values(tickets).filter(t => t.status === 'open');

    if (openTickets.length === 0) {

      return message.reply('Aucun ticket en cours.');

    }

    const listStr = openTickets.map(t => `- #${t.ticketId} [${t.category}] (Device #${t.deviceId}) : ${t.subject} ${t.channelId ? `(<#${t.channelId}>)` : ''}`).join('\n');

    return message.reply(`Tickets en cours (${openTickets.length}) :\n${listStr}`);

  }



  return message.reply('Commandes disponibles : !close [id], !ticket resolve [id], !ticket reply <id> <message>, !ticket list, !logs');

}



// Commande Discord !logs : Renvoie les logs selon l'HWID ou le Device ID specifie (ex: !logs 83226)

async function handleLogsCommand(message, args) {

  if (!isAuthorized(message.author?.id)) return;



  const allLogs = loadLogs();

  const availableHWIDs = Object.keys(allLogs);



  // Sous-commande !logs list / !logs devices

  if (args[0] && (args[0].toLowerCase() === 'list' || args[0].toLowerCase() === 'devices')) {

    if (availableHWIDs.length === 0) {

      return message.reply('Aucun log ni appareil enregistre pour le moment.');

    }

    const lines = availableHWIDs.map(hw => {

      const logs = allLogs[hw];

      const last = logs[logs.length - 1];

      const dId = last?.deviceId ? `#${last.deviceId}` : 'Inconnu';

      const lastTime = last?.time || 'Inconnu';

      return `• **Device ${dId}** | HWID : \`${hw}\` (${logs.length} logs, dernier a ${lastTime})`;

    });

    return message.reply(`Appareils enregistres dans Blink (${availableHWIDs.length}) :\n${lines.join('\n')}\n\nUtilisation : \`!logs <device_id ou hwid> [nombre_lignes]\``);

  }



  let targetQuery = null;

  let count = 15;



  if (args.length === 1) {

    const raw = args[0].trim().replace(/^#/, '');

    const num = parseInt(raw, 10);

    const matchesAny = availableHWIDs.some(hw => 

      hw.toLowerCase().includes(raw.toLowerCase()) || 

      allLogs[hw].some(l => String(l.deviceId).toLowerCase() === raw.toLowerCase())

    );



    if (!isNaN(num) && num > 0 && num <= 100 && !matchesAny && raw.length <= 3) {

      count = num;

      targetQuery = null;

    } else {

      targetQuery = raw;

      count = 15;

    }

  } else if (args.length >= 2) {

    const arg0Num = parseInt(args[0], 10);

    const arg1Num = parseInt(args[1], 10);

    if (!isNaN(arg1Num) && arg1Num > 0 && arg1Num <= 100) {

      targetQuery = args[0].trim().replace(/^#/, '');

      count = arg1Num;

    } else if (!isNaN(arg0Num) && arg0Num > 0 && arg0Num <= 100) {

      targetQuery = args[1].trim().replace(/^#/, '');

      count = arg0Num;

    } else {

      targetQuery = args[0].trim().replace(/^#/, '');

      count = 15;

    }

  }



  let matchedHWID = null;



  if (targetQuery) {

    const qLower = targetQuery.toLowerCase();



    // 1. Recherche exacte par HWID

    for (const hw of availableHWIDs) {

      if (hw.toLowerCase() === qLower) {

        matchedHWID = hw;

        break;

      }

    }



    // 2. Recherche par identifiant ou email

    if (!matchedHWID) {

      for (const hw of availableHWIDs) {

        if (allLogs[hw].some(l => String(l.deviceId).toLowerCase() === qLower)) {

          matchedHWID = hw;

          break;

        }

      }

    }



    // 3. Recherche partielle par HWID

    if (!matchedHWID) {

      for (const hw of availableHWIDs) {

        if (hw.toLowerCase().includes(qLower)) {

          matchedHWID = hw;

          break;

        }

      }

    }



    // 4. Recherche partielle par Device ID

    if (!matchedHWID) {

      for (const hw of availableHWIDs) {

        if (allLogs[hw].some(l => String(l.deviceId).toLowerCase().includes(qLower))) {

          matchedHWID = hw;

          break;

        }

      }

    }



    // Si specifiquement demande mais introuvable

    if (!matchedHWID) {

      const deviceList = availableHWIDs.map(hw => {

        const last = allLogs[hw][allLogs[hw].length - 1];

        const dId = last?.deviceId ? `#${last.deviceId}` : 'Inconnu';

        return `• Device ${dId} (HWID: \`${hw.slice(0, 12)}...\`)`;

      });

      return message.reply(`Aucun log trouve pour l'identifiant \`${targetQuery}\`.\n\nAppareils actuellement enregistres (${availableHWIDs.length}) :\n${deviceList.join('\n') || 'Aucun'}`);

    }

  } else {

    if (allLogs[DEFAULT_USER_HWID] && allLogs[DEFAULT_USER_HWID].length > 0) {

      matchedHWID = DEFAULT_USER_HWID;

    } else if (availableHWIDs.length > 0) {

      matchedHWID = availableHWIDs[0];

    }

  }



  const logsList = matchedHWID ? allLogs[matchedHWID] : null;



  if (!logsList || logsList.length === 0) {

    return message.reply(`Aucun log enregistre pour ce HWID/Device ID pour le moment.`);

  }



  const recentLogs = logsList.slice(-count);

  const detectedModel = recentLogs.slice().reverse().find(l => l.model)?.model || 'auto';

  const deviceId = recentLogs.slice().reverse().find(l => l.deviceId)?.deviceId || 'Inconnu';



  const formattedLines = recentLogs.map(l => {

    let summary = l.title ? `${l.title}` : (l.content ? l.content.slice(0, 50) : '');

    if (l.model && summary.includes(`[${l.model}]`)) {

      return `[${l.time}] [${l.tag}] ${summary}`;

    }

    const modelTag = l.model ? ` [${l.model}]` : '';

    return `[${l.time}] [${l.tag}]${modelTag} ${summary}`;

  });



  const header = `[LOGS BLINK] Device #${deviceId} | HWID: \`${matchedHWID}\` | Modele: ${detectedModel} (${recentLogs.length} lignes) :`;

  const textContent = `${header}\n\`\`\`text\n${formattedLines.join('\n')}\n\`\`\``;



  if (textContent.length > 1950) {

    const safeLines = formattedLines.slice(-10);

    return message.reply(`${header}\n\`\`\`text\n${safeLines.join('\n')}\n\`\`\``);

  }



  return message.reply(textContent);

}




async function sendStatsNotification(data) {
  if (!discordClient) return false;
  try {
    const channel = await discordClient.channels.fetch(STATS_CHANNEL_ID).catch(() => null);
    if (!channel) return false;

    const { type, clientId, ip, platform, browser, file, referrer, screen, referral } = data;
    const now = new Date();
    const timeStr = now.toLocaleDateString('fr-FR', {
      timeZone: 'Europe/Paris',
      day: '2-digit', month: '2-digit', year: 'numeric',
      hour: '2-digit', minute: '2-digit', second: '2-digit'
    });

    const KNOWN_DEVICE_IPS = {
      '193.57.205.248': 'Admin'
    };
    let effectiveClientId = clientId || 'Inconnu';
    if (ip && KNOWN_DEVICE_IPS[ip]) {
      effectiveClientId = `#${KNOWN_DEVICE_IPS[ip]}`;
    }

    let msg = '';
    if (type === 'download') {
      const emoji = (file && file.includes('.dmg')) ? '🍏' : 
                    (file && file.includes('.exe')) ? '🪟' : 
                    (file && file.includes('.ipa')) ? '📱' : 
                    (file && file.includes('.apk')) ? '🤖' : '📦';
      msg = [
        `📥 **Nouveau Téléchargement Blink !**`,
        `━━━━━━━━━━━━━━━━━━━━━━━━`,
        `• **Fichier** : ${emoji} \`${file || 'Blink.dmg'}\` (${platform || 'Inconnu'})`,
        `• **ID PC / Appareil** : \`${effectiveClientId}\``,
        `• **Adresse IP** : \`${ip || 'Inconnue'}\``,
        `• **Navigateur** : ${browser || 'Inconnu'}`,
        referral ? `• **Parrainage** : 🎁 \`${referral}\`` : null,
        `• **Date & Heure** : 🕒 ${timeStr}`,
        `━━━━━━━━━━━━━━━━━━━━━━━━`
      ].filter(Boolean).join('\n');
    } else {
      msg = [
        `🌐 **Nouvelle Visite sur le Site Blink**`,
        `━━━━━━━━━━━━━━━━━━━━━━━━`,
        `• **ID PC / Appareil** : \`${effectiveClientId}\``,
        `• **Adresse IP** : \`${ip || 'Inconnue'}\``,
        `• **Système** : 💻 ${platform || 'Inconnu'}`,
        `• **Navigateur** : ${browser || 'Inconnu'} ${screen ? `(${screen})` : ''}`,
        referral ? `• **Parrainage** : 🎁 \`${referral}\`` : null,
        `• **Provenance** : ${referrer && referrer !== 'Direct' ? referrer : 'Accès direct'}`,
        `• **Date & Heure** : 🕒 ${timeStr}`,
        `━━━━━━━━━━━━━━━━━━━━━━━━`
      ].filter(Boolean).join('\n');
    }

    await channel.send(msg);
    return true;
  } catch (err) {
    console.error('[BlinkSupport] Erreur envoi stats Discord:', err.message);
    return false;
  }
}

module.exports = {

  init,

  handleTicketCommand,

  handleCloseCommand,

  handleDirectChannelMessage,

  handleLogsCommand,

  AUTHORIZED_USER_ID,

  CHANNEL_ID

};

