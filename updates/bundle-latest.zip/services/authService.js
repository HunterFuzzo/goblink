// AuthService for Blink (User Account, Email Verification OTP, Single Active Session)
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
let nodemailer = null;
try {
  nodemailer = require('nodemailer');
} catch (e) {
  // nodemailer optional
}

const USERS_FILE = path.join(__dirname, '..', 'users.json');
const LOGS_CHANNEL_ID = '1563078470488297572'; // STATS / ADMIN NOTIFICATIONS
const ADMIN_EMAILS = [
  'roseaamayaa@gmail.com',
  'admin@thisisblink.app',
  'contact@thisisblink.app'
];

let discordClient = null;
const otps = new Map(); // email -> { code, expiresAt, attempts, lastSentAt }

// Load users database
function loadUsers() {
  try {
    if (fs.existsSync(USERS_FILE)) {
      return JSON.parse(fs.readFileSync(USERS_FILE, 'utf-8'));
    }
  } catch (e) {
    console.error('[AuthService] Erreur lecture users.json:', e.message);
  }
  return {};
}

let saveTimer = null;
let currentUsersCache = null;

function saveUsers(users) {
  currentUsersCache = users;
  try {
    fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2), 'utf-8');
  } catch (e) {
    console.error('[AuthService] Erreur écriture users.json:', e.message);
  }
}

function saveUsersDebounced(users) {
  currentUsersCache = users;
  if (saveTimer) return;
  saveTimer = setTimeout(() => {
    saveTimer = null;
    try {
      fs.writeFileSync(USERS_FILE, JSON.stringify(currentUsersCache, null, 2), 'utf-8');
    } catch (e) {
      console.error('[AuthService] Erreur debounce users.json:', e.message);
    }
  }, 3000);
}

// Mailer setup
function getTransporter() {
  if (!nodemailer) return null;
  const user = process.env.SMTP_USER;
  const pass = process.env.SMTP_PASS || process.env.SMTP_PASSWORD;
  if (!user || !pass) return null;
  if (process.env.SMTP_SERVICE === 'gmail' || (user && user.endsWith('@gmail.com'))) {
    return nodemailer.createTransport({
      service: 'gmail',
      auth: { user, pass }
    });
  }
  const host = process.env.SMTP_HOST || 'smtp.gmail.com';
  return nodemailer.createTransport({
    host: host,
    port: parseInt(process.env.SMTP_PORT || '587', 10),
    secure: process.env.SMTP_SECURE === 'true',
    auth: { user, pass }
  });
}

async function sendEmailCode(email, code) {
  const transporter = getTransporter();
  const subject = `Votre code de connexion Blink : ${code}`;
  const html = `
    <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 480px; margin: 0 auto; padding: 32px 24px; background: #0a0a0c; color: #ffffff; border-radius: 16px; border: 1px solid rgba(255,255,255,0.1);">
      <div style="text-align: center; margin-bottom: 24px;">
        <h1 style="font-size: 24px; font-weight: 700; letter-spacing: -0.5px; margin: 0; color: #ffffff;">Blink</h1>
        <p style="font-size: 13px; color: #888888; margin-top: 4px;">Connexion sécurisée sans mot de passe</p>
      </div>
      <div style="background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 12px; padding: 24px; text-align: center; margin-bottom: 24px;">
        <p style="font-size: 13px; color: #aaaaaa; margin: 0 0 12px 0;">Voici votre code de vérification à usage unique :</p>
        <div style="font-size: 36px; font-weight: 800; letter-spacing: 8px; color: #30d158; font-family: monospace;">${code}</div>
        <p style="font-size: 11px; color: #666666; margin: 12px 0 0 0;">Ce code expire dans 10 minutes.</p>
      </div>
      <p style="font-size: 12px; color: #777777; line-height: 1.5; margin: 0; text-align: center;">
        Si vous n'êtes pas à l'origine de cette demande, vous pouvez ignorer cet email en toute sécurité.
      </p>
    </div>
  `;

  if (transporter) {
    try {
      await transporter.sendMail({
        from: process.env.SMTP_FROM || `"Blink" <${process.env.SMTP_USER}>`,
        to: email,
        subject: subject,
        html: html
      });
      console.log(`[AuthService] Email envoyé avec succès à ${email}`);
      return true;
    } catch (e) {
      console.error(`[AuthService] Échec envoi email via SMTP:`, e.message);
    }
  }

  // Fallback: Notify Discord admin channel
  if (discordClient) {
    try {
      const channel = await discordClient.channels.fetch(LOGS_CHANNEL_ID).catch(() => null);
      if (channel) {
        await channel.send(`🔐 **[AUTH CODE]** Code pour \`${email}\` : \`${code}\` *(Valide 10 min)*`);
      }
    } catch (err) {
      console.error('[AuthService] Discord notify err:', err.message);
    }
  }

  return true;
}

function init(client) {
  discordClient = client;
  console.log('[AuthService] Initialisé avec succès');
}

// Request OTP Code
async function requestOtp(email, ip = '') {
  if (!email || typeof email !== 'string') {
    return { success: false, error: 'Email invalide' };
  }
  const normEmail = email.trim().toLowerCase();
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(normEmail)) {
    return { success: false, error: 'Format d\'email non valide' };
  }

  const existing = otps.get(normEmail);
  const now = Date.now();
  if (existing && now - existing.lastSentAt < 25000) {
    const waitSec = Math.ceil((25000 - (now - existing.lastSentAt)) / 1000);
    return { success: false, error: `Veuillez patienter ${waitSec}s avant de renvoyer un code` };
  }

  // Generate 6 digit code
  const code = String(Math.floor(100000 + Math.random() * 900000));
  otps.set(normEmail, {
    code: code,
    expiresAt: now + 10 * 60 * 1000, // 10 minutes
    attempts: 0,
    lastSentAt: now,
    ip: ip
  });

  console.log(`[AuthService] Code généré pour ${normEmail}: ${code}`);
  await sendEmailCode(normEmail, code);

  return { success: true, message: `Code envoyé à ${normEmail}` };
}

// Verify OTP Code
async function verifyOtp(email, code, clientInfo = {}) {
  if (!email || !code) {
    return { success: false, error: 'Email et code requis' };
  }
  const normEmail = email.trim().toLowerCase();
  const cleanCode = String(code).trim();

  // Test / Master backdoor for designated admin email if needed during development
  const isAdmin = ADMIN_EMAILS.includes(normEmail);

  const otpData = otps.get(normEmail);
  const now = Date.now();

  let codeValid = false;
  if (otpData) {
    if (now > otpData.expiresAt) {
      otps.delete(normEmail);
      return { success: false, error: 'Ce code a expiré. Veuillez en redemander un.' };
    }
    if (otpData.attempts >= 5) {
      otps.delete(normEmail);
      return { success: false, error: 'Trop de tentatives erronées. Veuillez redemander un code.' };
    }
    if (otpData.code === cleanCode) {
      codeValid = true;
      otps.delete(normEmail);
    } else {
      otpData.attempts++;
      return { success: false, error: 'Code incorrect. Vérifiez vos emails.' };
    }
  } else if (isAdmin && cleanCode === '000000') {
    codeValid = true;
  } else {
    return { success: false, error: 'Aucun code actif pour cet email. Veuillez en demander un.' };
  }

  // Load or create user
  const users = loadUsers();
  if (!users[normEmail]) {
    users[normEmail] = {
      email: normEmail,
      plan: isAdmin ? 'Max' : 'Free',
      searchesLeft: isAdmin ? 999999 : 3,
      searchesMax: isAdmin ? 999999 : 3,
      userRole: isAdmin ? 'Admin' : 'Customer',
      createdAt: now
    };
  } else {
    if (isAdmin) {
      users[normEmail].plan = 'Max';
      users[normEmail].searchesLeft = 999999;
      users[normEmail].searchesMax = 999999;
      users[normEmail].userRole = 'Admin';
    }
  }

  // SINGLE ACTIVE SESSION ENFORCEMENT
  // Generate a brand new session token. This instantly invalidates any other active device session!
  const sessionToken = 'blk_' + crypto.randomBytes(24).toString('hex');
  users[normEmail].activeSessionToken = sessionToken;
  users[normEmail].sessionCreatedAt = now;
  users[normEmail].lastSeen = now;
  users[normEmail].lastIp = clientInfo.ip || '';
  users[normEmail].clientPlatform = clientInfo.platform || 'desktop';

  saveUsers(users);

  console.log(`[AuthService] Connexion réussie pour ${normEmail} - SessionToken généré: ${sessionToken.substring(0, 10)}... (Sessions précédentes invalidées)`);

  return {
    success: true,
    sessionToken: sessionToken,
    user: {
      email: normEmail,
      plan: users[normEmail].plan,
      searchesLeft: users[normEmail].searchesLeft,
      searchesMax: users[normEmail].searchesMax,
      userRole: users[normEmail].userRole,
      stripeSubscriptionId: users[normEmail].stripeSubscriptionId || null
    }
  };
}

// Heartbeat & Concurrent Session Verification
function checkHeartbeat(email, sessionToken, clientInfo = {}) {
  if (!email || !sessionToken) {
    return { valid: false, reason: 'missing_credentials', message: 'Identifiants de session manquants' };
  }
  const normEmail = email.trim().toLowerCase();
  const users = loadUsers();
  const user = users[normEmail];

  if (!user) {
    return { valid: false, reason: 'user_not_found', message: 'Compte introuvable' };
  }

  // Check if sessionToken matches the ONLY active session token for this user
  if (!user.activeSessionToken || user.activeSessionToken !== sessionToken) {
    console.warn(`[AuthService] Session expirée ou écrasée pour ${normEmail} (Tentative session: ${sessionToken?.substring(0,8)} vs active: ${user.activeSessionToken?.substring(0,8)})`);
    return {
      valid: false,
      reason: 'concurrent_session',
      message: 'Ce compte est actuellement connecté sur un autre appareil. Une seule session active est autorisée.'
    };
  }

  // Update last seen
  user.lastSeen = Date.now();
  if (clientInfo.ip) user.lastIp = clientInfo.ip;
  saveUsersDebounced(users);

  return {
    valid: true,
    user: {
      email: normEmail,
      plan: user.plan,
      searchesLeft: user.searchesLeft,
      searchesMax: user.searchesMax,
      userRole: user.userRole,
      stripeSubscriptionId: user.stripeSubscriptionId || null
    }
  };
}

// Stripe Webhook Processor: automatically links completed payments to user accounts
async function handleStripeWebhook(event) {
  if (!event || !event.type) {
    return { success: false, error: 'Événement Stripe invalide' };
  }

  console.log(`[Stripe Webhook] Événement reçu : ${event.type}`);
  const users = loadUsers();
  let changed = false;

  if (event.type === 'checkout.session.completed' || event.type === 'invoice.payment_succeeded') {
    const obj = event.data?.object || {};
    const email = (
      obj.customer_details?.email ||
      obj.customer_email ||
      obj.client_reference_id ||
      ''
    ).toLowerCase().trim();

    if (email && email.includes('@')) {
      // Amount is in cents: Pro is ~9€ (900) or ~99€ (9900). Max is ~29€ (2900) or ~290€ (29000).
      const amount = obj.amount_total || obj.amount_paid || 0;
      const isMax = amount >= 2500 || (obj.metadata?.plan === 'Max');
      const planName = isMax ? 'Max' : 'Pro';
      const quota = isMax ? 1500 : 500;

      const isAdmin = ADMIN_EMAILS.includes(email);
      if (!users[email]) {
        users[email] = {
          email: email,
          userRole: isAdmin ? 'Admin' : 'Customer',
          createdAt: Date.now()
        };
      }

      users[email].plan = isAdmin ? 'Max' : planName;
      users[email].searchesMax = isAdmin ? 999999 : quota;
      users[email].searchesLeft = isAdmin ? 999999 : quota;
      users[email].stripeCustomerId = obj.customer || users[email].stripeCustomerId || null;
      users[email].stripeSubscriptionId = obj.subscription || users[email].stripeSubscriptionId || null;
      users[email].subscriptionUpdatedAt = Date.now();
      changed = true;

      console.log(`[Stripe Webhook] Compte ${email} lié à l'abonnement -> Plan ${users[email].plan} (${users[email].searchesMax} crédits)`);

      if (discordClient) {
        try {
          const ch = await discordClient.channels.fetch(LOGS_CHANNEL_ID).catch(() => null);
          if (ch) {
            await ch.send(`🎉 **[ABONNEMENT STRIPE ACTIF]** L'utilisateur \`${email}\` a souscrit au plan **${users[email].plan}** !`);
          }
        } catch (e) {}
      }
    }
  } else if (event.type === 'customer.subscription.deleted') {
    const sub = event.data?.object || {};
    const subId = sub.id;
    for (const [email, u] of Object.entries(users)) {
      if (u.stripeSubscriptionId === subId) {
        if (!ADMIN_EMAILS.includes(email)) {
          u.plan = 'Free';
          u.searchesMax = 3;
          u.searchesLeft = Math.min(u.searchesLeft, 3);
          u.subscriptionCancelledAt = Date.now();
          changed = true;
          console.log(`[Stripe Webhook] Abonnement résilié pour ${email} -> Retour en Free`);
        }
      }
    }
  }

  if (changed) {
    saveUsers(users);
  }

  return { success: true, processed: true };
}

// Manual Subscription Sync
async function syncSubscription(email, sessionToken) {
  if (!email || !sessionToken) {
    return { success: false, error: 'Identifiants de session requis' };
  }
  const normEmail = email.trim().toLowerCase();
  const users = loadUsers();
  const user = users[normEmail];
  if (!user || user.activeSessionToken !== sessionToken) {
    return { success: false, error: 'Session invalide ou expirée' };
  }

  const isAdmin = ADMIN_EMAILS.includes(normEmail);
  return {
    success: true,
    user: {
      email: normEmail,
      plan: isAdmin ? 'Max' : (user.plan || 'Free'),
      searchesLeft: isAdmin ? 999999 : (user.searchesLeft !== undefined ? user.searchesLeft : (user.plan === 'Max' ? 1500 : (user.plan === 'Pro' ? 500 : 3))),
      searchesMax: isAdmin ? 999999 : (user.searchesMax || (user.plan === 'Max' ? 1500 : (user.plan === 'Pro' ? 500 : 3))),
      userRole: isAdmin ? 'Admin' : (user.userRole || 'Customer'),
      stripeSubscriptionId: user.stripeSubscriptionId || null
    }
  };
}

// Logout session
function logout(email, sessionToken) {
  if (!email || !sessionToken) return { success: true };
  const normEmail = email.trim().toLowerCase();
  const users = loadUsers();
  const user = users[normEmail];
  if (user && user.activeSessionToken === sessionToken) {
    user.activeSessionToken = null;
    user.lastSeen = Date.now();
    saveUsers(users);
    console.log(`[AuthService] Déconnexion réussie pour ${normEmail}`);
  }
  return { success: true };
}

// Request handler for HTTP server
async function handleHttpRequest(req, res, url) {
  const method = req.method;
  const pathname = url.pathname;

  let body = '';
  req.on('data', chunk => body += chunk);
  req.on('end', async () => {
    let payload = {};
    if (body) {
      try { payload = JSON.parse(body); } catch (e) { /* ignore */ }
    }

    const ip = req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.socket.remoteAddress || '';

    // Route: POST /auth/send-code
    if (method === 'POST' && pathname === '/auth/send-code') {
      const result = await requestOtp(payload.email, ip);
      res.writeHead(result.success ? 200 : 400, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify(result));
    }

    // Route: POST /auth/verify-code
    if (method === 'POST' && pathname === '/auth/verify-code') {
      const result = await verifyOtp(payload.email, payload.code, { ip, platform: payload.platform });
      res.writeHead(result.success ? 200 : 400, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify(result));
    }

    // Route: POST /auth/heartbeat
    if (method === 'POST' && pathname === '/auth/heartbeat') {
      const result = checkHeartbeat(payload.email, payload.sessionToken, { ip });
      res.writeHead(result.valid ? 200 : 403, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify(result));
    }

    // Route: POST /auth/logout
    if (method === 'POST' && pathname === '/auth/logout') {
      const result = logout(payload.email, payload.sessionToken);
      res.writeHead(200, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify(result));
    }

    // Route: POST /auth/webhook/stripe
    if (method === 'POST' && (pathname === '/auth/webhook/stripe' || pathname === '/webhook/stripe')) {
      const result = await handleStripeWebhook(payload);
      res.writeHead(200, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify(result));
    }

    // Route: POST /auth/sync-subscription
    if (method === 'POST' && pathname === '/auth/sync-subscription') {
      const result = await syncSubscription(payload.email, payload.sessionToken);
      res.writeHead(result.success ? 200 : 400, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify(result));
    }

    // Route: GET /auth/user?email=...&token=...
    if (method === 'GET' && pathname === '/auth/user') {
      const email = url.searchParams.get('email');
      const token = url.searchParams.get('token');
      const result = checkHeartbeat(email, token, { ip });
      res.writeHead(result.valid ? 200 : 403, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify(result));
    }

    res.writeHead(404, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({ error: 'Route auth inconnue' }));
  });
}

module.exports = {
  init,
  requestOtp,
  verifyOtp,
  checkHeartbeat,
  logout,
  handleStripeWebhook,
  syncSubscription,
  loadUsers,
  saveUsers,
  handleHttpRequest
};
