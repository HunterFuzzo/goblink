// Rubric Frontend Engine - macOS Minimalist Theme with Live Logs Inspector

document.addEventListener('DOMContentLoaded', async () => {
  // Application State
  let config = {
    searchesLeft: 3,
    searchesMax: 3,
    visibilityMode: 'dock',
    responseMode: 'capslock',
    language: 'fr',
    shortcutDisplay: '⌃⌥⌘',
    userRole: 'Customer',
    plan: 'Free',
    usedThisMonth: 0,
    creditsLeft: 3,
    menuBarIcon: 'gearshape',
    testZone: false
  };

  if (window.rubricAPI) {
    try {
      const remoteConfig = await window.rubricAPI.getConfig();
      config = { ...config, ...remoteConfig };
    } catch (e) {
      console.warn('Fallback to local state:', e);
    }
  }

  // Internationalization Dictionary (French & English)
  const TRANSLATIONS = {
    en: {
      nav: {
        general: 'General',
        mode: 'Mode',
        account: 'Account',
        security: 'Security',
        logs: 'Logs',
        subscription: 'Subscription'
      },
      account: {
        title: 'Account',
        copyHint: 'Click to copy ID',
        copied: 'Copied!',
        copiedToast: 'Device ID copied to clipboard',
        statusHeading: 'Account status',
        plan: 'Plan',
        usedThisMonth: 'Used this month'
      },
      logs: {
        title: 'Logs & AI Traffic',
        trigger: 'Trigger',
        detach: 'Detach',
        clear: 'Clear',
        instruction: 'This console streams real-time telemetry: <strong>screen capture</strong>, <strong>prompt sent to FreeLLMAPI</strong>, <strong>raw AI response</strong>, and <strong>hardware indication output</strong>.',
        waiting: 'Waiting for activation...',
        shortcutHint: (shortcut) => `Press <kbd class="inline-kbd" id="emptyStateShortcutKbd">${shortcut}</kbd> or trigger from the Mode section to inspect live AI traffic.`
      },
      general: {
        title: 'General',
        preferences: 'Preferences',
        searchesLeft: 'Searches left',
        searchesDesc: 'Daily quota for question analysis',
        subscribe: 'Subscribe',
        upgrade: 'Upgrade',
        keyboardShortcut: 'Keyboard shortcut',
        shortcutDesc: 'Click badge to record a new trigger combination',
        appVisibility: 'App visibility',
        visibilityDesc: 'Show or hide the app icon from the macOS Dock',
        dock: 'Dock',
        hideFromDock: 'Hide from Dock',
        defaultIcon: 'Default icon',
        defaultIconDesc: 'Looks like an ordinary system icon rather than a special app.',
        captureZone: 'Capture zone',
        captureZoneDesc: 'Display frame in screen center to adjust width and height',
        configZone: 'Configuration',
        configuringZone: 'Configuring...',
        language: 'Language',
        languageDesc: 'Interface and response parsing language',
        supportHeading: 'Support',
        techSupport: 'Technical support',
        supportDesc: 'Need assistance or want to report an issue? Open a ticket',
        openTicket: 'Open a ticket',
        supportReplyTitle: 'Support Reply',
        replyReceivedBadge: 'Reply received',
        waitingSupportBadge: 'Waiting for support',
        inProgressBadge: 'In progress',
        replyPlaceholder: 'Write a reply to support...',
        sendReplyBtn: 'Send'
      },
      mode: {
        title: 'Mode',
        instruction: (shortcut) => `Point at a question number and press <kbd class="inline-kbd">${shortcut}</kbd>. The answer appears using the selected display method.`,
        displayMethod: 'Display method',
        capsLockTitle: 'Caps Lock LED',
        capsLockDesc: 'The keyboard LED blinks to indicate the answer number, with a 1-second pause between repeats.',
        hudTitle: 'Floating HUD',
        hudDesc: 'A discreet micro-overlay appears momentarily on your screen.',
        hapticTitle: 'Subtle Haptic',
        hapticDesc: 'Silent trackpad haptic pulses corresponding to the answer choice.',
        menuBarTitle: 'Menu Bar Icon',
        menuBarDesc: 'The macOS menu bar icon discreetly displays the detected answer number (1, 2, 3...).',
        iphoneTitle: 'iPhone Vibration',
        iphoneDesc: 'Your iPhone vibrates over local Wi-Fi based on the answer (1, 2, 3... pulses). Works while locked.',
        iphoneSettings: 'iPhone Vibration Settings',
        iphoneIp: 'iPhone IP address',
        iphoneIpDesc: 'Local IP shown in Blink Remote on your iPhone',
        serverPort: 'Server port',
        serverPortDesc: 'Local HTTP port (8765 by default)',
        vibrationTest: 'Vibration test',
        vibrationTestDesc: 'Sends 2 test haptic pulses to your iPhone',
        testVibrationBtn: 'Test vibration (#2)'
      },
      security: {
        title: 'Security',
        appPerms: 'App permissions',
        screenRecording: 'Screen recording',
        screenRecordingDesc: 'Required to read the question under the pointer.',
        accessibility: 'Accessibility',
        accessibilityDesc: 'Required for global keyboard shortcuts.',
        allowed: 'Allowed',
        notAllowed: 'Not allowed',
        privacy: 'Privacy',
        captureScope: 'Capture scope',
        captureScopeDesc: 'Only the display containing the pointer is captured when you trigger a search.',
        hardwareIdentity: 'Hardware Identity',
        deviceId: 'Device ID',
        deviceIdDesc: 'Hardware-bound ID used for subscription activation. Click to copy.'
      },
      subscription: {
        title: 'Subscription',
        plans: 'Plans',
        free: 'Free',
        freeFeatures: [
          '3 question analysis credits',
          'Caps Lock LED & Haptics'
        ],
        currentPlan: 'Current plan',
        pro: 'Pro',
        proFeatures: [
          '500 research',
          'All modes',
          'Stealth mode & unlimited access'
        ],
        popularBadge: 'POPULAR',
        upgradePro: 'Upgrade to Pro',
        max: 'Max',
        maxFeatures: [
          '1,500 research per month',
          'Everything in Pro included',
          'VIP Priority Support (< 2h)',
          'Early access to new features'
        ],
        upgradeMax: 'Upgrade to Max',
        manageSubscription: 'Manage subscription',
        freePlan: 'Free plan'
      },
      modal: {
        title: 'Submit Support Ticket',
        subject: 'Subject',
        subjectPlaceholder: 'e.g. Question detection feedback',
        category: 'Category',
        categories: {
          tech: 'Bug / Technical issue',
          feature: 'Feature request / Suggestion',
          general: 'General inquiry'
        },
        message: 'Detailed message',
        messagePlaceholder: 'Describe your question or issue with as much detail as possible...',
        cancel: 'Cancel',
        submit: 'Submit Ticket'
      }
    },
    fr: {
      nav: {
        general: 'Général',
        mode: 'Mode',
        account: 'Compte',
        security: 'Sécurité',
        logs: 'Journaux',
        subscription: 'Abonnement'
      },
      account: {
        title: 'Compte',
        copyHint: 'Cliquer pour copier l\'ID',
        copied: 'Copié !',
        copiedToast: 'ID de l\'appareil copié dans le presse-papiers',
        statusHeading: 'Statut du compte',
        plan: 'Formule',
        usedThisMonth: 'Utilisé ce mois-ci'
      },
      logs: {
        title: 'Journaux & Trafic IA',
        trigger: 'Déclencher',
        detach: 'Détacher',
        clear: 'Effacer',
        instruction: 'Cette console diffuse la télémétrie en temps réel : <strong>capture d\'écran</strong>, <strong>prompt envoyé à FreeLLMAPI</strong>, <strong>réponse brute de l\'IA</strong>, et <strong>indication matérielle</strong>.',
        waiting: 'En attente d\'activation...',
        shortcutHint: (shortcut) => `Appuyez sur <kbd class="inline-kbd" id="emptyStateShortcutKbd">${shortcut}</kbd> ou déclenchez depuis la section Mode pour inspecter le trafic IA.`
      },
      general: {
        title: 'Général',
        preferences: 'Préférences',
        searchesLeft: 'Analyses restantes',
        searchesDesc: 'Quota pour l\'analyse de questions',
        subscribe: 'S\'abonner',
        upgrade: 'Passer à Pro',
        keyboardShortcut: 'Raccourci clavier',
        shortcutDesc: 'Cliquez sur le badge pour enregistrer une combinaison',
        appVisibility: 'Visibilité de l\'application',
        visibilityDesc: 'Afficher ou masquer l\'icône dans le Dock macOS',
        dock: 'Dock',
        hideFromDock: 'Masquer du Dock',
        defaultIcon: 'Icône par défaut',
        defaultIconDesc: 'Ressemble à une icône système ordinaire plutôt qu\'à une application.',
        captureZone: 'Zone de capture',
        captureZoneDesc: 'Afficher le cadre au centre pour ajuster la largeur et la hauteur',
        configZone: 'Configuration',
        configuringZone: 'Configuration...',
        language: 'Langue',
        languageDesc: 'Langue de l\'interface et de l\'analyse',
        supportHeading: 'Support',
        techSupport: 'Support technique',
        supportDesc: 'Besoin d\'aide ou signaler un problème ? Ouvrir un ticket',
        openTicket: 'Ouvrir un ticket',
        supportReplyTitle: 'Réponse du Support',
        replyReceivedBadge: 'Réponse reçue',
        waitingSupportBadge: 'En attente du support',
        inProgressBadge: 'En cours',
        replyPlaceholder: 'Écrire une réponse au support...',
        sendReplyBtn: 'Envoyer'
      },
      mode: {
        title: 'Mode',
        instruction: (shortcut) => `Pointez sur un numéro de question et appuyez sur <kbd class="inline-kbd">${shortcut}</kbd>. La réponse s'affiche selon la méthode choisie.`,
        displayMethod: 'Méthode d\'affichage',
        capsLockTitle: 'LED Caps Lock',
        capsLockDesc: 'La LED du clavier clignote pour indiquer le numéro de la réponse, avec 1 seconde de pause entre les répétitions.',
        hudTitle: 'HUD Flottant',
        hudDesc: 'Un micro-overlay discret apparaît brièvement sur votre écran.',
        hapticTitle: 'Retour Haptique Discret',
        hapticDesc: 'Pulsions haptiques silencieuses sur le trackpad selon la réponse.',
        menuBarTitle: 'Icône Barre des Menus',
        menuBarDesc: 'L\'icône de la barre des menus macOS affiche discrètement le numéro de réponse détecté (1, 2, 3...).',
        iphoneTitle: 'Vibration iPhone',
        iphoneDesc: 'Votre iPhone vibre via le Wi-Fi local selon la réponse (1, 2, 3... vibrations). Fonctionne écran verrouillé.',
        iphoneSettings: 'Paramètres Vibration iPhone',
        iphoneIp: 'Adresse IP de l\'iPhone',
        iphoneIpDesc: 'IP locale affichée dans Blink Remote sur votre iPhone',
        serverPort: 'Port du serveur',
        serverPortDesc: 'Port HTTP local (8765 par défaut)',
        vibrationTest: 'Test de vibration',
        vibrationTestDesc: 'Envoie 2 vibrations de test à votre iPhone',
        testVibrationBtn: 'Tester la vibration (#2)'
      },
      security: {
        title: 'Sécurité',
        appPerms: 'Autorisations de l\'application',
        screenRecording: 'Enregistrement de l\'écran',
        screenRecordingDesc: 'Requis pour lire la question sous le pointeur.',
        accessibility: 'Accessibilité',
        accessibilityDesc: 'Requis pour les raccourcis clavier globaux.',
        allowed: 'Autorisé',
        notAllowed: 'Non autorisé',
        privacy: 'Confidentialité',
        captureScope: 'Périmètre de capture',
        captureScopeDesc: 'Seul l\'écran contenant le pointeur est capturé lors du déclenchement d\'une analyse.',
        hardwareIdentity: 'Identité Matérielle',
        deviceId: 'Identifiant de l\'appareil',
        deviceIdDesc: 'ID lié au matériel pour l\'activation de l\'abonnement. Cliquer pour copier.'
      },
      subscription: {
        title: 'Abonnement',
        plans: 'Formules',
        free: 'Gratuit',
        freeFeatures: [
          '3 crédits d\'analyse de questions',
          'LED Caps Lock & Haptique'
        ],
        currentPlan: 'Formule actuelle',
        pro: 'Pro',
        proFeatures: [
          '500 recherches',
          'Tous les modes',
          'Mode discret & accès illimité'
        ],
        popularBadge: 'POPULAIRE',
        upgradePro: 'Passer à Pro',
        max: 'Max',
        maxFeatures: [
          '1 500 recherches par mois',
          'Tout ce qui est inclus dans Pro',
          'Support Prioritaire VIP (< 2h)',
          'Accès anticipé aux nouveautés'
        ],
        upgradeMax: 'Passer à Max',
        manageSubscription: 'Gérer l\'abonnement',
        freePlan: 'Formule gratuite'
      },
      modal: {
        title: 'Soumettre un Ticket de Support',
        subject: 'Sujet',
        subjectPlaceholder: 'ex. Retour sur la détection de question',
        category: 'Catégorie',
        categories: {
          tech: 'Bug / Problème technique',
          feature: 'Demande de fonctionnalité / Suggestion',
          general: 'Question générale'
        },
        message: 'Message détaillé',
        messagePlaceholder: 'Décrivez votre question ou problème avec le plus de précisions possible...',
        cancel: 'Annuler',
        submit: 'Soumettre le Ticket'
      }
    }
  };

  function applyLanguage(lang) {
    const t = TRANSLATIONS[lang] || TRANSLATIONS.en;

    // 1. Navigation sidebar
    document.querySelectorAll('.nav-item').forEach(btn => {
      const sec = btn.getAttribute('data-section');
      const label = btn.querySelector('.nav-label');
      if (label && t.nav && t.nav[sec]) {
        label.textContent = t.nav[sec];
      }
    });

    // 2. Section Account
    const secAccount = document.getElementById('section-account');
    if (secAccount) {
      const title = secAccount.querySelector('.page-title');
      if (title) title.textContent = t.account.title;
      const subheading = secAccount.querySelector('.section-subheading');
      if (subheading) subheading.textContent = t.account.statusHeading;
      const copyHint = document.getElementById('accountCopyHint');
      if (copyHint && copyHint.textContent !== t.account.copied) {
        copyHint.textContent = t.account.copyHint;
      }
      const rows = secAccount.querySelectorAll('.grouped-row');
      if (rows[0]) {
        const label = rows[0].querySelector('.row-label');
        if (label) label.textContent = t.account.plan;
      }
      if (rows[1]) {
        const label = rows[1].querySelector('.row-label');
        if (label) label.textContent = t.account.usedThisMonth;
      }

      // Referral section translations
      const isFr = (lang === 'fr');
      const accountReferralHeading = document.getElementById('accountReferralHeading');
      if (accountReferralHeading) accountReferralHeading.textContent = isFr ? 'Programme de parrainage' : 'Referral Program';
      const referralShareDesc = document.getElementById('referralShareDesc');
      if (referralShareDesc) {
        referralShareDesc.textContent = isFr
          ? 'Invitez un ami pour obtenir une réduction'
          : 'Invite a friend to get discount';
      }
      const referralCodeLabel = document.getElementById('referralCodeLabel');
      if (referralCodeLabel) referralCodeLabel.textContent = isFr ? 'VOTRE CODE PARRAIN' : 'YOUR REFERRAL CODE';
      const btnCopyReferralCodeText = document.getElementById('btnCopyReferralCodeText');
      if (btnCopyReferralCodeText) btnCopyReferralCodeText.textContent = isFr ? 'Copier le code' : 'Copy code';
      const referralLinkLabel = document.getElementById('referralLinkLabel');
      if (referralLinkLabel) referralLinkLabel.textContent = isFr ? 'LIEN DIRECT À PARTAGER' : 'DIRECT SHARE LINK';
      const btnCopyReferralLinkText = document.getElementById('btnCopyReferralLinkText');
      if (btnCopyReferralLinkText) btnCopyReferralLinkText.textContent = isFr ? 'Partager le lien (-30%)' : 'Share Link (-30%)';

      const referralSubCalloutTitle = document.getElementById('referralSubCalloutTitle');
      if (referralSubCalloutTitle) referralSubCalloutTitle.textContent = isFr ? 'Programme de Parrainage (-30%)' : 'Referral Program (-30%)';
      const referralSubCalloutDesc = document.getElementById('referralSubCalloutDesc');
      if (referralSubCalloutDesc) referralSubCalloutDesc.textContent = isFr ? 'Invitez un ami : il bénéficie de -30% immédiat sur son abonnement Pro (~2 €/mois) ou Max.' : 'Invite a friend: they get 30% OFF immediately on Pro (~2 €/mo) or Max.';
      const btnGoToReferralTabText = document.getElementById('btnGoToReferralTabText');
      if (btnGoToReferralTabText) btnGoToReferralTabText.textContent = isFr ? 'Voir mon code →' : 'View my code →';
    }

    // 3. Section Logs
    const secLogs = document.getElementById('section-logs');
    if (secLogs) {
      const title = secLogs.querySelector('.page-title');
      if (title) title.textContent = t.logs.title;
      const btnTrigger = document.getElementById('btnTriggerNowFromLogs');
      if (btnTrigger) btnTrigger.textContent = t.logs.trigger;
      const btnDetach = document.getElementById('btnLaunchLogWindow');
      if (btnDetach) btnDetach.textContent = t.logs.detach;
      const btnClear = document.getElementById('btnClearEmbeddedLogs');
      if (btnClear) btnClear.textContent = t.logs.clear;
      const instr = secLogs.querySelector('.instruction-box p');
      if (instr) instr.innerHTML = t.logs.instruction;
      const emptyState = document.getElementById('embeddedEmptyState');
      if (emptyState) {
        const ps = emptyState.querySelectorAll('p');
        if (ps[0]) ps[0].textContent = t.logs.waiting;
        if (ps[1]) ps[1].innerHTML = t.logs.shortcutHint(config.shortcutDisplay || '⌃⌥⌘');
      }
    }

    // 4. Section General
    const secGeneral = document.getElementById('section-general');
    if (secGeneral) {
      const title = secGeneral.querySelector('.page-title');
      if (title) title.textContent = t.general.title;
      const subheadings = secGeneral.querySelectorAll('.section-subheading');
      if (subheadings[0]) subheadings[0].textContent = t.general.preferences;
      if (subheadings[1]) subheadings[1].textContent = t.general.supportHeading;

      // 4a. Searches left row
      const rowSearches = document.getElementById('rowGeneralSearches');
      if (rowSearches) {
        const label = rowSearches.querySelector('.row-label');
        const desc = rowSearches.querySelector('.row-desc');
        if (label) label.textContent = t.general.searchesLeft;
        if (desc) desc.textContent = t.general.searchesDesc;
        const btnUp = document.getElementById('btnUpgradeGeneral');
        if (btnUp) btnUp.textContent = t.general.subscribe;
      }

      // 4b. Keyboard shortcut row
      const btnRecordShortcut = document.getElementById('btnRecordShortcut');
      const rowShortcut = btnRecordShortcut?.closest('.grouped-row');
      if (rowShortcut) {
        const label = rowShortcut.querySelector('.row-label');
        const desc = rowShortcut.querySelector('.row-desc');
        if (label) label.textContent = t.general.keyboardShortcut;
        if (desc) desc.textContent = t.general.shortcutDesc;
      }

      // 4c. App visibility row & buttons
      const visibilityToggle = document.getElementById('visibilityToggle');
      const rowVisibility = visibilityToggle?.closest('.grouped-row');
      if (rowVisibility) {
        const label = rowVisibility.querySelector('.row-label');
        const desc = rowVisibility.querySelector('.row-desc');
        if (label) label.textContent = t.general.appVisibility;
        if (desc) desc.textContent = t.general.visibilityDesc;
        const btnDock = visibilityToggle.querySelector('[data-val="dock"]');
        if (btnDock) btnDock.textContent = t.general.dock;
        const btnHidden = visibilityToggle.querySelector('[data-val="hidden"]');
        if (btnHidden) btnHidden.textContent = t.general.hideFromDock;
      }

      // 4d. Default icon row
      const rowMenuBarIcon = document.getElementById('rowMenuBarIcon');
      if (rowMenuBarIcon) {
        const label = rowMenuBarIcon.querySelector('.row-label');
        const desc = rowMenuBarIcon.querySelector('.row-desc');
        if (label) label.textContent = t.general.defaultIcon;
        if (desc) desc.textContent = t.general.defaultIconDesc;
      }

      // 4e. Capture zone row & button
      const btnConfigureZone = document.getElementById('btnConfigureZone');
      const rowZone = btnConfigureZone?.closest('.grouped-row');
      if (rowZone) {
        const label = rowZone.querySelector('.row-label');
        const desc = rowZone.querySelector('.row-desc');
        if (label) label.textContent = t.general.captureZone;
        if (desc) desc.textContent = t.general.captureZoneDesc;
        if (btnConfigureZone) btnConfigureZone.textContent = t.general.configZone;
      }

      // 4f. Language row
      const langSel = document.getElementById('languageSelect');
      const rowLang = langSel?.closest('.grouped-row');
      if (rowLang) {
        const label = rowLang.querySelector('.row-label');
        const desc = rowLang.querySelector('.row-desc');
        if (label) label.textContent = t.general.language;
        if (desc) desc.textContent = t.general.languageDesc;
      }
      if (langSel && langSel.value !== lang) {
        langSel.value = lang;
      }

      // 4g. Support section
      const supTitle = document.getElementById('supportTicketTitle');
      const supDesc = document.getElementById('supportTicketDesc');
      const btnOpenSupport = document.getElementById('btnOpenSupportModal');
      if (btnOpenSupport && (!currentActiveTicket || currentActiveTicket.status !== 'open')) {
        if (supTitle) supTitle.textContent = t.general.techSupport;
        if (supDesc) supDesc.textContent = t.general.supportDesc;
        btnOpenSupport.textContent = t.general.openTicket;
      }

      const rowReply = document.getElementById('rowSupportTicketReply');
      if (rowReply) {
        const repLabel = rowReply.querySelector('.row-label');
        if (repLabel) repLabel.textContent = t.general.supportReplyTitle;
      }
      const inputRep = document.getElementById('inputSupportUserReply');
      if (inputRep) inputRep.placeholder = t.general.replyPlaceholder;
      const btnSendRep = document.getElementById('btnSendSupportUserReply');
      if (btnSendRep) btnSendRep.textContent = t.general.sendReplyBtn;
    }

    // 5. Section Mode
    const secMode = document.getElementById('section-mode');
    if (secMode) {
      const title = secMode.querySelector('.page-title');
      if (title) title.textContent = t.mode.title;
      const instr = secMode.querySelector('.instruction-box p');
      if (instr) instr.innerHTML = t.mode.instruction(config.shortcutDisplay || '⌃⌥⌘');
      const subheading = secMode.querySelector('.section-subheading');
      if (subheading) subheading.textContent = t.mode.displayMethod;

      const modeItems = secMode.querySelectorAll('.mode-item');
      modeItems.forEach(item => {
        const m = item.getAttribute('data-mode');
        const itemTitle = item.querySelector('.mode-item-title');
        const itemDesc = item.querySelector('.mode-item-desc');
        if (m === 'capslock') {
          if (itemTitle) itemTitle.textContent = t.mode.capsLockTitle;
          if (itemDesc) itemDesc.textContent = t.mode.capsLockDesc;
        } else if (m === 'hud') {
          if (itemTitle) itemTitle.textContent = t.mode.hudTitle;
          if (itemDesc) itemDesc.textContent = t.mode.hudDesc;
        } else if (m === 'haptic') {
          if (itemTitle) itemTitle.textContent = t.mode.hapticTitle;
          if (itemDesc) itemDesc.textContent = t.mode.hapticDesc;
        } else if (m === 'menubar') {
          if (itemTitle) itemTitle.textContent = t.mode.menuBarTitle;
          if (itemDesc) itemDesc.textContent = t.mode.menuBarDesc;
        } else if (m === 'iphone') {
          if (itemTitle) itemTitle.textContent = t.mode.iphoneTitle;
          if (itemDesc) itemDesc.textContent = t.mode.iphoneDesc;
        }
      });

      const iphoneHeading = document.getElementById('headingIphoneSettings');
      if (iphoneHeading) iphoneHeading.textContent = t.mode.iphoneSettings;
      const cardIphone = document.getElementById('cardIphoneSettings');
      if (cardIphone) {
        const rows = cardIphone.querySelectorAll('.grouped-row');
        if (rows[0]) {
          const l = rows[0].querySelector('.row-label');
          const d = rows[0].querySelector('.row-desc');
          if (l) l.textContent = t.mode.iphoneIp;
          if (d) d.textContent = t.mode.iphoneIpDesc;
        }
        if (rows[1]) {
          const l = rows[1].querySelector('.row-label');
          const d = rows[1].querySelector('.row-desc');
          if (l) l.textContent = t.mode.serverPort;
          if (d) d.textContent = t.mode.serverPortDesc;
        }
        if (rows[2]) {
          const l = rows[2].querySelector('.row-label');
          const d = rows[2].querySelector('.row-desc');
          if (l) l.textContent = t.mode.vibrationTest;
          if (d) d.textContent = t.mode.vibrationTestDesc;
          const btn = document.getElementById('btnTestIphoneHaptic');
          if (btn) btn.textContent = t.mode.testVibrationBtn;
        }
      }
    }

    // 6. Section Security
    const secSecurity = document.getElementById('section-security');
    if (secSecurity) {
      const title = secSecurity.querySelector('.page-title');
      if (title) title.textContent = t.security.title;
      const subheadings = secSecurity.querySelectorAll('.section-subheading');
      if (subheadings[0]) subheadings[0].textContent = t.security.appPerms;
      if (subheadings[1]) subheadings[1].textContent = t.security.privacy;
      if (subheadings[2]) subheadings[2].textContent = t.security.hardwareIdentity;

      const rowScreen = document.getElementById('rowScreenRecording');
      if (rowScreen) {
        const l = rowScreen.querySelector('.row-label');
        const d = rowScreen.querySelector('.row-desc');
        if (l) l.textContent = t.security.screenRecording;
        if (d) d.textContent = t.security.screenRecordingDesc;
      }
      const rowAx = document.getElementById('rowAccessibility');
      if (rowAx) {
        const l = rowAx.querySelector('.row-label');
        const d = rowAx.querySelector('.row-desc');
        if (l) l.textContent = t.security.accessibility;
        if (d) d.textContent = t.security.accessibilityDesc;
      }

      const permScreen = document.getElementById('permStatusScreen');
      if (permScreen) permScreen.textContent = t.security.allowed;
      const permAx = document.getElementById('permStatusAx');
      if (permAx) permAx.textContent = t.security.allowed;

      const cards = secSecurity.querySelectorAll('.grouped-card');
      if (cards[1]) {
        const l = cards[1].querySelector('.row-label');
        const d = cards[1].querySelector('.row-desc');
        if (l) l.textContent = t.security.captureScope;
        if (d) d.textContent = t.security.captureScopeDesc;
      }
      const rowDevId = document.getElementById('rowSecurityDeviceId');
      if (rowDevId) {
        const l = rowDevId.querySelector('.row-label');
        const d = rowDevId.querySelector('.row-desc');
        if (l) l.textContent = t.security.deviceId;
        if (d) d.textContent = t.security.deviceIdDesc;
      }
    }

    // 7. Section Subscription
    const secSub = document.getElementById('section-subscription');
    if (secSub) {
      const title = secSub.querySelector('.page-title');
      if (title) title.textContent = t.subscription.title;
      const subheading = secSub.querySelector('.section-subheading');
      if (subheading) subheading.textContent = t.subscription.plans;

      const cardFree = document.getElementById('subCardFree');
      if (cardFree) {
        const h3 = cardFree.querySelector('h3');
        if (h3) h3.textContent = t.subscription.free;
        const ul = cardFree.querySelector('.sub-features');
        if (ul && t.subscription.freeFeatures) {
          ul.innerHTML = t.subscription.freeFeatures.map(feat => `<li>${feat}</li>`).join('');
        }
        const btn = document.getElementById('btnPlanFree');
        if (btn) btn.textContent = t.subscription.currentPlan;
      }

      const cardPro = document.getElementById('subCardPro');
      if (cardPro) {
        const h3 = cardPro.querySelector('h3');
        if (h3) h3.textContent = t.subscription.pro;
        const badge = document.getElementById('subPopularBadge');
        if (badge && t.subscription.popularBadge) {
          badge.textContent = t.subscription.popularBadge;
        }
        const ul = cardPro.querySelector('.sub-features');
        if (ul && t.subscription.proFeatures) {
          ul.innerHTML = t.subscription.proFeatures.map(feat => `<li>${feat}</li>`).join('');
        }
        const billPeriod = document.getElementById('subBillingPeriod');
        if (billPeriod) {
          billPeriod.remove();
        }
        const btn = document.getElementById('btnUpgradePro');
        if (btn && btn.textContent !== 'Actif' && btn.textContent !== 'Active') {
          btn.textContent = t.subscription.upgradePro;
        }
      }

      const cardMax = document.getElementById('subCardMax');
      if (cardMax) {
        const h3 = cardMax.querySelector('h3');
        if (h3) h3.textContent = t.subscription.max;
        const ul = cardMax.querySelector('.sub-features');
        if (ul && t.subscription.maxFeatures) {
          ul.innerHTML = t.subscription.maxFeatures.map(feat => `<li>${feat}</li>`).join('');
        }
        const btn = document.getElementById('btnUpgradeMax');
        if (btn && btn.textContent !== 'Actif' && btn.textContent !== 'Active') {
          btn.textContent = t.subscription.upgradeMax;
        }
      }
    }

    // 8. Support Modal
    const modal = document.getElementById('supportModal');
    if (modal) {
      const title = modal.querySelector('.modal-title');
      if (title) title.textContent = t.modal.title;
      const labels = modal.querySelectorAll('.modal-label');
      if (labels[0]) labels[0].textContent = t.modal.subject;
      if (labels[1]) labels[1].textContent = t.modal.category;
      if (labels[2]) labels[2].textContent = t.modal.message;

      const inpSubject = document.getElementById('ticketSubject');
      if (inpSubject) inpSubject.placeholder = t.modal.subjectPlaceholder;

      const selCategory = document.getElementById('ticketCategory');
      if (selCategory) {
        const opts = selCategory.querySelectorAll('option');
        if (opts[0]) opts[0].textContent = t.modal.categories.tech;
        if (opts[1]) opts[1].textContent = t.modal.categories.feature;
        if (opts[2]) opts[2].textContent = t.modal.categories.general;
      }

      const txtMessage = document.getElementById('ticketMessage');
      if (txtMessage) txtMessage.placeholder = t.modal.messagePlaceholder;

      const btnCancel = document.getElementById('btnCancelSupportModal');
      if (btnCancel) btnCancel.textContent = t.modal.cancel;
      const btnSubmit = document.getElementById('btnSubmitTicket');
      if (btnSubmit) btnSubmit.textContent = t.modal.submit;
    }

    // Refresh active ticket text if open
    if (typeof updateSupportTicketUI === 'function') {
      updateSupportTicketUI(currentActiveTicket);
    }
    if (typeof updateAccountAndLicenseUI === 'function') {
      updateAccountAndLicenseUI();
    }
  }

  // DOM Elements
  const navButtons = document.querySelectorAll('.nav-item');
  const sections = document.querySelectorAll('.content-section');
  const modeItems = document.querySelectorAll('.mode-item');
  const simulatedCapsLed = document.getElementById('simulatedCapsLed');
  const btnTestHardwareBlink = document.getElementById('btnTestHardwareBlink');
  const btnSimulateQuestion = document.getElementById('btnSimulateQuestion');
  const demoStatusDesc = document.getElementById('demoStatusDesc');
  const inputApiKey = document.getElementById('inputApiKey');
  const btnToggleApiKeyMask = document.getElementById('btnToggleApiKeyMask');
  const inputBaseUrl = document.getElementById('inputBaseUrl');
  const selectModel = document.getElementById('selectModel');
  const btnSaveSecurity = document.getElementById('btnSaveSecurity');
  const btnTestApi = document.getElementById('btnTestApi');
  const apiTestResult = document.getElementById('apiTestResult');
  const visibilityBtns = document.querySelectorAll('#visibilityToggle .seg-btn');
  const checkboxTestZone = document.getElementById('checkboxTestZone');
  const inputCaptureWidth = document.getElementById('inputCaptureWidth');
  const inputCaptureHeight = document.getElementById('inputCaptureHeight');
  const btnOpenSupportModal = document.getElementById('btnOpenSupportModal');
  const supportModal = document.getElementById('supportModal');
  const btnCloseSupportModal = document.getElementById('btnCloseSupportModal');
  const btnCancelSupportModal = document.getElementById('btnCancelSupportModal');
  const btnSubmitTicket = document.getElementById('btnSubmitTicket');
  const ticketSubject = document.getElementById('ticketSubject');
  const ticketCategory = document.getElementById('ticketCategory');
  const ticketMessage = document.getElementById('ticketMessage');
  const ticketFeedback = document.getElementById('ticketFeedback');
  const modalDiagText = document.getElementById('modalDiagText');

  // Logs Elements
  const btnLaunchLogWindow = document.getElementById('btnLaunchLogWindow');
  const btnClearEmbeddedLogs = document.getElementById('btnClearEmbeddedLogs');
  const embeddedLogsList = document.getElementById('embeddedLogsList');
  const embeddedEmptyState = document.getElementById('embeddedEmptyState');
  const badgeLogsLive = document.getElementById('badgeLogsLive');

  // Admin Access Control (Hardware Bound)
  let isCurrentUserAdmin = false;
  const navItemLogs = document.getElementById('navItemLogs');
  const accountUserRole = document.getElementById('accountUserRole');
  const accountDeviceId = document.getElementById('accountDeviceId');

  // Account Status & HWID License Elements
  const statusPlanValue = document.getElementById('statusPlanValue');
  const statusUsedValue = document.getElementById('statusUsedValue');
  const statusCreditsValue = document.getElementById('statusCreditsValue');
  const licenseStatusValue = document.getElementById('licenseStatusValue');
  const licenseKeyValue = document.getElementById('licenseKeyValue');
  const deviceHwidValue = document.getElementById('deviceHwidValue');
  const btnCopyHwid = document.getElementById('btnCopyHwid');
  const inputLicenseKey = document.getElementById('inputLicenseKey');
  let latestLicenseInfo = null;
  const btnActivateLicense = document.getElementById('btnActivateLicense');
  const licenseFeedback = document.getElementById('licenseFeedback');
  const subCardFree = document.getElementById('subCardFree');
  const btnPlanFree = document.getElementById('btnPlanFree');
  const subCardPro = document.getElementById('subCardPro');
  const btnUpgradePro = document.getElementById('btnUpgradePro');
  const subCardMax = document.getElementById('subCardMax');
  const btnUpgradeMax = document.getElementById('btnUpgradeMax');

  // General & Menu Bar Elements
  const rowGeneralSearches = document.getElementById('rowGeneralSearches');
  const dividerGeneralSearches = document.getElementById('dividerGeneralSearches');
  const generalSearchesBadge = document.getElementById('generalSearchesBadge');
  const btnUpgradeGeneral = document.getElementById('btnUpgradeGeneral');
  const btnTestMenuBarIcon = document.getElementById('btnTestMenuBarIcon');
  const currentIconImg = document.getElementById('currentIconImg');
  const btnToggleIconDropdown = document.getElementById('btnToggleIconDropdown');
  const iconPickerDropdown = document.getElementById('iconPickerDropdown');
  const iconPickerGrid = document.getElementById('iconPickerGrid');
  const inputSearchIcons = document.getElementById('inputSearchIcons');
  const iconCountBadge = document.getElementById('iconCountBadge');

  async function applyAdminPermissions() {
    if (window.rubricAPI?.getLicenseInfo) {
      try {
        const info = await window.rubricAPI.getLicenseInfo();
        isCurrentUserAdmin = !!(info && info.isAdmin);
        if (navItemLogs) {
          navItemLogs.style.display = 'none';
        }
        const activeSection = document.querySelector('.content-section.active');
        if (activeSection && activeSection.id === 'section-logs') {
          activeSection.classList.remove('active');
          document.getElementById('section-general')?.classList.add('active');
          navButtons.forEach(b => b.classList.remove('active'));
          document.querySelector('.nav-item[data-section="general"]')?.classList.add('active');
        }
      } catch (e) {}
    }
  }

  async function updateAccountAndLicenseUI() {
    if (!window.rubricAPI) return;
    try {
      const info = await window.rubricAPI.getLicenseInfo();
      if (!info) return;
      latestLicenseInfo = info;

      if (accountDeviceId) {
        accountDeviceId.textContent = `Device ID #${info.deviceId || '87847'}`;
      }
      const btnSecDevId = document.getElementById('btnCopySecurityDeviceId');
      if (btnSecDevId) {
        btnSecDevId.textContent = `#${info.deviceId || '87847'}`;
      }
      const isMax = info.plan === 'Max';
      const isPro = info.plan === 'Pro';
      const isPaid = isPro || isMax;
      const defaultQuota = isMax ? 1500 : (isPro ? 500 : 3);

      if (statusPlanValue) {
        statusPlanValue.textContent = info.plan || (isPaid ? (isMax ? 'Max' : 'Pro') : 'Free');
        statusPlanValue.style.color = isPaid ? '#34c759' : 'var(--text-primary)';
      }
      if (statusUsedValue) {
        statusUsedValue.textContent = `${info.usedThisMonth || 0} / ${info.searchesMax || defaultQuota}`;
      }
      if (statusCreditsValue) {
        statusCreditsValue.textContent = info.searchesLeft !== undefined ? info.searchesLeft : defaultQuota;
        statusCreditsValue.style.color = (info.searchesLeft > 0) ? '#34c759' : '#ef4444';
      }
      const isFr = (config.language === 'fr');
      if (licenseStatusValue) {
        if (info.isMatch) {
          licenseStatusValue.textContent = isFr ? 'Actif (Appareil vérifié)' : (info.licenseStatus || 'Active (Verified device)');
          licenseStatusValue.style.color = '#34c759';
        } else {
          licenseStatusValue.textContent = isFr ? 'Appareil non autorisé (Lié à un autre Mac)' : 'Unauthorized device (Locked to another Mac)';
          licenseStatusValue.style.color = '#ef4444';
        }
      }
      if (licenseKeyValue) {
        licenseKeyValue.textContent = info.licenseKey || (isMax ? 'BLINK-MAX-ACTIVE' : (isPro ? 'BLINK-PRO-ACTIVE' : 'BLINK-FREE-DEFAULT'));
      }
      if (deviceHwidValue) {
        deviceHwidValue.title = info.deviceHWID || '';
      }

      // Populate Referral code & link
      const rawDeviceId = info.deviceId || '87847';
      const myReferralCode = `BLINK-${rawDeviceId}`;
      const myReferralLink = `https://thisisblink.vercel.app/?parrain=${myReferralCode}`;
      const elCode = document.getElementById('myReferralCode');
      if (elCode) elCode.textContent = myReferralCode;
      const elLink = document.getElementById('myReferralLinkText');
      if (elLink) elLink.textContent = myReferralLink;

      const badgeRef = document.querySelector('.referral-badge-mac');
      const descRef = document.getElementById('referralShareDesc');
      if (info.hasReferralReward) {
        if (badgeRef) {
          badgeRef.textContent = isFr ? '-30% RÉDUCTION ACTIVE' : '-30% DISCOUNT ACTIVE';
          badgeRef.style.background = 'rgba(52, 199, 89, 0.2)';
          badgeRef.style.color = '#34c759';
          badgeRef.style.borderColor = 'rgba(52, 199, 89, 0.4)';
        }
        if (descRef) {
          descRef.innerHTML = isFr
            ? `✓ <strong>Félicitations !</strong> Vous avez parrainé <strong>${info.referralCount || 1} ami(s)</strong>. Vous bénéficiez de <strong>-30% de réduction</strong> sur votre propre abonnement (Pro à <strong>~2 €/mois</strong> au lieu de 2,99 €) !`
            : `✓ <strong>Congratulations!</strong> You referred <strong>${info.referralCount || 1} friend(s)</strong>. You enjoy <strong>30% OFF</strong> your own subscription (Pro at <strong>~2 €/mo</strong> instead of 2.99 €)!`;
        }
      } else {
        if (badgeRef) {
          badgeRef.textContent = isFr ? 'PARRAINEZ = -30%' : 'REFER = -30%';
          badgeRef.style.background = 'rgba(255, 255, 255, 0.08)';
          badgeRef.style.color = '#a1a1a6';
          badgeRef.style.borderColor = 'rgba(255, 255, 255, 0.15)';
        }
        if (descRef) {
          descRef.textContent = isFr
            ? 'Invitez un ami pour obtenir une réduction'
            : 'Invite a friend to get discount';
        }
      }

      // Hide or show "Searches left" in General
      if (rowGeneralSearches) {
        rowGeneralSearches.style.display = isPaid ? 'none' : 'flex';
      }
      if (dividerGeneralSearches) {
        dividerGeneralSearches.style.display = isPaid ? 'none' : 'block';
      }
      if (!isPaid && generalSearchesBadge) {
        generalSearchesBadge.textContent = `${info.usedThisMonth || 0} / ${info.searchesMax || 3}`;
      }

      // Update plan prices in Subscription section dynamically via billing toggle
      updateAppBillingUI();

      // Sync subscription cards UI
      if (subCardFree && subCardPro) {
        if (isMax) {
          subCardFree.classList.remove('current');
          if (btnPlanFree) {
            btnPlanFree.disabled = true;
            btnPlanFree.textContent = isFr ? 'Formule gratuite' : 'Free plan';
          }
          subCardPro.classList.remove('current');
          if (btnUpgradePro) {
            btnUpgradePro.disabled = false;
            btnUpgradePro.textContent = isFr ? 'Gérer l\'abonnement' : 'Manage subscription';
          }
          if (subCardMax) subCardMax.classList.add('current');
          if (btnUpgradeMax) {
            btnUpgradeMax.disabled = false;
            btnUpgradeMax.textContent = isFr ? 'Gérer l\'abonnement' : 'Manage subscription';
          }
          if (btnUpgradeGeneral) btnUpgradeGeneral.style.display = 'none';
        } else if (isPro) {
          subCardFree.classList.remove('current');
          if (btnPlanFree) {
            btnPlanFree.disabled = true;
            btnPlanFree.textContent = isFr ? 'Formule gratuite' : 'Free plan';
          }
          subCardPro.classList.add('current');
          if (btnUpgradePro) {
            btnUpgradePro.disabled = false;
            btnUpgradePro.textContent = isFr ? 'Gérer l\'abonnement' : 'Manage subscription';
          }
          if (subCardMax) subCardMax.classList.remove('current');
          if (btnUpgradeMax) {
            btnUpgradeMax.disabled = false;
            btnUpgradeMax.textContent = isFr ? 'Passer à Max' : 'Upgrade to Max';
          }
          if (btnUpgradeGeneral) btnUpgradeGeneral.style.display = 'none';
        } else {
          subCardFree.classList.add('current');
          if (btnPlanFree) {
            btnPlanFree.disabled = true;
            btnPlanFree.textContent = isFr ? 'Formule actuelle' : 'Current plan';
          }
          subCardPro.classList.remove('current');
          if (btnUpgradePro) {
            btnUpgradePro.disabled = false;
            btnUpgradePro.textContent = isFr ? 'Passer à Pro' : 'Upgrade to Pro';
          }
          if (subCardMax) subCardMax.classList.remove('current');
          if (btnUpgradeMax) {
            btnUpgradeMax.disabled = false;
            btnUpgradeMax.textContent = isFr ? 'Passer à Max' : 'Upgrade to Max';
          }
          if (btnUpgradeGeneral) {
            btnUpgradeGeneral.style.display = 'inline-block';
            btnUpgradeGeneral.textContent = isFr ? 'S\'abonner' : 'Subscribe';
          }
        }
      }
    } catch (e) {
      console.error('Failed to load license info:', e);
    }
  }

  applyAdminPermissions();
  updateAccountAndLicenseUI();

  // Permissions Elements
  const rowScreenRecording = document.getElementById('rowScreenRecording');
  const rowAccessibility = document.getElementById('rowAccessibility');
  const permStatusScreen = document.getElementById('permStatusScreen');
  const permStatusAx = document.getElementById('permStatusAx');

  function updatePermissionsUI(perms) {
    if (!perms) return;

    if (permStatusScreen) {
      if (perms.screen || config.permissionsConfirmed) {
        permStatusScreen.textContent = 'Allowed';
        permStatusScreen.className = 'perm-status allowed';
      } else {
        permStatusScreen.textContent = 'Not allowed (Open Settings)';
        permStatusScreen.className = 'perm-status denied clickable';
      }
    }

    if (permStatusAx) {
      if (perms.accessibility || config.permissionsConfirmed) {
        permStatusAx.textContent = 'Allowed';
        permStatusAx.className = 'perm-status allowed';
      } else {
        permStatusAx.textContent = 'Not allowed (Open Settings)';
        permStatusAx.className = 'perm-status denied clickable';
      }
    }
  }

  if (rowScreenRecording) {
    rowScreenRecording.addEventListener('click', async () => {
      if (window.rubricAPI) {
        await window.rubricAPI.requestPermission('screen');
        // Toggle to allowed if user already granted it in system settings
        if (permStatusScreen && permStatusScreen.textContent.includes('Not allowed')) {
          permStatusScreen.textContent = 'Allowed';
          permStatusScreen.className = 'perm-status allowed';
          config.permissionsConfirmed = true;
          await window.rubricAPI.saveConfig({ permissionsConfirmed: true });
        }
      }
    });
  }

  if (rowAccessibility) {
    rowAccessibility.addEventListener('click', async () => {
      if (window.rubricAPI) {
        await window.rubricAPI.requestPermission('ax');
        if (permStatusAx && permStatusAx.textContent.includes('Not allowed')) {
          permStatusAx.textContent = 'Allowed';
          permStatusAx.className = 'perm-status allowed';
          config.permissionsConfirmed = true;
          await window.rubricAPI.saveConfig({ permissionsConfirmed: true });
        }
      }
    });
  }

  if (window.rubricAPI) {
    window.rubricAPI.getPermissions().then(updatePermissionsUI);
    window.rubricAPI.onPermissionsUpdated(updatePermissionsUI);

    // Auto-refresh when user clicks back into window
    window.addEventListener('focus', async () => {
      const perms = await window.rubricAPI.getPermissions();
      updatePermissionsUI(perms);
    });

    setInterval(async () => {
      if (document.hasFocus()) {
        const perms = await window.rubricAPI.getPermissions();
        updatePermissionsUI(perms);
      }
    }, 2000);
  }

  // Tab Navigation
  navButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const targetSection = btn.getAttribute('data-section');
      navButtons.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      sections.forEach(sec => {
        sec.classList.remove('active');
        if (sec.id === `section-${targetSection}`) {
          sec.classList.add('active');
        }
      });
    });
  });

  // Render a log card in the embedded logs section
  function appendEmbeddedLog(log) {
    if (embeddedEmptyState) embeddedEmptyState.style.display = 'none';

    // Flash sidebar badge
    if (badgeLogsLive) {
      badgeLogsLive.style.opacity = '1';
      setTimeout(() => { badgeLogsLive.style.opacity = '0.5'; }, 600);
    }

    const card = document.createElement('div');
    card.className = 'log-entry-card';

    let tagClass = 'trigger';
    if (log.type === 'request') tagClass = 'request';
    if (log.type === 'response') tagClass = 'response';
    if (log.type === 'hardware') tagClass = 'hardware';
    if (log.type === 'error') tagClass = 'error';

    const timeStr = log.time || new Date().toLocaleTimeString();

    card.innerHTML = `
      <div class="log-entry-header">
        <span class="badge-tag ${tagClass}">${(log.tag || log.type).toUpperCase()}</span>
        <span class="log-entry-time">${timeStr}</span>
      </div>
      <div class="log-entry-title">${log.title}</div>
      <div class="log-entry-body">${log.content}</div>
    `;

    embeddedLogsList.appendChild(card);
    embeddedLogsList.scrollTop = embeddedLogsList.scrollHeight;
  }

  // Open Floating Log Window (Strictly Admin only)
  function openLogWindow() {
    if (!isCurrentUserAdmin) {
      console.warn('Unauthorized: Logs window is restricted to admin.');
      return;
    }
    if (window.rubricAPI) {
      window.rubricAPI.openLogWindow();
    }
  }

  if (btnLaunchLogWindow) btnLaunchLogWindow.addEventListener('click', openLogWindow);

  const btnTriggerNowFromLogs = document.getElementById('btnTriggerNowFromLogs');
  if (btnTriggerNowFromLogs) {
    btnTriggerNowFromLogs.addEventListener('click', async () => {
      btnTriggerNowFromLogs.disabled = true;
      btnTriggerNowFromLogs.textContent = 'Running...';
      if (window.rubricAPI) {
        await window.rubricAPI.triggerAction();
      }
      btnTriggerNowFromLogs.textContent = 'Trigger';
      btnTriggerNowFromLogs.disabled = false;
    });
  }

  // Clear Embedded Logs
  if (btnClearEmbeddedLogs) {
    btnClearEmbeddedLogs.addEventListener('click', () => {
      embeddedLogsList.innerHTML = '';
      if (window.rubricAPI) window.rubricAPI.clearLogs();
      const empty = document.createElement('div');
      empty.className = 'empty-state';
      empty.id = 'embeddedEmptyState';
      empty.innerHTML = `<p>Logs cleared. Waiting for <kbd class="inline-kbd">⌃⌥⌘</kbd>...</p>`;
      embeddedLogsList.appendChild(empty);
    });
  }

  // Initial load of logs
  if (window.rubricAPI) {
    window.rubricAPI.getLogs().then(logs => {
      if (logs && logs.length > 0) {
        logs.forEach(appendEmbeddedLog);
      }
    });

    window.rubricAPI.onLogEvent((log) => {
      appendEmbeddedLog(log);
    });
  }

  // Mode Selection Helper
  function updateModeButtonUI() {
    const currentMode = config.responseMode || 'capslock';
    modeItems.forEach(m => {
      if (m.getAttribute('data-mode') === currentMode) {
        m.classList.add('active');
      } else {
        m.classList.remove('active');
      }
    });

    if (btnTestHardwareBlink) {
      if (currentMode === 'haptic') {
        btnTestHardwareBlink.textContent = 'Test Subtle Haptic (2 then 3 pulses)';
      } else if (currentMode === 'hud') {
        btnTestHardwareBlink.textContent = 'Test Floating HUD (#2 & #3)';
      } else if (currentMode === 'menubar') {
        btnTestHardwareBlink.textContent = 'Test Menu Bar Icon (#2 & #3)';
      } else if (currentMode === 'iphone') {
        btnTestHardwareBlink.textContent = 'Test iPhone Vibration (#2)';
      } else {
        btnTestHardwareBlink.textContent = 'Test Caps Lock LED (2 then 3 blinks)';
      }
    }

    const headingIphoneSettings = document.getElementById('headingIphoneSettings');
    const cardIphoneSettings = document.getElementById('cardIphoneSettings');
    if (headingIphoneSettings && cardIphoneSettings) {
      const isIphone = currentMode === 'iphone';
      headingIphoneSettings.style.display = isIphone ? 'block' : 'none';
      cardIphoneSettings.style.display = isIphone ? 'block' : 'none';
    }
  }

  updateModeButtonUI();

  // Mode Selection (Tous les modes disponibles en Free)
  modeItems.forEach(item => {
    item.addEventListener('click', async () => {
      const mode = item.getAttribute('data-mode');
      config.responseMode = mode;
      updateModeButtonUI();
      if (window.rubricAPI) {
        await window.rubricAPI.saveConfig({ responseMode: mode });
      }
    });
  });

  // iPhone Haptic Configuration Listeners
  const inputIphoneIp = document.getElementById('inputIphoneIp');
  const inputIphonePort = document.getElementById('inputIphonePort');
  const btnTestIphoneHaptic = document.getElementById('btnTestIphoneHaptic');
  const descIphoneStatus = document.getElementById('descIphoneStatus');

  if (inputIphoneIp) {
    inputIphoneIp.value = config.iphoneIp || '192.168.1.50';
    inputIphoneIp.addEventListener('change', async () => {
      config.iphoneIp = inputIphoneIp.value.trim();
      if (window.rubricAPI) {
        await window.rubricAPI.saveConfig({ iphoneIp: config.iphoneIp });
      }
    });
  }

  if (inputIphonePort) {
    inputIphonePort.value = config.iphonePort || 8765;
    inputIphonePort.addEventListener('change', async () => {
      config.iphonePort = parseInt(inputIphonePort.value, 10) || 8765;
      if (window.rubricAPI) {
        await window.rubricAPI.saveConfig({ iphonePort: config.iphonePort });
      }
    });
  }

  if (btnTestIphoneHaptic) {
    btnTestIphoneHaptic.addEventListener('click', async () => {
      const ip = inputIphoneIp ? inputIphoneIp.value.trim() : (config.iphoneIp || '192.168.1.50');
      const port = inputIphonePort ? parseInt(inputIphonePort.value, 10) : 8765;
      btnTestIphoneHaptic.disabled = true;
      btnTestIphoneHaptic.textContent = 'Sending to iPhone...';
      if (descIphoneStatus) {
        descIphoneStatus.textContent = `Connecting to http://${ip}:${port}...`;
        descIphoneStatus.style.color = 'var(--text-secondary)';
      }

      try {
        const res = await window.rubricAPI.testIphoneHaptic({ ip, port, digits: [2] });
        if (res && res.success) {
          btnTestIphoneHaptic.textContent = 'Vibrated successfully!';
          if (descIphoneStatus) {
            descIphoneStatus.textContent = 'Connected! 2 test pulses sent to iPhone.';
            descIphoneStatus.style.color = '#34c759';
          }
        } else {
          btnTestIphoneHaptic.textContent = 'Connection failed';
          if (descIphoneStatus) {
            descIphoneStatus.textContent = `Unable to reach iPhone (${res?.error || 'Offline'}). Make sure Blink Remote is running on your iPhone.`;
            descIphoneStatus.style.color = '#ff453a';
          }
        }
      } catch (err) {
        btnTestIphoneHaptic.textContent = 'Error';
        if (descIphoneStatus) {
          descIphoneStatus.textContent = `Error: ${err.message}`;
          descIphoneStatus.style.color = '#ff453a';
        }
      } finally {
        setTimeout(() => {
          btnTestIphoneHaptic.disabled = false;
          btnTestIphoneHaptic.textContent = 'Test vibration (#2)';
        }, 2500);
      }
    });
  }

  // Dock Visibility Segmented Control (dock, stealth, hidden)
  visibilityBtns.forEach(btn => {
    if (btn.getAttribute('data-val') === config.visibilityMode) {
      btn.classList.add('active');
    } else {
      btn.classList.remove('active');
    }

    btn.addEventListener('click', async () => {
      visibilityBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const mode = btn.getAttribute('data-val');
      config.visibilityMode = mode;
      if (window.rubricAPI) {
        await window.rubricAPI.saveConfig({ visibilityMode: mode });
      }
    });
  });

  // Language Selector Wiring
  const languageSelect = document.getElementById('languageSelect');
  if (languageSelect) {
    languageSelect.value = config.language || 'en';
    languageSelect.addEventListener('change', async () => {
      const selectedLang = languageSelect.value;
      config.language = selectedLang;
      applyLanguage(selectedLang);
      if (window.rubricAPI && window.rubricAPI.saveConfig) {
        await window.rubricAPI.saveConfig({ language: selectedLang });
      }
    });
  }

  // Visual SF Symbol Icon Picker Initialization (250+ icons, zero text names)
  async function initVisualIconPicker() {
    if (!iconPickerGrid) return;

    let symbols = [];
    if (window.rubricAPI && window.rubricAPI.getAvailableSymbols) {
      try {
        symbols = await window.rubricAPI.getAvailableSymbols();
      } catch (err) {
        console.error('Failed to load symbols via API:', err);
      }
    }

    if (!symbols || symbols.length === 0) {
      symbols = [
        "apple", "gearshape", "wifi", "link", "globe", "checkmark", "star", 
        "heart", "bolt", "flame", "sun.max", "moon", "cloud", "leaf", 
        "speaker.fill", "camera", "lock", "key", "eye", "magnifyingglass", 
        "command", "bell", "envelope", "message", "paperplane", "folder", 
        "doc", "brain", "lightbulb", "crown"
      ];
    }

    const activeSymbol = config.menuBarIcon || 'gearshape';
    if (currentIconImg) {
      currentIconImg.src = `../assets/tray/${activeSymbol}Template@2x.png`;
    }

    if (iconCountBadge) {
      iconCountBadge.textContent = `${symbols.length} icons`;
    }

    iconPickerGrid.innerHTML = '';
    const buttons = [];

    symbols.forEach(sym => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'icon-choice-btn' + (sym === activeSymbol ? ' selected' : '');
      btn.setAttribute('data-symbol', sym);
      btn.title = sym;

      const img = document.createElement('img');
      img.src = `../assets/tray/${sym}Template@2x.png`;
      img.alt = sym;
      img.loading = 'lazy';
      btn.appendChild(img);

      btn.addEventListener('click', async () => {
        buttons.forEach(b => b.btn.classList.remove('selected'));
        btn.classList.add('selected');
        config.menuBarIcon = sym;
        if (currentIconImg) {
          currentIconImg.src = `../assets/tray/${sym}Template@2x.png`;
        }
        if (window.rubricAPI) {
          await window.rubricAPI.saveConfig({ menuBarIcon: sym });
        }
        // Ferme le popover après sélection
        closeDropdown();
      });

      iconPickerGrid.appendChild(btn);
      buttons.push({ btn, sym });
    });

    function openDropdown() {
      if (!iconPickerDropdown) return;
      iconPickerDropdown.style.display = 'block';
      // Force layout reflow so animation triggers cleanly every time
      void iconPickerDropdown.offsetWidth;
      iconPickerDropdown.classList.add('open');
      if (btnToggleIconDropdown) {
        btnToggleIconDropdown.classList.add('active');
      }
    }

    function closeDropdown() {
      if (!iconPickerDropdown) return;
      iconPickerDropdown.classList.remove('open');
      iconPickerDropdown.style.display = 'none';
      if (btnToggleIconDropdown) {
        btnToggleIconDropdown.classList.remove('active');
      }
    }

    // Toggle dropdown button
    if (btnToggleIconDropdown && iconPickerDropdown) {
      btnToggleIconDropdown.addEventListener('click', (e) => {
        e.stopPropagation();
        const isOpen = iconPickerDropdown.classList.contains('open');
        if (isOpen) {
          closeDropdown();
        } else {
          openDropdown();
        }
      });

      document.addEventListener('click', (e) => {
        if (iconPickerDropdown.classList.contains('open')) {
          if (!iconPickerDropdown.contains(e.target) && !btnToggleIconDropdown.contains(e.target)) {
            closeDropdown();
          }
        }
      });

      document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && iconPickerDropdown.classList.contains('open')) {
          closeDropdown();
        }
      });
    }

    if (inputSearchIcons) {
      inputSearchIcons.addEventListener('input', () => {
        const query = inputSearchIcons.value.trim().toLowerCase();
        let visible = 0;
        buttons.forEach(({ btn, sym }) => {
          if (!query || sym.toLowerCase().includes(query)) {
            btn.style.display = 'flex';
            visible++;
          } else {
            btn.style.display = 'none';
          }
        });
        if (iconCountBadge) {
          iconCountBadge.textContent = `${visible} icon${visible > 1 ? 's' : ''}`;
        }
      });
    }
  }

  initVisualIconPicker();

  // Direct Menu Bar Test Button
  if (btnTestMenuBarIcon) {
    btnTestMenuBarIcon.addEventListener('click', async () => {
      if (window.rubricAPI && window.rubricAPI.testMenuBarBadge) {
        btnTestMenuBarIcon.disabled = true;
        btnTestMenuBarIcon.textContent = 'Displaying...';
        await window.rubricAPI.testMenuBarBadge([2, 3]);
        setTimeout(() => {
          btnTestMenuBarIcon.disabled = false;
          btnTestMenuBarIcon.textContent = 'Test Menu Bar Icon (#2)';
        }, 1500);
      }
    });
  }

  // Interactive Keyboard Shortcut Recorder
  const btnRecordShortcut = document.getElementById('btnRecordShortcut');
  const shortcutDisplayBadge = document.getElementById('shortcutDisplayBadge');
  const sidebarShortcutHint = document.getElementById('sidebarShortcutHint');
  const emptyStateShortcutKbd = document.getElementById('emptyStateShortcutKbd');

  function updateShortcutUI(display) {
    const disp = display || config.shortcutDisplay || '⌃⌥⌘';
    config.shortcutDisplay = disp;
    if (shortcutDisplayBadge) {
      shortcutDisplayBadge.textContent = disp;
      shortcutDisplayBadge.classList.remove('recording');
    }
    if (sidebarShortcutHint) {
      sidebarShortcutHint.innerHTML = `Shortcut: <strong>${disp}</strong>`;
    }
    if (emptyStateShortcutKbd) {
      emptyStateShortcutKbd.textContent = disp;
    }
    const modeKbd = document.getElementById('modeInstructionShortcutKbd');
    if (modeKbd) {
      modeKbd.textContent = disp;
    }
    const modeP = document.getElementById('modeInstructionText');
    const currentLang = (typeof config !== 'undefined' && config.language) ? config.language : 'fr';
    const dict = (typeof TRANSLATIONS !== 'undefined') ? TRANSLATIONS : {};
    const t = dict[currentLang] || dict.fr;
    if (modeP && t?.mode?.instruction) {
      modeP.innerHTML = t.mode.instruction(disp);
    }
  }

  updateShortcutUI();

  if (btnRecordShortcut) {
    let isRecording = false;

    function handleShortcutKeyDown(e) {
      e.preventDefault();
      e.stopPropagation();

      if (e.key === 'Escape') {
        stopRecording();
        updateShortcutUI();
        return;
      }

      const hasCtrl = e.ctrlKey;
      const hasAlt = e.altKey;
      const hasMeta = e.metaKey;
      const hasShift = e.shiftKey;

      const isModifierOnly = ['Control', 'Alt', 'Meta', 'Shift'].includes(e.key);

      if (isModifierOnly) {
        // Special case: Control + Alt + Command pressed together without regular key
        if (hasCtrl && hasAlt && hasMeta && !hasShift) {
          saveShortcut('Control+Alt+Command', '⌃⌥⌘');
          stopRecording();
        }
        return;
      }

      // Standard key pressed
      let key = e.key.toUpperCase();
      if (e.code === 'Space' || e.key === ' ') key = 'Space';
      else if (key === 'ARROWUP') key = 'Up';
      else if (key === 'ARROWDOWN') key = 'Down';
      else if (key === 'ARROWLEFT') key = 'Left';
      else if (key === 'ARROWRIGHT') key = 'Right';

      // Build Electron accelerator
      const accelParts = [];
      if (hasCtrl) accelParts.push('Control');
      if (hasAlt) accelParts.push('Alt');
      if (hasShift) accelParts.push('Shift');
      if (hasMeta) accelParts.push('Command');
      accelParts.push(key);

      // Build Mac visual symbols
      let displayParts = '';
      if (hasCtrl) displayParts += '⌃';
      if (hasAlt) displayParts += '⌥';
      if (hasShift) displayParts += '⇧';
      if (hasMeta) displayParts += '⌘';
      displayParts += (key === 'Space' ? ' Space' : (key.length === 1 ? key : ` ${key}`));

      const accel = accelParts.join('+');
      const display = displayParts.trim();

      saveShortcut(accel, display);
      stopRecording();
    }

    async function saveShortcut(accel, display) {
      config.shortcut = accel;
      config.shortcutDisplay = display;
      updateShortcutUI(display);
      if (window.rubricAPI) {
        await window.rubricAPI.saveConfig({ shortcut: accel, shortcutDisplay: display });
      }
    }

    function startRecording() {
      if (isRecording) return;
      isRecording = true;
      if (shortcutDisplayBadge) {
        shortcutDisplayBadge.textContent = 'Press keys...';
        shortcutDisplayBadge.classList.add('recording');
      }
      window.addEventListener('keydown', handleShortcutKeyDown, true);
    }

    function stopRecording() {
      if (!isRecording) return;
      isRecording = false;
      if (shortcutDisplayBadge) {
        shortcutDisplayBadge.classList.remove('recording');
      }
      window.removeEventListener('keydown', handleShortcutKeyDown, true);
    }

    btnRecordShortcut.addEventListener('click', (e) => {
      e.stopPropagation();
      if (isRecording) {
        stopRecording();
        updateShortcutUI();
      } else {
        startRecording();
      }
    });

    document.addEventListener('click', (e) => {
      if (isRecording && !btnRecordShortcut.contains(e.target)) {
        stopRecording();
        updateShortcutUI();
      }
    });
  }

  // Test Zone Checkbox Handler
  if (checkboxTestZone) {
    checkboxTestZone.checked = !!config.testZone;
    checkboxTestZone.addEventListener('change', async () => {
      config.testZone = checkboxTestZone.checked;
      if (window.rubricAPI) {
        await window.rubricAPI.saveConfig({ testZone: checkboxTestZone.checked });
      }
    });
  }

  // LED Animation Helper (supporte un chiffre unique ou un tableau [2, 3])
  async function animateLedPulses(digits, delayMs = 200, repeats = 2, pauseBetweenChoices = 1300, pauseBetweenCycles = 2200) {
    if (!simulatedCapsLed) return;
    const list = Array.isArray(digits) ? digits : [digits];
    const str = list.map(d => '#' + d).join(' & ');
    demoStatusDesc.textContent = `Pulsing LED for Option(s) ${str} (${repeats} cycle(s))...`;

    for (let r = 0; r < repeats; r++) {
      for (let c = 0; c < list.length; c++) {
        const count = parseInt(list[c], 10) || 1;
        for (let i = 0; i < count; i++) {
          simulatedCapsLed.classList.add('glowing');
          await new Promise(res => setTimeout(res, delayMs));

          simulatedCapsLed.classList.remove('glowing');
          await new Promise(res => setTimeout(res, delayMs));
        }

        if (c < list.length - 1) {
          demoStatusDesc.textContent = `Pause (1.3s) before next option...`;
          await new Promise(res => setTimeout(res, pauseBetweenChoices));
        }
      }

      if (r < repeats - 1) {
        demoStatusDesc.textContent = `Pause between cycles (2.2s)...`;
        await new Promise(res => setTimeout(res, pauseBetweenCycles));
      }
    }

    demoStatusDesc.innerHTML = `Completed. Answer detected: <strong>Option(s) ${str}</strong>`;
  }

  // Test Feedback Button (Caps Lock / Haptic / HUD)
  if (btnTestHardwareBlink) {
    btnTestHardwareBlink.addEventListener('click', async () => {
      btnTestHardwareBlink.disabled = true;
      const currentMode = config.responseMode || 'capslock';

      if (currentMode === 'haptic') {
        demoStatusDesc.textContent = 'Sending trackpad haptic pulses (2 pulses -> pause 1.3s -> 3 pulses)...';
        if (window.rubricAPI) {
          await window.rubricAPI.testHapticFeedback([2, 3]);
        }
        demoStatusDesc.innerHTML = 'Haptic feedback sent: <strong>2 vibrations, pause 1.3s, then 3 vibrations</strong> on trackpad.';
      } else if (currentMode === 'hud') {
        demoStatusDesc.textContent = 'Displaying Floating HUD (#2 & #3)...';
        if (window.rubricAPI) {
          await window.rubricAPI.testHudFeedback([2, 3]);
        }
        demoStatusDesc.innerHTML = 'Floating HUD displayed: <strong>Options #2 & #3</strong>.';
      } else if (currentMode === 'menubar') {
        demoStatusDesc.textContent = 'Displaying on menu bar (#2 & #3)...';
        if (window.rubricAPI && window.rubricAPI.testMenuBarBadge) {
          await window.rubricAPI.testMenuBarBadge([2, 3]);
        }
        demoStatusDesc.innerHTML = 'Menu bar: <strong>Icon and digits #2 & #3 displayed</strong>.';
      } else {
        demoStatusDesc.textContent = 'Triggering Caps Lock LED (2 blinks -> pause 1.3s -> 3 blinks)...';
        if (window.rubricAPI) {
          window.rubricAPI.testCapsLock({
            digits: [2, 3]
          });
        }
        await animateLedPulses([2, 3], 200, 1, 1300, 2200);
      }

      btnTestHardwareBlink.disabled = false;
    });
  }

  // Demo Multiple Choice Questions
  const SAMPLE_QUESTIONS = [
    {
      text: "Question: Which of the following protocols operate at the transport layer of the OSI model? (Multiple valid answers)\n1) HTTP\n2) TCP\n3) UDP\n4) IP",
      expected: [2, 3]
    },
    {
      text: "Question: What is the official capital of Australia?\n1) Canberra\n2) Sydney\n3) Melbourne\n4) Brisbane",
      expected: [1]
    },
    {
      text: "Question: What is the primary function of mitochondria in eukaryotic cells?\n1) Protein synthesis\n2) Cellular energy production (ATP)\n3) DNA replication\n4) Lipid storage",
      expected: [2]
    },
    {
      text: "Question: Which planet is closest to the Sun?\n1) Venus\n2) Mars\n3) Mercury\n4) Jupiter",
      expected: [3]
    }
  ];
  let sampleQuestionIndex = 0;

  // Simulate Question Button
  if (btnSimulateQuestion) {
    btnSimulateQuestion.addEventListener('click', async () => {
      btnSimulateQuestion.disabled = true;
      demoStatusDesc.textContent = 'Analyzing question with AI...';

      const currentSample = SAMPLE_QUESTIONS[sampleQuestionIndex % SAMPLE_QUESTIONS.length];
      sampleQuestionIndex++;

      try {
        let answerDigits = Array.isArray(currentSample.expected) ? currentSample.expected : [currentSample.expected];
        if (window.rubricAPI) {
          const res = await window.rubricAPI.triggerAction(currentSample.text);
          if (res && res.answerDigits && res.answerDigits.length > 0) {
            answerDigits = res.answerDigits;
          } else if (res && res.answerDigit) {
            answerDigits = [res.answerDigit];
          }
        }

        const answerStr = answerDigits.map(d => '#' + d).join(' & ');
        const currentMode = config.responseMode || 'capslock';
        if (currentMode === 'capslock') {
          await animateLedPulses(answerDigits, 200, 2, 1300, 2200);
        } else if (currentMode === 'haptic') {
          demoStatusDesc.innerHTML = `Analysis complete. Detected answer(s): <strong>Option(s) ${answerStr}</strong> (haptic pulses delivered to trackpad: ${answerDigits.join(' then ')}).`;
        } else {
          demoStatusDesc.innerHTML = `Analysis complete. Detected answer(s): <strong>Option(s) ${answerStr}</strong> (shown in micro-HUD).`;
        }
      } catch (err) {
        demoStatusDesc.textContent = 'Error: ' + err.message;
      } finally {
        btnSimulateQuestion.disabled = false;
      }
    });
  }

  // API Key Toggle
  if (btnToggleApiKeyMask) {
    btnToggleApiKeyMask.addEventListener('click', () => {
      if (inputApiKey.type === 'password') {
        inputApiKey.type = 'text';
        btnToggleApiKeyMask.textContent = 'Hide';
      } else {
        inputApiKey.type = 'password';
        btnToggleApiKeyMask.textContent = 'Show';
      }
    });
  }

  // Test FreeLLMAPI Connection
  if (btnTestApi) {
    btnTestApi.addEventListener('click', async () => {
      btnTestApi.disabled = true;
      apiTestResult.textContent = 'Testing connection...';

      if (window.rubricAPI) {
        const res = await window.rubricAPI.testApiConnection();
        if (res.success) {
          apiTestResult.textContent = `Connected (${res.latency}ms)`;
        } else {
          apiTestResult.textContent = `Failed: ${res.error}`;
        }
      } else {
        apiTestResult.textContent = 'Connected (24ms)';
      }
      btnTestApi.disabled = false;
    });
  }

  // Configuration Button - Opens interactive capture zone in center of screen
  const btnConfigureZone = document.getElementById('btnConfigureZone');
  if (btnConfigureZone) {
    btnConfigureZone.addEventListener('click', async () => {
      btnConfigureZone.disabled = true;
      btnConfigureZone.textContent = 'Configuring...';
      if (window.rubricAPI && window.rubricAPI.openZoneConfig) {
        await window.rubricAPI.openZoneConfig();
      }
      setTimeout(() => {
        btnConfigureZone.disabled = false;
        btnConfigureZone.textContent = 'Configuration';
      }, 500);
    });
  }

  // Support Ticket Modal & Rate Limiting Wiring
  let currentActiveTicket = null;

  function escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  async function updateSupportTicketUI(ticket) {
    if (ticket === undefined && window.rubricAPI?.getActiveTicket) {
      ticket = await window.rubricAPI.getActiveTicket();
    }
    currentActiveTicket = ticket;
    const titleEl = document.getElementById('supportTicketTitle');
    const descEl = document.getElementById('supportTicketDesc');
    const actionsEl = document.getElementById('supportTicketActions');
    const replyRow = document.getElementById('rowSupportTicketReply');
    const messagesContainer = document.getElementById('supportMessagesContainer');
    const userReplyBox = document.getElementById('supportUserReplyBox');
    const userReplyFeedback = document.getElementById('supportUserReplyFeedback');

    if (ticket && ticket.status === 'open') {
      if (titleEl) titleEl.textContent = `Ticket #${ticket.id}`;

      const isFr = (config.language === 'fr');
      // Verification si un message du support est present
      const hasSupportReply = Boolean(ticket.reply || (ticket.thread && ticket.thread.some(m => m.sender === 'support')));

      if (hasSupportReply) {
        if (replyRow) replyRow.style.display = 'flex';
        if (userReplyBox) userReplyBox.style.display = 'flex';

        // Construction du fil de conversation
        const thread = (ticket.thread && ticket.thread.length > 0) ? ticket.thread : [
          { sender: 'user', text: ticket.message || '' },
          ...(ticket.reply ? [{ sender: 'support', text: ticket.reply }] : [])
        ];

        if (messagesContainer) {
          messagesContainer.innerHTML = thread.map(msg => {
            const isSupport = msg.sender === 'support';
            const bg = isSupport ? 'rgba(52, 199, 89, 0.08)' : 'rgba(255, 255, 255, 0.04)';
            const border = isSupport ? '1px solid rgba(52, 199, 89, 0.25)' : '1px solid rgba(255, 255, 255, 0.08)';
            const label = isSupport ? (isFr ? 'Support Blink' : 'Blink Support') : (isFr ? 'Vous' : 'You');
            const labelColor = isSupport ? '#34c759' : 'var(--text-secondary)';
            const align = isSupport ? 'flex-start' : 'flex-end';
            return `
              <div style="align-self: ${align}; max-width: 88%; background: ${bg}; border: ${border}; border-radius: 8px; padding: 8px 12px;">
                <div style="font-size: 10.5px; color: ${labelColor}; margin-bottom: 2px; font-weight: 600;">${label}</div>
                <div style="font-size: 12.5px; color: var(--text-primary); line-height: 1.4; word-break: break-word;">${escapeHtml(msg.text)}</div>
              </div>
            `;
          }).join('');
        }

        const lastMsg = thread[thread.length - 1];
        if (lastMsg && lastMsg.sender === 'user') {
          if (descEl) descEl.textContent = isFr
            ? `"${ticket.subject}" • Reponse transmise, en attente du support`
            : `"${ticket.subject}" • Reply sent, waiting for support`;
          if (actionsEl) {
            actionsEl.innerHTML = `
              <div style="display: flex; align-items: center; gap: 8px;">
                <span style="font-size: 11.5px; padding: 5px 10px; border-radius: 6px; background: rgba(59, 130, 246, 0.15); color: #60a5fa; font-weight: 600;">${isFr ? 'En attente du support' : 'Waiting for support'}</span>
              </div>
            `;
          }
        } else {
          if (descEl) descEl.textContent = isFr
            ? `"${ticket.subject}" • Reponse recue du support`
            : `"${ticket.subject}" • Support reply received`;
          if (actionsEl) {
            actionsEl.innerHTML = `
              <div style="display: flex; align-items: center; gap: 8px;">
                <span style="font-size: 11.5px; padding: 5px 10px; border-radius: 6px; background: rgba(52, 199, 89, 0.15); color: #34c759; font-weight: 600;">${isFr ? 'Reponse recue' : 'Reply received'}</span>
              </div>
            `;
          }
        }
      } else {
        if (descEl) descEl.textContent = isFr
          ? `"${ticket.subject}" • En cours de traitement par le support`
          : `"${ticket.subject}" • In progress by support`;
        if (replyRow) replyRow.style.display = 'none';
        if (userReplyBox) userReplyBox.style.display = 'none';
        if (messagesContainer) messagesContainer.innerHTML = '';
        if (actionsEl) {
          actionsEl.innerHTML = `
            <div style="display: flex; align-items: center; gap: 8px;">
              <span style="font-size: 11.5px; padding: 5px 10px; border-radius: 6px; background: rgba(59, 130, 246, 0.15); color: #60a5fa; font-weight: 600;">${isFr ? 'En cours' : 'In progress'}</span>
            </div>
          `;
        }
      }
    } else {
      const isFr = (config.language === 'fr');
      if (titleEl) titleEl.textContent = isFr ? 'Support technique' : 'Technical support';
      if (descEl) descEl.textContent = isFr
        ? 'Besoin d aide ou signaler un probleme ? Ouvrir un ticket'
        : 'Need assistance or want to report an issue? Open a ticket';
      if (replyRow) replyRow.style.display = 'none';
      if (userReplyBox) userReplyBox.style.display = 'none';
      if (messagesContainer) messagesContainer.innerHTML = '';
      if (userReplyFeedback) userReplyFeedback.style.display = 'none';
      if (actionsEl) {
        actionsEl.innerHTML = `<button class="btn-dark-pill primary" id="btnOpenSupportModal">${isFr ? 'Ouvrir un ticket' : 'Open a ticket'}</button>`;
        document.getElementById('btnOpenSupportModal')?.addEventListener('click', openSupportModal);
      }
    }
  }

  // Traitement de la reponse utilisateur envoyee au support
  const inputUserReply = document.getElementById('inputSupportUserReply');
  const btnSendUserReply = document.getElementById('btnSendSupportUserReply');
  const userReplyFeedback = document.getElementById('supportUserReplyFeedback');

  async function handleSendUserReply() {
    if (!inputUserReply || !btnSendUserReply) return;
    const text = inputUserReply.value.trim();
    if (!text) {
      if (userReplyFeedback) {
        userReplyFeedback.style.display = 'block';
        userReplyFeedback.style.color = '#ef4444';
        userReplyFeedback.textContent = 'Veuillez saisir votre message.';
      }
      inputUserReply.focus();
      return;
    }

    inputUserReply.disabled = true;
    btnSendUserReply.disabled = true;
    if (userReplyFeedback) {
      userReplyFeedback.style.display = 'block';
      userReplyFeedback.style.color = 'var(--text-secondary)';
      userReplyFeedback.textContent = 'Envoi de votre reponse...';
    }

    try {
      if (window.rubricAPI?.sendTicketReply) {
        const res = await window.rubricAPI.sendTicketReply(text);
        if (res && res.success) {
          inputUserReply.value = '';
          if (userReplyFeedback) {
            userReplyFeedback.style.color = '#34c759';
            userReplyFeedback.textContent = 'Reponse transmise au support.';
            setTimeout(() => {
              if (userReplyFeedback) userReplyFeedback.style.display = 'none';
            }, 2500);
          }
          if (res.ticket) {
            updateSupportTicketUI(res.ticket);
          }
        } else {
          if (userReplyFeedback) {
            userReplyFeedback.style.color = '#ef4444';
            userReplyFeedback.textContent = res?.error || 'Erreur lors de l envoi.';
          }
        }
      }
    } catch (err) {
      if (userReplyFeedback) {
        userReplyFeedback.style.color = '#ef4444';
        userReplyFeedback.textContent = 'Erreur: ' + err.message;
      }
    } finally {
      inputUserReply.disabled = false;
      btnSendUserReply.disabled = false;
    }
  }

  btnSendUserReply?.addEventListener('click', handleSendUserReply);
  inputUserReply?.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleSendUserReply();
    }
  });

  function openSupportModal() {
    if (!supportModal) return;
    const isFr = (config.language === 'fr');
    if (currentActiveTicket && currentActiveTicket.status === 'open') {
      showToast(
        isFr ? 'Ticket deja en cours' : 'Ticket already open',
        isFr 
          ? `Le ticket #${currentActiveTicket.id} est en attente du support. Seul le support Discord peut le clore.`
          : `Ticket #${currentActiveTicket.id} is pending support. Only Discord support can resolve it.`
      );
      return;
    }
    supportModal.style.display = 'flex';
    if (ticketFeedback) ticketFeedback.textContent = '';
    if (ticketSubject) { ticketSubject.value = ''; ticketSubject.focus(); }
    if (ticketMessage) ticketMessage.value = '';
    if (btnSubmitTicket) btnSubmitTicket.disabled = false;
  }

  const btnOpenSupportInit = document.getElementById('btnOpenSupportModal');
  if (btnOpenSupportInit) {
    btnOpenSupportInit.addEventListener('click', openSupportModal);
  }

  const closeModal = () => { if (supportModal) supportModal.style.display = 'none'; };
  btnCloseSupportModal?.addEventListener('click', closeModal);
  btnCancelSupportModal?.addEventListener('click', closeModal);

  if (supportModal) {
    supportModal.addEventListener('click', (e) => {
      if (e.target === supportModal) closeModal();
    });
  }

  btnSubmitTicket?.addEventListener('click', async () => {
    const isFr = (config.language === 'fr');
    if (currentActiveTicket && currentActiveTicket.status === 'open') {
      if (ticketFeedback) {
        ticketFeedback.style.color = '#ef4444';
        ticketFeedback.textContent = isFr
          ? `Un ticket (#${currentActiveTicket.id}) est deja en cours. Veuillez attendre la resolution par le support.`
          : `A ticket (#${currentActiveTicket.id}) is already open. Please wait for support resolution.`;
      }
      return;
    }

    const subject = ticketSubject?.value.trim();
    const category = ticketCategory?.value || 'Technical Issue';
    const message = ticketMessage?.value.trim();

    if (!subject) {
      if (ticketFeedback) {
        ticketFeedback.style.color = '#ef4444';
        ticketFeedback.textContent = isFr ? 'Veuillez saisir un sujet.' : 'Please enter a subject.';
      }
      ticketSubject?.focus();
      return;
    }
    if (!message) {
      if (ticketFeedback) {
        ticketFeedback.style.color = '#ef4444';
        ticketFeedback.textContent = isFr ? 'Veuillez decrire votre demande ou probleme.' : 'Please describe your request or issue.';
      }
      ticketMessage?.focus();
      return;
    }

    btnSubmitTicket.disabled = true;
    if (ticketFeedback) {
      ticketFeedback.style.color = 'var(--text-secondary)';
      ticketFeedback.textContent = isFr ? 'Envoi du ticket en cours...' : 'Submitting ticket...';
    }

    try {
      if (window.rubricAPI) {
        const res = await window.rubricAPI.submitSupportTicket({ subject, category, message });
        if (res && res.success) {
          if (ticketFeedback) {
            ticketFeedback.style.color = '#34c759';
            ticketFeedback.textContent = isFr ? 'Ticket soumis avec succes !' : 'Ticket submitted successfully!';
          }
          if (res.ticket) {
            updateSupportTicketUI(res.ticket);
          }
          setTimeout(() => {
            closeModal();
            btnSubmitTicket.disabled = false;
          }, 1400);
        } else {
          if (ticketFeedback) {
            ticketFeedback.style.color = '#ef4444';
            ticketFeedback.textContent = res?.error || (isFr ? 'Erreur de soumission' : 'Submission error');
          }
          btnSubmitTicket.disabled = false;
        }
      }
    } catch (err) {
      if (ticketFeedback) {
        ticketFeedback.style.color = '#ef4444';
        ticketFeedback.textContent = 'Error: ' + err.message;
      }
      btnSubmitTicket.disabled = false;
    }
  });

  if (window.rubricAPI?.onTicketStatusUpdated) {
    window.rubricAPI.onTicketStatusUpdated((ticket) => {
      updateSupportTicketUI(ticket);
    });
  }

  window.addEventListener('focus', () => {
    if (window.rubricAPI?.checkTicketStatus) {
      window.rubricAPI.checkTicketStatus();
    }
  });

  // Initialisation du statut ticket et de la langue au lancement
  updateSupportTicketUI();
  applyLanguage(config.language || 'en');

  // Device ID copy handler (Account & Security)
  async function copyDeviceIdToClipboard(targetElem) {
    if (!window.rubricAPI) return;
    try {
      const info = await window.rubricAPI.getLicenseInfo();
      const devId = info?.deviceId || '87847';
      await navigator.clipboard.writeText(devId);

      const isFr = (config.language === 'fr');
      if (targetElem) {
        const originalText = targetElem.textContent;
        targetElem.textContent = isFr ? 'Copié !' : 'Copied!';
        setTimeout(() => {
          targetElem.textContent = originalText;
        }, 1500);
      }

      const hint = document.getElementById('accountCopyHint');
      if (hint) {
        hint.textContent = isFr ? 'Copié dans le presse-papiers !' : 'Copied to clipboard!';
        hint.style.color = '#34c759';
        setTimeout(() => {
          hint.textContent = isFr ? 'Cliquer pour copier l\'ID' : 'Click to copy ID';
          hint.style.color = '';
        }, 1500);
      }
    } catch (e) {
      console.warn('Copy failed:', e);
    }
  }

  if (accountDeviceId) {
    accountDeviceId.addEventListener('click', () => copyDeviceIdToClipboard(accountDeviceId));
  }
  const accountCopyHint = document.getElementById('accountCopyHint');
  if (accountCopyHint) {
    accountCopyHint.addEventListener('click', () => copyDeviceIdToClipboard(accountDeviceId));
  }

  const btnSecCopy = document.getElementById('btnCopySecurityDeviceId');
  const rowSecCopy = document.getElementById('rowSecurityDeviceId');
  if (btnSecCopy) {
    btnSecCopy.addEventListener('click', (e) => {
      e.stopPropagation();
      copyDeviceIdToClipboard(btnSecCopy);
    });
  }
  if (rowSecCopy) {
    rowSecCopy.addEventListener('click', () => copyDeviceIdToClipboard(btnSecCopy));
  }

  // Referral System copy handlers
  const btnCopyRefCode = document.getElementById('btnCopyReferralCode');
  const btnCopyRefLink = document.getElementById('btnCopyReferralLink');
  const refFeedback = document.getElementById('referralAppFeedback');

  function showReferralFeedback(msg) {
    if (!refFeedback) return;
    refFeedback.textContent = msg;
    refFeedback.style.display = 'block';
    setTimeout(() => {
      refFeedback.style.display = 'none';
    }, 3500);
  }

  if (btnCopyRefCode) {
    btnCopyRefCode.addEventListener('click', async (e) => {
      e.stopPropagation();
      const elCode = document.getElementById('myReferralCode');
      const code = elCode ? elCode.textContent : 'BLINK-87847';
      try {
        await navigator.clipboard.writeText(code);
        const isFr = (config.language === 'fr');
        showReferralFeedback(isFr ? `✓ Code ${code} copié !` : `✓ Code ${code} copied!`);
      } catch (err) {
        showReferralFeedback(`Code: ${code}`);
      }
    });
  }

  if (btnCopyRefLink) {
    btnCopyRefLink.addEventListener('click', async (e) => {
      e.stopPropagation();
      const elLink = document.getElementById('myReferralLinkText');
      const link = elLink ? elLink.textContent : 'https://thisisblink.vercel.app/?ref=BLINK-87847';
      try {
        await navigator.clipboard.writeText(link);
        const isFr = (config.language === 'fr');
        showReferralFeedback(isFr ? `✓ Lien de parrainage (-30%) copié ! Partagez-le à vos amis.` : `✓ Referral link (30% OFF) copied! Share it with friends.`);
      } catch (err) {
        showReferralFeedback(`Link: ${link}`);
      }
    });
  }

  const btnGoToReferralTab = document.getElementById('btnGoToReferralTab');
  if (btnGoToReferralTab) {
    btnGoToReferralTab.addEventListener('click', () => {
      const navAccount = document.querySelector('.nav-item[data-section="account"]');
      if (navAccount) navAccount.click();
      setTimeout(() => {
        const refCard = document.querySelector('.referral-share-card');
        if (refCard) refCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }, 50);
    });
  }

  const btnAccountChangePlan = document.getElementById('btnAccountChangePlan');
  const btnAccountGoSub = document.getElementById('btnAccountGoSubscription');
  const rowAccountSubLink = document.getElementById('rowAccountSubscriptionLink');
  const openSubscriptionTab = () => {
    const navSub = document.querySelector('.nav-item[data-section="subscription"]');
    if (navSub) navSub.click();
  };
  if (btnAccountChangePlan) btnAccountChangePlan.addEventListener('click', openSubscriptionTab);
  if (btnAccountGoSub) btnAccountGoSub.addEventListener('click', openSubscriptionTab);
  if (rowAccountSubLink) rowAccountSubLink.addEventListener('click', openSubscriptionTab);

  // HWID copy button (legacy)
  if (btnCopyHwid) {
    btnCopyHwid.addEventListener('click', async () => {
      if (window.rubricAPI) {
        const info = await window.rubricAPI.getLicenseInfo();
        if (info && info.deviceHWID) {
          navigator.clipboard.writeText(info.deviceHWID);
          btnCopyHwid.textContent = 'Copied!';
          setTimeout(() => { btnCopyHwid.textContent = 'Copy'; }, 1500);
        }
      }
    });
  }

  // License activation button
  if (btnActivateLicense) {
    const handleActivation = async () => {
      const key = inputLicenseKey?.value.trim();
      const isFr = (currentLang === 'fr');
      if (!key) {
        if (licenseFeedback) {
          licenseFeedback.style.color = '#ef4444';
          licenseFeedback.textContent = isFr ? 'Veuillez entrer une adresse email ou une clé de licence.' : 'Please enter an email or a license key.';
        }
        inputLicenseKey?.focus();
        return;
      }

      btnActivateLicense.disabled = true;
      if (licenseFeedback) {
        licenseFeedback.style.color = 'var(--text-secondary)';
        licenseFeedback.textContent = isFr ? 'Vérification et liaison avec Stripe...' : 'Verifying and binding device...';
      }

      try {
        if (window.rubricAPI) {
          const res = await window.rubricAPI.activateLicense(key);
          if (res && res.success) {
            if (licenseFeedback) {
              licenseFeedback.style.color = '#34c759';
              licenseFeedback.textContent = isFr 
                ? `Formule ${res.plan} activée avec succès (${res.searchesMax} analyses disponibles) !` 
                : `${res.plan} license activated successfully (${res.searchesMax} analyses available)!`;
            }
            if (inputLicenseKey) inputLicenseKey.value = '';
            showToast(
              isFr ? `Blink ${res.plan} Activé !` : `Blink ${res.plan} Activated!`,
              isFr ? 'Votre abonnement est actif et lié à cet appareil.' : 'Your subscription is active and bound to this device.'
            );
            await updateAccountAndLicenseUI();
          } else {
            if (licenseFeedback) {
              licenseFeedback.style.color = '#ef4444';
              licenseFeedback.textContent = (isFr ? 'Erreur : ' : 'Error: ') + (res?.error || 'Activation failed');
            }
          }
        }
      } catch (err) {
        if (licenseFeedback) {
          licenseFeedback.style.color = '#ef4444';
          licenseFeedback.textContent = 'Error: ' + err.message;
        }
      } finally {
        btnActivateLicense.disabled = false;
      }
    };

    btnActivateLicense.addEventListener('click', handleActivation);
    inputLicenseKey?.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') handleActivation();
    });
  }

  // Toast notifications UI
  function showToast(title, message, duration = 5000) {
    let container = document.querySelector('.blink-toast-container');
    if (!container) {
      container = document.createElement('div');
      container.className = 'blink-toast-container';
      document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    toast.className = 'blink-toast';
    toast.innerHTML = `
      <div class="blink-toast-title">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#34c759" stroke-width="2.5" stroke-linecap="round"><polyline points="20 6 9 17 4 12"></polyline></svg>
        <span>${title}</span>
      </div>
      <div class="blink-toast-msg">${message}</div>
    `;
    container.appendChild(toast);

    setTimeout(() => {
      toast.style.animation = 'toastFadeOut 0.3s cubic-bezier(0.16, 1, 0.3, 1) forwards';
      setTimeout(() => {
        toast.remove();
        if (container.children.length === 0) container.remove();
      }, 300);
    }, duration);
  }

  // OTA Silent Background Auto-Update Listener
  const updateAppliedHandler = window.blinkAPI?.onUpdateApplied || window.rubricAPI?.onUpdateApplied;
  if (updateAppliedHandler) {
    updateAppliedHandler((data) => {
      const isFr = (currentLang === 'fr');
      showToast(
        isFr ? `Mise à jour v${data.version} installée !` : `Update v${data.version} installed!`,
        isFr ? 'Blink a été mis à jour automatiquement en arrière-plan.' : 'Blink has been updated automatically in the background.'
      );
    });
  }

  // Gestion du toggle Facturation Mensuel / Annuel (+30% en mensuel, annuel par défaut 2.99€)
  let currentAppBillingPeriod = 'yearly';

  function updateAppBillingUI() {
    const isYearly = currentAppBillingPeriod === 'yearly';
    const isFr = (config?.language || 'fr') === 'fr';
    const hasReward = !!latestLicenseInfo?.hasReferralReward;

    const btnYearly = document.getElementById('btnAppPeriodYearly');
    const btnMonthly = document.getElementById('btnAppPeriodMonthly');
    if (btnYearly) btnYearly.classList.toggle('active', isYearly);
    if (btnMonthly) btnMonthly.classList.toggle('active', !isYearly);

    const pricePro = document.getElementById('subPricePro');
    const notePro = document.getElementById('subNotePro');
    const priceMax = document.getElementById('subPriceMax');
    const noteMax = document.getElementById('subNoteMax');

    if (isYearly) {
      if (pricePro) {
        pricePro.innerHTML = hasReward
          ? `<span style="text-decoration: line-through; opacity: 0.5; font-size: 13px; margin-right: 4px;">2.99 €</span> 2.09 € <span>/mo</span> <span style="font-size: 10px; color: #34c759; font-weight: 700; margin-left: 4px;">-30%</span>`
          : `2.99 € <span>/mo</span>`;
      }
      if (notePro) {
        notePro.textContent = hasReward
          ? (isFr ? 'Facturé 25,12 € / an (Remise parrain -30%)' : 'Billed €25.12 / yr (Referral -30%)')
          : (isFr ? 'Facturé 35,88 € / an' : 'Billed €35.88 / yr');
        notePro.className = 'sub-price-note';
      }
      if (priceMax) {
        priceMax.innerHTML = hasReward
          ? `<span style="text-decoration: line-through; opacity: 0.5; font-size: 13px; margin-right: 4px;">4.99 €</span> 3.49 € <span>/mo</span> <span style="font-size: 10px; color: #34c759; font-weight: 700; margin-left: 4px;">-30%</span>`
          : `4.99 € <span>/mo</span>`;
      }
      if (noteMax) {
        noteMax.textContent = hasReward
          ? (isFr ? 'Facturé 41,92 € / an (Remise parrain -30%)' : 'Billed €41.92 / yr (Referral -30%)')
          : (isFr ? 'Facturé 59,88 € / an' : 'Billed €59.88 / yr');
        noteMax.className = 'sub-price-note';
      }
    } else {
      if (pricePro) {
        pricePro.innerHTML = hasReward
          ? `<span style="text-decoration: line-through; opacity: 0.5; font-size: 13px; margin-right: 4px;">3.89 €</span> 2.72 € <span>/mo</span> <span style="font-size: 10px; color: #34c759; font-weight: 700; margin-left: 4px;">-30%</span>`
          : `3.89 € <span>/mo</span>`;
      }
      if (notePro) {
        notePro.textContent = '(+30%)';
        notePro.className = 'sub-price-note highlight';
      }
      if (priceMax) {
        priceMax.innerHTML = hasReward
          ? `<span style="text-decoration: line-through; opacity: 0.5; font-size: 13px; margin-right: 4px;">6.49 €</span> 4.54 € <span>/mo</span> <span style="font-size: 10px; color: #34c759; font-weight: 700; margin-left: 4px;">-30%</span>`
          : `6.49 € <span>/mo</span>`;
      }
      if (noteMax) {
        noteMax.textContent = '(+30%)';
        noteMax.className = 'sub-price-note highlight';
      }
    }
  }

  const btnAppYearly = document.getElementById('btnAppPeriodYearly');
  if (btnAppYearly) {
    btnAppYearly.addEventListener('click', () => {
      currentAppBillingPeriod = 'yearly';
      updateAppBillingUI();
    });
  }

  const btnAppMonthly = document.getElementById('btnAppPeriodMonthly');
  if (btnAppMonthly) {
    btnAppMonthly.addEventListener('click', () => {
      currentAppBillingPeriod = 'monthly';
      updateAppBillingUI();
    });
  }

  updateAppBillingUI();

  // Gestion de la souscription Stripe & Redirection Checkout
  async function triggerStripeSubscription(btn, plan = 'Pro') {
    if (!btn || btn.disabled) return;
    const oldText = btn.textContent;
    btn.disabled = true;
    btn.textContent = 'Opening Stripe...';

    try {
      const info = await (window.blinkAPI?.getLicenseInfo() || window.rubricAPI?.getLicenseInfo());
      const isAlreadyOnThisPlan = info?.plan === plan;

      if (isAlreadyOnThisPlan) {
        btn.textContent = 'Opening Portal...';
        const portalRes = await (window.blinkAPI?.openCustomerPortal() || window.rubricAPI?.openCustomerPortal());
        if (!portalRes?.success) {
          showToast(`Blink ${plan} Actif`, 'Votre abonnement est déjà actif et lié au matériel de ce Mac.');
        }
        btn.disabled = false;
        btn.textContent = 'Manage subscription';
        return;
      }

      const res = await (window.blinkAPI?.startStripeCheckout(plan, currentAppBillingPeriod) || window.rubricAPI?.startStripeCheckout(plan, currentAppBillingPeriod));
      if (res && res.success) {
        btn.textContent = 'Waiting for payment...';
        showToast('Stripe Checkout', 'Finalisez votre paiement dans votre navigateur. Blink s\'activera automatiquement dès la validation.');
      } else {
        alert('Erreur Stripe : ' + (res?.error || 'Impossible d\'ouvrir la page de paiement.'));
        btn.disabled = false;
        btn.textContent = oldText;
      }
    } catch (e) {
      console.error('Stripe Checkout error:', e);
      btn.disabled = false;
      btn.textContent = oldText;
    }
  }

  if (btnUpgradePro) {
    btnUpgradePro.addEventListener('click', () => triggerStripeSubscription(btnUpgradePro, 'Pro'));
  }

  if (btnUpgradeMax) {
    btnUpgradeMax.addEventListener('click', () => triggerStripeSubscription(btnUpgradeMax, 'Max'));
  }

  if (btnUpgradeGeneral) {
    btnUpgradeGeneral.addEventListener('click', () => triggerStripeSubscription(btnUpgradeGeneral, 'Pro'));
  }

  const subActivatedHandler = window.blinkAPI?.onSubscriptionActivated || window.rubricAPI?.onSubscriptionActivated;
  if (subActivatedHandler) {
    subActivatedHandler((data) => {
      updateAccountAndLicenseUI();
      if (btnUpgradePro) {
        btnUpgradePro.disabled = false;
        btnUpgradePro.textContent = 'Manage subscription';
      }
      if (btnUpgradeGeneral) {
        btnUpgradeGeneral.style.display = 'none';
      }
      showToast('Blink Pro Activé !', 'Votre abonnement est actif et lié à cet appareil.');
    });
  }

  const planUpdatedHandler = window.blinkAPI?.onPlanUpdated || window.rubricAPI?.onPlanUpdated;
  if (planUpdatedHandler) {
    planUpdatedHandler((data) => {
      updateAccountAndLicenseUI();
    });
  }

  window.addEventListener('focus', () => {
    updateAccountAndLicenseUI();
    if (window.blinkAPI?.checkStripeSubscription) {
      window.blinkAPI.checkStripeSubscription().then(() => updateAccountAndLicenseUI());
    }
  });

  if (window.rubricAPI) {
    window.rubricAPI.onActionCompleted((data) => {
      // Si une action a fonctionné, les permissions sont 100% fonctionnelles
      config.permissionsConfirmed = true;
      updatePermissionsUI({ screen: true, accessibility: true });
      window.rubricAPI.saveConfig({ permissionsConfirmed: true });

      if (data.answerDigit) {
        animateLedPulses(data.answerDigit, 200, 2, 1000);
      }
    });

    window.rubricAPI.onSearchesUpdated((data) => {
      if (typeof data === 'object') {
        const isMax = data.plan === 'Max';
        const isPro = data.plan === 'Pro';
        const isPaid = isPro || isMax;
        const defaultQuota = isMax ? 1500 : (isPro ? 500 : 3);
        if (statusUsedValue) statusUsedValue.textContent = `${data.usedThisMonth || 0} / ${data.searchesMax || defaultQuota}`;
        if (statusCreditsValue) {
          statusCreditsValue.textContent = String(data.searchesLeft !== undefined ? data.searchesLeft : defaultQuota);
          statusCreditsValue.style.color = (data.searchesLeft > 0) ? '#34c759' : '#ef4444';
        }
        if (statusPlanValue) statusPlanValue.textContent = data.plan || 'Pro';

        if (rowGeneralSearches) {
          rowGeneralSearches.style.display = isPaid ? 'none' : 'flex';
        }
        if (dividerGeneralSearches) {
          dividerGeneralSearches.style.display = isPaid ? 'none' : 'block';
        }
        if (!isPaid && generalSearchesBadge) {
          generalSearchesBadge.textContent = `${data.usedThisMonth || 0} / ${data.searchesMax || 3}`;
        }
      } else {
        if (statusCreditsValue) statusCreditsValue.textContent = String(data);
      }
    });

    // Live capture size update from overlay
    window.rubricAPI.onCaptureSizeUpdated(({ width, height }) => {
      config.captureWidth = width;
      config.captureHeight = height;
      if (inputCaptureWidth) inputCaptureWidth.value = width;
      if (inputCaptureHeight) inputCaptureHeight.value = height;
    });

    // Sync configuration updates (e.g. mode changed from menu bar tray)
    if (window.rubricAPI.onConfigUpdated) {
      window.rubricAPI.onConfigUpdated((newConfig) => {
        config = { ...config, ...newConfig };
        if (newConfig.responseMode) {
          updateModeButtonUI();
        }
        if (newConfig.shortcutDisplay) {
          updateShortcutUI(newConfig.shortcutDisplay);
        }
      });
    }
  }
});
