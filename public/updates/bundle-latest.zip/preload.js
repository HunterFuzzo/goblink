const { contextBridge, ipcRenderer } = require('electron');

const api = {
  getConfig: () => ipcRenderer.invoke('get-config'),
  saveConfig: (cfg) => ipcRenderer.invoke('save-config', cfg),
  testCapsLock: (params) => ipcRenderer.invoke('test-caps-lock', params),
  testHapticFeedback: (digits) => ipcRenderer.invoke('test-haptic-feedback', digits),
  testHudFeedback: (digits) => ipcRenderer.invoke('test-hud-feedback', digits),
  testMenuBarBadge: (digits) => ipcRenderer.invoke('test-menubar-badge', digits),
  testIphoneHaptic: (params) => ipcRenderer.invoke('test-iphone-haptic', params),
  getAvailableSymbols: () => ipcRenderer.invoke('get-available-symbols'),
  triggerAction: (customQuestion) => ipcRenderer.invoke('trigger-action', customQuestion),
  testApiConnection: () => ipcRenderer.invoke('test-api-connection'),
  openZoneConfig: () => ipcRenderer.invoke('open-zone-config'),

  // Logs & Traffic API
  openLogWindow: () => ipcRenderer.invoke('open-log-window'),
  getLogs: () => ipcRenderer.invoke('get-logs'),
  clearLogs: () => ipcRenderer.invoke('clear-logs'),
  setLogAlwaysOnTop: (val) => ipcRenderer.invoke('set-log-always-on-top', val),

  // Permissions API
  getPermissions: () => ipcRenderer.invoke('get-permissions'),
  requestPermission: (type) => ipcRenderer.invoke('request-permission', type),
  onPermissionsUpdated: (cb) => ipcRenderer.on('permissions-updated', (_e, data) => cb(data)),

  // Support & Tickets API
  submitSupportTicket: (ticket) => ipcRenderer.invoke('submit-support-ticket', ticket),
  getActiveTicket: () => ipcRenderer.invoke('get-active-ticket'),
  checkTicketStatus: () => ipcRenderer.invoke('check-ticket-status'),
  sendTicketReply: (message) => ipcRenderer.invoke('send-ticket-reply', message),
  closeActiveTicket: () => ipcRenderer.invoke('close-active-ticket'),
  setDiscordWebhook: (url) => ipcRenderer.invoke('set-discord-webhook', url),
  onTicketStatusUpdated: (cb) => ipcRenderer.on('ticket-status-updated', (_e, data) => cb(data)),

  // User Accounts & Anti-Sharing Session API
  authSendCode: (email) => ipcRenderer.invoke('auth-send-code', email),
  authVerifyCode: (params) => ipcRenderer.invoke('auth-verify-code', params),
  authHeartbeat: () => ipcRenderer.invoke('auth-heartbeat'),
  authLogout: () => ipcRenderer.invoke('auth-logout'),
  authGetSession: () => ipcRenderer.invoke('auth-get-session'),
  onSessionInvalidated: (cb) => ipcRenderer.on('session-invalidated', (_e, data) => cb(data)),

  // Legacy License API (mapped to Account state)
  getLicenseInfo: () => ipcRenderer.invoke('get-license-info'),
  activateLicense: (key) => ipcRenderer.invoke('activate-license', key),
  unlinkDevice: () => ipcRenderer.invoke('unlink-device'),

  // Stripe Subscription API (Redirects / Portal)
  startStripeCheckout: (plan = 'Pro', interval = 'yearly') => ipcRenderer.invoke('start-stripe-checkout', plan, interval),
  checkStripeSubscription: () => ipcRenderer.invoke('check-stripe-subscription'),
  openCustomerPortal: () => ipcRenderer.invoke('open-customer-portal'),

  // Listeners
  onLogEvent: (cb) => ipcRenderer.on('log-event', (_e, data) => cb(data)),
  onActionStarted: (cb) => ipcRenderer.on('action-started', (_e, data) => cb(data)),
  onActionCompleted: (cb) => ipcRenderer.on('action-completed', (_e, data) => cb(data)),
  onActionError: (cb) => ipcRenderer.on('action-error', (_e, err) => cb(err)),
  onSearchesUpdated: (cb) => ipcRenderer.on('searches-updated', (_e, count) => cb(count)),
  onCaptureSizeUpdated: (cb) => ipcRenderer.on('capture-size-updated', (_e, data) => cb(data)),
  onConfigUpdated: (cb) => ipcRenderer.on('config-updated', (_e, data) => cb(data)),
  onSubscriptionActivated: (cb) => ipcRenderer.on('subscription-activated', (_e, data) => cb(data)),
  onPlanUpdated: (cb) => ipcRenderer.on('plan-updated', (_e, data) => cb(data)),

  // Auto-Update OTA API
  checkAppUpdates: () => ipcRenderer.invoke('check-app-updates'),
  restartToApplyUpdate: () => ipcRenderer.invoke('restart-to-apply-update'),
  onUpdateStatus: (cb) => ipcRenderer.on('ota-update-status', (_e, data) => cb(data)),
  onUpdateApplied: (cb) => ipcRenderer.on('ota-update-applied', (_e, data) => cb(data)),

  // Support & Admin Ticketing
  adminGetTickets: () => ipcRenderer.invoke('admin-get-tickets'),
  adminReplyTicket: (data) => ipcRenderer.invoke('admin-reply-ticket', data),
  adminResolveTicket: (ticketId) => ipcRenderer.invoke('admin-resolve-ticket', ticketId),
  adminReopenTicket: (ticketId) => ipcRenderer.invoke('admin-reopen-ticket', ticketId)
};

contextBridge.exposeInMainWorld('blinkAPI', api);
contextBridge.exposeInMainWorld('rubricAPI', api);
