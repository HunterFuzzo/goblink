const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('overlayAPI', {
  updateSize: (data) => ipcRenderer.send('update-capture-size-live', data),
  finish: () => ipcRenderer.send('close-capture-overlay')
});
