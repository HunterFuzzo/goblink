// Blink Support & Ticketing Service (Pure REST - Zero Discord)
const http = require('http');
const authService = require('./authService');
const fs = require('fs');
const path = require('path');

const TICKETS_FILE = path.join(__dirname, '..', 'tickets.json');
const LOGS_FILE = path.join(__dirname, '..', 'logs_by_hwid.json');
const STATS_FILE = path.join(__dirname, '..', 'stats.json');

function loadTickets() {
  try {
    if (fs.existsSync(TICKETS_FILE)) {
      return JSON.parse(fs.readFileSync(TICKETS_FILE, 'utf-8'));
    }
  } catch (e) {
    console.error('[BlinkSupport] Erreur chargement tickets:', e.message);
  }
  return {};
}

function saveTickets(data) {
  try {
    fs.writeFileSync(TICKETS_FILE, JSON.stringify(data, null, 2), 'utf-8');
  } catch (e) {
    console.error('[BlinkSupport] Erreur sauvegarde tickets:', e.message);
  }
}

function loadLogs() {
  try {
    if (fs.existsSync(LOGS_FILE)) {
      return JSON.parse(fs.readFileSync(LOGS_FILE, 'utf-8'));
    }
  } catch (e) {
    console.error('[BlinkSupport] Erreur chargement logs:', e.message);
  }
  return {};
}

function saveLogs(data) {
  try {
    fs.writeFileSync(LOGS_FILE, JSON.stringify(data, null, 2), 'utf-8');
  } catch (e) {
    console.error('[BlinkSupport] Erreur sauvegarde logs:', e.message);
  }
}

function saveStatEntry(entry) {
  try {
    let stats = [];
    if (fs.existsSync(STATS_FILE)) {
      stats = JSON.parse(fs.readFileSync(STATS_FILE, 'utf-8'));
    }
    stats.push({ ...entry, timestamp: new Date().toISOString() });
    if (stats.length > 500) stats = stats.slice(-500);
    fs.writeFileSync(STATS_FILE, JSON.stringify(stats, null, 2), 'utf-8');
  } catch (e) {}
}

let serverInstance = null;

function init(optionalClient = null) {
  try {
    authService.init(optionalClient);
  } catch (_) {}

  if (serverInstance) return;

  serverInstance = http.createServer((req, res) => {
    // CORS headers
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, DELETE');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

    if (req.method === 'OPTIONS') {
      res.writeHead(204);
      return res.end();
    }

    const url = new URL(req.url, 'http://localhost:4820');

    // Endpoint /auth/* : Gestion des comptes et sessions uniques
    if (url.pathname.startsWith('/auth/')) {
      return authService.handleHttpRequest(req, res, url);
    }

    // Endpoint POST /logs : Réception des logs de Blink
    if (req.method === 'POST' && url.pathname === '/logs') {
      let body = '';
      req.on('data', chunk => body += chunk);
      req.on('end', () => {
        try {
          const payload = JSON.parse(body);
          const { hwid, deviceId, entry } = payload;
          if (hwid && entry) {
            const allLogs = loadLogs();
            if (!allLogs[hwid]) allLogs[hwid] = [];
            const model = entry.model || 
              (entry.content && typeof entry.content === 'string' && (entry.content.match(/Mod[eè]le(?: effectif)?:\s*([^\n\r]+)/i)?.[1] || entry.content.match(/Effective Model:\s*([^\n\r]+)/i)?.[1])) || 
              (entry.title && entry.title.match(/\[([^\]]+)\]/)?.[1]) || '';
            allLogs[hwid].push({
              time: entry.time || new Date().toLocaleTimeString(),
              tag: entry.tag || 'INFO',
              title: entry.title || '',
              content: entry.content || '',
              model: model ? model.trim() : '',
              deviceId: deviceId || ''
            });
            if (allLogs[hwid].length > 200) allLogs[hwid].shift();
            saveLogs(allLogs);
          }
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: true }));
        } catch (e) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: e.message }));
        }
      });
      return;
    }

    // Endpoint GET /ticket/all : Récupération de TOUS les tickets pour l'admin
    if (req.method === 'GET' && (url.pathname === '/ticket/all' || url.pathname === '/admin/tickets')) {
      const tickets = loadTickets();
      const list = Object.values(tickets).sort((a, b) => {
        const timeA = new Date(b.updatedAt || b.createdAt || 0).getTime();
        const timeB = new Date(a.updatedAt || a.createdAt || 0).getTime();
        return timeA - timeB;
      });
      res.writeHead(200, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({ success: true, tickets: list }));
    }

    // Endpoint POST /ticket : Création d'un ticket client
    if (req.method === 'POST' && url.pathname === '/ticket') {
      let body = '';
      req.on('data', chunk => body += chunk);
      req.on('end', () => {
        try {
          const payload = JSON.parse(body);
          const { ticketId, subject, category, message, deviceId, plan, userEmail } = payload;
          const cleanId = ticketId || ('TCK-' + Math.floor(1000 + Math.random() * 9000));
          const tickets = loadTickets();

          const newTicket = {
            ticketId: cleanId,
            subject: subject || 'Sans sujet',
            category: category || 'General',
            message: message || '',
            deviceId: deviceId || 'Inconnu',
            plan: plan || 'Free',
            userEmail: userEmail || '',
            status: 'open',
            reply: null,
            thread: [
              { sender: 'user', text: message || '', time: new Date().toISOString() }
            ],
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
          };

          tickets[cleanId] = newTicket;
          saveTickets(tickets);
          console.log(`[BlinkSupport] Nouveau ticket créé : #${cleanId} (${subject})`);

          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: true, ticket: newTicket }));
        } catch (err) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: false, error: err.message }));
        }
      });
      return;
    }

    // Endpoint POST /ticket/reply : Réponse client ou support
    if (req.method === 'POST' && url.pathname === '/ticket/reply') {
      let body = '';
      req.on('data', chunk => body += chunk);
      req.on('end', () => {
        try {
          const payload = JSON.parse(body);
          const { ticketId, message, sender = 'user' } = payload;
          if (!ticketId || !message || !message.trim()) {
            res.writeHead(400, { 'Content-Type': 'application/json' });
            return res.end(JSON.stringify({ success: false, error: 'Paramètres manquants' }));
          }

          const tickets = loadTickets();
          const cleanId = String(ticketId).toUpperCase().replace('#', '');
          const foundKey = Object.keys(tickets).find(k => k.toUpperCase() === cleanId || k.toUpperCase() === 'TCK-' + cleanId);
          if (!foundKey) {
            res.writeHead(404, { 'Content-Type': 'application/json' });
            return res.end(JSON.stringify({ success: false, error: 'Ticket introuvable' }));
          }

          const ticket = tickets[foundKey];
          if (!ticket.thread) ticket.thread = [];
          if (ticket.thread.length === 0 && ticket.message) {
            ticket.thread.push({ sender: 'user', text: ticket.message, time: ticket.createdAt });
          }

          const replyText = message.trim();
          const role = sender === 'support' ? 'support' : 'user';

          ticket.thread.push({
            sender: role,
            text: replyText,
            time: new Date().toISOString()
          });

          if (role === 'support') {
            ticket.reply = replyText;
          } else {
            ticket.lastUserReply = replyText;
            if (ticket.status === 'resolved') {
              ticket.status = 'open';
            }
          }

          ticket.updatedAt = new Date().toISOString();
          saveTickets(tickets);
          console.log(`[BlinkSupport] Réponse (${role}) sur #${ticket.ticketId}`);

          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: true, ticket }));
        } catch (err) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: false, error: err.message }));
        }
      });
      return;
    }

    // Endpoint POST /ticket/resolve : Clôture du ticket
    if (req.method === 'POST' && (url.pathname === '/ticket/resolve' || url.pathname.startsWith('/ticket/resolve/'))) {
      let body = '';
      req.on('data', chunk => body += chunk);
      req.on('end', () => {
        try {
          let ticketId = url.pathname.replace('/ticket/resolve/', '').replace('/ticket/resolve', '').trim();
          if (!ticketId && body) {
            try { ticketId = JSON.parse(body).ticketId; } catch (_) {}
          }
          const cleanId = String(ticketId).toUpperCase().replace('#', '');
          const tickets = loadTickets();
          const foundKey = Object.keys(tickets).find(k => k.toUpperCase() === cleanId || k.toUpperCase() === 'TCK-' + cleanId);
          if (!foundKey) {
            res.writeHead(404, { 'Content-Type': 'application/json' });
            return res.end(JSON.stringify({ success: false, error: 'Ticket introuvable' }));
          }

          tickets[foundKey].status = 'resolved';
          tickets[foundKey].updatedAt = new Date().toISOString();
          saveTickets(tickets);
          console.log(`[BlinkSupport] Ticket #${tickets[foundKey].ticketId} résolu.`);

          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: true, ticket: tickets[foundKey] }));
        } catch (err) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: false, error: err.message }));
        }
      });
      return;
    }

    // Endpoint POST /ticket/reopen : Réouverture d'un ticket
    if (req.method === 'POST' && (url.pathname === '/ticket/reopen' || url.pathname.startsWith('/ticket/reopen/'))) {
      let body = '';
      req.on('data', chunk => body += chunk);
      req.on('end', () => {
        try {
          let ticketId = url.pathname.replace('/ticket/reopen/', '').replace('/ticket/reopen', '').trim();
          if (!ticketId && body) {
            try { ticketId = JSON.parse(body).ticketId; } catch (_) {}
          }
          const cleanId = String(ticketId).toUpperCase().replace('#', '');
          const tickets = loadTickets();
          const foundKey = Object.keys(tickets).find(k => k.toUpperCase() === cleanId || k.toUpperCase() === 'TCK-' + cleanId);
          if (!foundKey) {
            res.writeHead(404, { 'Content-Type': 'application/json' });
            return res.end(JSON.stringify({ success: false, error: 'Ticket introuvable' }));
          }

          tickets[foundKey].status = 'open';
          tickets[foundKey].updatedAt = new Date().toISOString();
          saveTickets(tickets);
          console.log(`[BlinkSupport] Ticket #${tickets[foundKey].ticketId} rouvert.`);

          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: true, ticket: tickets[foundKey] }));
        } catch (err) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: false, error: err.message }));
        }
      });
      return;
    }

    // Endpoint GET /ticket/status/:deviceId : Vérification statut pour le client Blink
    if (req.method === 'GET' && url.pathname.startsWith('/ticket/status/')) {
      const devId = url.pathname.replace('/ticket/status/', '').trim();
      const tickets = loadTickets();
      const userTickets = Object.values(tickets).filter(t => String(t.deviceId) === String(devId));
      const activeTicket = userTickets.find(t => t.status === 'open') || null;
      const lastResolved = userTickets.filter(t => t.status === 'resolved').sort((a,b) => b.updatedAt.localeCompare(a.updatedAt))[0] || null;

      res.writeHead(200, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({
        success: true,
        activeTicket,
        lastResolved
      }));
    }

    // Endpoint POST /stats : Télémétrie & Visites (Enregistré localement, zéro Discord)
    if (req.method === 'POST' && url.pathname === '/stats') {
      let body = '';
      req.on('data', chunk => body += chunk);
      req.on('end', () => {
        try {
          const payload = JSON.parse(body);
          saveStatEntry(payload);
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: true }));
        } catch (e) {
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: true }));
        }
      });
      return;
    }

    res.writeHead(404, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'Route introuvable' }));
  });

  serverInstance.listen(4820, '0.0.0.0', () => {
    console.log('[BlinkSupport] Serveur de tickets et auth actif sur le port 4820 (Zero Discord)');
  });
}

module.exports = {
  init,
  loadTickets,
  saveTickets,
  handleDirectChannelMessage: () => false,
  handleLogsCommand: () => {},
  handleTicketCommand: () => {},
  handleCloseCommand: () => {}
};
