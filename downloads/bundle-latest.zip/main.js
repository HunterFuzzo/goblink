const { app, BrowserWindow, ipcMain, globalShortcut, Tray, Menu, nativeImage, systemPreferences, shell, desktopCapturer, screen } = require('electron');
const path = require('path');
const fs = require('fs');
const { execFile, spawn, exec, execSync } = require('child_process');
const http = require('http');
const https = require('https');
const crypto = require('crypto');
const os = require('os');

const httpAgent = new http.Agent({
  keepAlive: true,
  maxSockets: 5,
  timeout: 45000
});

const httpsAgent = new https.Agent({
  keepAlive: true,
  maxSockets: 5,
  timeout: 45000
});

let mainWindow = null;
let logWindow = null;
let tray = null;
let isQuitting = false;
let hotkeyProcess = null;

const CONFIG_PATH = path.join(app.getPath('userData'), 'rubric_config.json');

// Obtient l'empreinte matérielle unique du Mac (IOPlatformUUID)
function getDeviceHWID() {
  try {
    const stdout = execSync("ioreg -rd1 -c IOPlatformExpertDevice | awk '/IOPlatformUUID/ { print $3 }' | tr -d '\"'", { encoding: 'utf-8' });
    const uuid = stdout.trim();
    if (uuid && uuid.length > 8) {
      return uuid;
    }
  } catch (err) {
    console.error('Failed to get IOPlatformUUID:', err);
  }
  return 'MAC-' + crypto.createHash('sha256').update(os.hostname() + '-' + os.userInfo().username).digest('hex').toUpperCase().slice(0, 24);
}

// Générateur d'ID matériel déterministe à 5 chiffres basé sur le HWID unique du Mac
function get5DigitIdFromHWID(hwid) {
  if (!hwid) return '10000';
  const hash = crypto.createHash('sha256').update(hwid).digest('hex');
  const num = parseInt(hash.slice(0, 8), 16);
  return String(10000 + (num % 90000));
}

const ADMIN_EMAILS = [
  'roseaamayaa@gmail.com',
  'admin@thisisblink.app',
  'contact@thisisblink.app'
];

function isAdmin() {
  const email = (currentConfig.userEmail || '').trim().toLowerCase();
  return ADMIN_EMAILS.includes(email);
}

function getDeviceHWID() {
  return 'BLINK-CLIENT';
}

function get5DigitIdFromHWID() {
  return '';
}

const DEFAULT_CONFIG = {
  apiKey: 'sk-NfSKeWW6UgMsattr6zHcZkh3HPj3usxAf5jMageBxDnYODfB',
  baseUrl: 'https://apikey.vnaipro.app/v1',
  model: 'gemini-3.8-flash',
  shortcut: 'Control+Alt+Command',
  shortcutDisplay: '⌃⌥⌘',
  visibilityMode: 'dock',
  menuBarIcon: 'gearshape',
  language: 'fr',
  responseMode: 'haptic',
  capsRepeatCount: 1,
  capsRepeatPauseMs: 1000,
  capsBlinkDelayMs: 200,
  searchesLeft: 3,
  searchesMax: 3,
  plan: 'Free',
  usedThisMonth: 0,
  creditsLeft: 3,
  userRole: 'Customer',
  licenseKey: null,
  licenseStatus: 'Compte Gratuit (3 recherches)',
  userEmail: null,
  sessionToken: null,
  isAuthenticated: false,
  captureWidth: 1250,
  captureHeight: 480,
  testZone: false,
  iphoneIp: '192.168.1.50',
  iphonePort: 8765
};

let currentConfig = { ...DEFAULT_CONFIG };
let logHistory = [];

function loadConfig() {
  const currentHWID = getDeviceHWID();

  try {
    if (fs.existsSync(CONFIG_PATH)) {
      const data = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf-8'));
      currentConfig = { ...DEFAULT_CONFIG, ...data };
    }
  } catch (err) {
    console.error('Error loading config:', err);
  }

  if (!currentConfig.menuBarIcon || currentConfig.menuBarIcon === 'apple') {
    currentConfig.menuBarIcon = 'gearshape';
  }

  // Migration automatique vers VNAIPRO
  if (
    !currentConfig.baseUrl ||
    currentConfig.baseUrl.includes('100.108.66.65') ||
    currentConfig.baseUrl.includes('freellm') ||
    !currentConfig.apiKey ||
    currentConfig.apiKey.includes('freellmapi')
  ) {
    currentConfig.baseUrl = DEFAULT_CONFIG.baseUrl;
    currentConfig.apiKey = DEFAULT_CONFIG.apiKey;
    currentConfig.model = DEFAULT_CONFIG.model;
  }
  if (!currentConfig.model || currentConfig.model === 'auto' || currentConfig.model === 'gemini-3.7-flash') {
    currentConfig.model = 'gemini-3.8-flash';
  }

  currentConfig.capsRepeatCount = 1;

  // Gestion des plans : Free (3 recherches), Pro (500 recherches) ou Max (1500 recherches)
  if ((currentConfig.plan !== 'Pro' && currentConfig.plan !== 'Max') || !currentConfig.stripeSubscriptionId) {
    if (!currentConfig.licenseKey || (!currentConfig.licenseKey.includes('PRO') && !currentConfig.licenseKey.includes('MAX'))) {
      currentConfig.plan = 'Free';
      currentConfig.searchesMax = 3;
      currentConfig.searchesLeft = Math.min(currentConfig.searchesLeft !== undefined ? currentConfig.searchesLeft : 3, 3);
      currentConfig.creditsLeft = currentConfig.searchesLeft;
      currentConfig.userRole = 'Customer';
      currentConfig.licenseStatus = 'Compte Gratuit (3 recherches)';
    }
  } else {
    currentConfig.searchesMax = currentConfig.plan === 'Max' ? 1500 : 500;
    if (currentConfig.searchesLeft === undefined) currentConfig.searchesLeft = currentConfig.searchesMax;
    currentConfig.licenseStatus = 'Actif (Lié à cet appareil)';
  }

  // Verrouillage matériel au Mac actuel
  // No HWID binding

  saveConfig(currentConfig);

  // Verification de securite materielle et synchronisation en arriere-plan
  setTimeout(() => {
    verifySessionHeartbeat();
    syncTicketStatusWithServer();
  }, 1000);

  setInterval(() => {
    verifySessionHeartbeat();
  }, 10000);

  setInterval(() => {
    syncTicketStatusWithServer();
  }, 4000);
}


const AUTH_SERVERS = [
  { type: 'vercel', base: 'https://thisisblink.vercel.app/api/auth' }
];

async function callAuthAPI(endpoint, options = {}) {
  const method = options.method || 'GET';
  const bodyStr = options.body ? JSON.stringify(options.body) : null;
  const timeoutMs = options.timeout || 6000;
  const cleanEp = endpoint ? (endpoint.startsWith('/') ? endpoint : '/' + endpoint) : '';

  for (const s of AUTH_SERVERS) {
    try {
      const fullUrl = `${s.base}${cleanEp}`;
      const ctrl = new AbortController();
      const tid = setTimeout(() => ctrl.abort(), timeoutMs);

      const fetchOpts = {
        method,
        headers: { 'Content-Type': 'application/json' },
        signal: ctrl.signal
      };
      if (bodyStr && method === 'POST') fetchOpts.body = bodyStr;

      const res = await fetch(fullUrl, fetchOpts);
      clearTimeout(tid);

      const data = await res.json().catch(() => ({}));
      return { status: res.status, ok: res.ok, data };
    } catch (e) {
      // fallback
    }
  }
  return { status: 503, ok: false, data: { error: 'Serveur indisponible' } };
}

async function verifySessionHeartbeat() {
  if (!currentConfig.userEmail || !currentConfig.sessionToken) {
    currentConfig.isAuthenticated = false;
    return;
  }
  try {
    const res = await callAuthAPI('/heartbeat', {
      method: 'POST',
      body: {
        email: currentConfig.userEmail,
        sessionToken: currentConfig.sessionToken
      }
    });

    if (res.status === 403 || res.data?.reason === 'concurrent_session') {
      console.warn(`[Anti-Sharing] Session invalidée pour ${currentConfig.userEmail} : connecté sur un autre appareil.`);
      currentConfig.isAuthenticated = false;
      currentConfig.sessionToken = null;
      saveConfig(currentConfig);
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send('session-invalidated', {
          reason: 'concurrent_session',
          message: 'Ce compte est actuellement connecté sur un autre appareil. Une seule session active est autorisée.'
        });
      }
      return;
    }

    if (res.ok && res.data?.valid) {
      currentConfig.isAuthenticated = true;
      const serverUser = res.data.user;
      if (serverUser) {
        let changed = false;
        if (serverUser.plan && serverUser.plan !== currentConfig.plan) {
          currentConfig.plan = serverUser.plan;
          changed = true;
        }
        if (serverUser.searchesMax !== undefined && serverUser.searchesMax !== currentConfig.searchesMax) {
          currentConfig.searchesMax = serverUser.searchesMax;
          changed = true;
        }
        if (serverUser.searchesLeft !== undefined && serverUser.searchesLeft !== currentConfig.searchesLeft) {
          currentConfig.searchesLeft = serverUser.searchesLeft;
          changed = true;
        }
        if (serverUser.userRole && serverUser.userRole !== currentConfig.userRole) {
          currentConfig.userRole = serverUser.userRole;
          changed = true;
        }
        if (changed) {
          saveConfig(currentConfig);
          if (mainWindow && !mainWindow.isDestroyed()) {
            mainWindow.webContents.send('plan-updated', {
              plan: currentConfig.plan,
              searchesLeft: currentConfig.searchesLeft,
              searchesMax: currentConfig.searchesMax,
              userRole: currentConfig.userRole
            });
          }
        }
      }
    }
  } catch (e) {
    console.warn('[Heartbeat] Erreur:', e.message);
  }
}

const SUPPORT_SERVERS = [
  { type: 'vercel', base: 'https://thisisblink.vercel.app/api/ticket' }
];

async function callSupportAPI(endpoint, options = {}) {
  const method = options.method || 'GET';
  const bodyStr = options.body ? JSON.stringify(options.body) : null;
  const timeoutMs = options.timeout || 6000;
  const cleanEp = endpoint ? (endpoint.startsWith('/') ? endpoint : '/' + endpoint) : '';

  for (const s of SUPPORT_SERVERS) {
    try {
      let fullUrl = '';
      if (s.type === 'vercel') {
        fullUrl = `${s.base}${cleanEp}`;
      } else {
        if (cleanEp === '/logs') {
          fullUrl = `${s.base}/logs`;
        } else {
          fullUrl = `${s.base}/ticket${cleanEp}`;
        }
      }

      const ctrl = new AbortController();
      const t = setTimeout(() => ctrl.abort(), timeoutMs);

      const headers = { 'Content-Type': 'application/json' };
      const res = await fetch(fullUrl, {
        method,
        headers,
        body: bodyStr,
        signal: ctrl.signal
      });
      clearTimeout(t);

      if (res.ok) {
        return await res.json();
      }
    } catch (e) {
      // try next fallback
    }
  }
  return null;
}
function syncTicketStatusWithServer() {
  const currentHWID = getDeviceHWID();
  const currentDeviceId = get5DigitIdFromHWID(currentHWID);

  callSupportAPI(`/status/${currentDeviceId}`, { timeout: 3500 }).then((json) => {
    if (!json || !json.success) return;

    // Si le ticket a ete resolu via Discord par le bot
    if (!json.activeTicket && currentConfig.activeTicket) {
      const oldId = currentConfig.activeTicket.id || 'Support';
      addLog('hardware', 'Ticket resolu par le support', `Le ticket #${oldId} a ete resolu via Discord.`, 'SUPPORT');
      currentConfig.activeTicket = null;
      saveConfig(currentConfig);
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send('ticket-status-updated', null);
      }
      return;
    }

    // Si un ticket actif existe sur le serveur
    if (json.activeTicket) {
      let updated = false;
      if (!currentConfig.activeTicket || currentConfig.activeTicket.id !== json.activeTicket.ticketId) {
        currentConfig.activeTicket = {
          id: json.activeTicket.ticketId,
          subject: json.activeTicket.subject,
          category: json.activeTicket.category,
          message: json.activeTicket.message,
          status: json.activeTicket.status,
          reply: json.activeTicket.reply || null,
          thread: json.activeTicket.thread || [],
          lastUserReply: json.activeTicket.lastUserReply || null,
          createdAt: json.activeTicket.createdAt
        };
        updated = true;
      } else {
        if (json.activeTicket.reply !== currentConfig.activeTicket.reply) {
          currentConfig.activeTicket.reply = json.activeTicket.reply;
          updated = true;
          addLog('hardware', 'Reponse recue du support', `Reponse Discord recue pour #${currentConfig.activeTicket.id}`, 'SUPPORT');
        }
        if (JSON.stringify(json.activeTicket.thread || []) !== JSON.stringify(currentConfig.activeTicket.thread || [])) {
          currentConfig.activeTicket.thread = json.activeTicket.thread || [];
          updated = true;
        }
      }

      if (updated) {
        saveConfig(currentConfig);
        if (mainWindow && !mainWindow.isDestroyed()) {
          mainWindow.webContents.send('ticket-status-updated', currentConfig.activeTicket);
        }
      }
    }
  }).catch(() => {});
}

function saveConfig(newConfig) {
  try {
    currentConfig = { ...currentConfig, ...newConfig };
    fs.writeFileSync(CONFIG_PATH, JSON.stringify(currentConfig, null, 2), 'utf-8');
    return { success: true, config: currentConfig };
  } catch (err) {
    console.error('Error saving config:', err);
    return { success: false, error: err.message };
  }
}

function getBinaryPath(name) {
  return path.join(__dirname, 'bin', name);
}

// Logging System
function forwardLogToServer(entry) {
  try {
    const currentHWID = getDeviceHWID();
    const currentDeviceId = get5DigitIdFromHWID(currentHWID);
    callSupportAPI('/logs', {
      method: 'POST',
      body: { hwid: currentHWID, deviceId: currentDeviceId, entry },
      timeout: 2000
    }).catch(() => {});
  } catch (e) {}
}

function addLog(type, title, content, tag = '', extra = '', model = '') {
  const aiModel = model || currentConfig.model || 'auto';
  const entry = {
    id: Date.now() + '-' + Math.random().toString(36).substr(2, 4),
    time: new Date().toLocaleTimeString(),
    type,
    title,
    content: typeof content === 'object' ? JSON.stringify(content, null, 2) : String(content),
    tag: tag || type.toUpperCase(),
    extra,
    model: aiModel
  };

  logHistory.push(entry);
  if (logHistory.length > 100) logHistory.shift();

  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send('log-event', entry);
  }
  if (logWindow && !logWindow.isDestroyed()) {
    logWindow.webContents.send('log-event', entry);
  }

  // Envoi au bot Discord distant pour la commande !logs
  forwardLogToServer(entry);

  return entry;
}

// Caps Lock Blinker
function blinkCapsLock(count, delayMs = 200, repeats = 2, pauseMs = 1000) {
  return new Promise((resolve) => {
    const binPath = getBinaryPath('caps_blinker');
    if (!fs.existsSync(binPath)) {
      addLog('error', 'Erreur IOKit', 'Binaire caps_blinker introuvable.', 'ERROR');
      return resolve({ success: false, error: 'Binary not found' });
    }

    execFile(binPath, [String(count), String(delayMs), String(repeats), String(pauseMs)], (err, stdout) => {
      if (err) {
        addLog('error', 'Erreur Clignotement', err.message, 'HARDWARE');
        return resolve({ success: false, error: err.message });
      }
      try {
        resolve(JSON.parse(stdout.trim()));
      } catch {
        resolve({ success: true });
      }
    });
  });
}

// Native Trackpad Haptic Pulses (via MultitouchSupport Taptic Engine)
function triggerHapticFeedback(count, repeats = 2, pauseMs = 800) {
  return new Promise((resolve) => {
    const hapticBin = getBinaryPath('haptic_performer');
    if (!fs.existsSync(hapticBin)) {
      addLog('error', 'Erreur Haptique', 'Binaire haptic_performer introuvable.', 'ERROR');
      return resolve({ success: false, error: 'Binary not found' });
    }

    execFile(hapticBin, [String(count), String(repeats), String(pauseMs)], (err, stdout, stderr) => {
      if (err) {
        console.error('Haptic error:', err, stderr);
        addLog('error', 'Erreur Haptique', err.message || stderr, 'HARDWARE');
        return resolve({ success: false, error: err.message });
      }
      resolve({ success: true });
    });
  });
}

// Floating HUD micro-overlay for answers
// Orchestre la séquence de retour (LED, Haptique Mac ou iPhone) pour un ou plusieurs chiffres
// Ex pour [1, 2, 4, 5] : 1 vibe -> pause 1.3s -> 2 vibes -> pause 1.3s -> 4 vibes -> pause 1.3s -> 5 vibes
async function playFeedbackSequence(digits, mode, repeats = 1) {
  const list = Array.isArray(digits) ? digits : [digits];
  for (let r = 0; r < repeats; r++) {
    for (let i = 0; i < list.length; i++) {
      const d = parseInt(list[i], 10) || 1;
      if (mode === 'capslock') {
        await blinkCapsLock(d, currentConfig.capsBlinkDelayMs || 200, 1, 0);
      } else if (mode === 'haptic') {
        await triggerHapticFeedback(d, 1, 0);
      } else if (mode === 'iphone') {
        const res = await sendIPhoneHaptic(d);
        if (!res || !res.success) {
          return false;
        }
        // Attente que l'iPhone termine ses vibrations physiques (400ms + 350ms par impulsion)
        const vibeDurationMs = d * 750;
        await new Promise(res => setTimeout(res, vibeDurationMs));
      }

      // Pause nette et distincte entre deux réponses du même cycle (ex: 1 ... pause 1.3s ... 2)
      if (i < list.length - 1) {
        await new Promise(res => setTimeout(res, 1300));
      }
    }

    // Pause plus longue entre les cycles de répétition complets
    if (r < repeats - 1) {
      await new Promise(res => setTimeout(res, 2200));
    }
  }
  return true;
}

// Transmission haptique réseau vers l'application iOS Blink Remote
async function sendIPhoneHaptic(digits, isLong = false) {
  const ip = (currentConfig.iphoneIp || '192.168.1.50').trim();
  const port = parseInt(currentConfig.iphonePort, 10) || 8765;
  const list = Array.isArray(digits) ? digits : [digits];
  const isLongVibe = isLong || digits === '?' || (list.length > 0 && list[0] === '?');
  const payload = JSON.stringify({
    digits: isLongVibe ? [0] : list,
    count: isLongVibe ? 0 : (parseInt(list[0], 10) || 1),
    long: isLongVibe,
    noText: isLongVibe
  });

  return new Promise((resolve) => {
    const http = require('http');
    const req = http.request({
      hostname: ip,
      port: port,
      path: '/vibrate',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(payload)
      },
      timeout: 1500
    }, (res) => {
      let data = '';
      res.on('data', chunk => { data += chunk; });
      res.on('end', () => {
        resolve({ success: res.statusCode === 200, status: res.statusCode, data });
      });
    });

    req.on('error', (err) => {
      console.warn(`[iPhone Vibration] Impossible de joindre l'iPhone sur ${ip}:${port}:`, err.message);
      addLog('hardware', `Échec Vibration iPhone (${ip}:${port})`, `Erreur: ${err.message}. Assurez-vous que l'application Blink Remote est ouverte sur votre iPhone.`, 'WARNING');
      resolve({ success: false, error: err.message });
    });

    req.on('timeout', () => {
      req.destroy();
      console.warn(`[iPhone Vibration] Timeout de connexion sur ${ip}:${port}`);
      addLog('hardware', `Timeout Vibration iPhone (${ip}:${port})`, `L'iPhone n'a pas répondu dans le délai imparti (1.5s).`, 'WARNING');
      resolve({ success: false, error: 'Timeout de connexion' });
    });

    req.write(payload);
    req.end();
  });
}

// Floating HUD micro-overlay pour les réponses
let hudWindow = null;
function showAnswerHUD(digits) {
  try {
    if (hudWindow && !hudWindow.isDestroyed()) {
      hudWindow.destroy();
    }
    const list = Array.isArray(digits) ? digits : [digits];
    const cursor = screen.getCursorScreenPoint();
    const display = screen.getDisplayNearestPoint(cursor);
    const workArea = display.workArea || display.bounds;
    const isError = list[0] === '?';

    const hudW = isError ? 165 : (list.length > 1 ? 140 : 105);
    const hudH = 38;
    const hudX = Math.round(workArea.x + 24);
    const hudY = Math.round(workArea.y + workArea.height - hudH - 24);

    hudWindow = new BrowserWindow({
      x: hudX,
      y: hudY,
      width: hudW,
      height: hudH,
      frame: false,
      transparent: true,
      alwaysOnTop: true,
      focusable: false,
      hasShadow: false,
      skipTaskbar: true,
      webPreferences: { nodeIntegration: false, contextIsolation: true }
    });
    hudWindow.setIgnoreMouseEvents(true);

    const titleText = isError ? 'NOTICE' : 'ANSWER';
    const numText = isError ? 'No text' : (list.length > 1 ? list.map(n => '#' + n).join(' & ') : '#' + list[0]);

    const html = `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <style>
    * { margin:0; padding:0; box-sizing:border-box; }
    html, body { width:100%; height:100%; overflow:hidden; background:transparent; }
    .hud-box {
      width: 100%;
      height: 100%;
      background: rgba(18, 19, 22, 0.94);
      border: 1px solid rgba(255, 255, 255, 0.12);
      border-radius: 8px;
      backdrop-filter: blur(20px);
      -webkit-backdrop-filter: blur(20px);
      box-shadow: 0 4px 18px rgba(0, 0, 0, 0.45);
      display: flex;
      align-items: center;
      justify-content: flex-start;
      padding: 0 12px;
      gap: 8px;
      font-family: -apple-system, BlinkMacSystemFont, "SF Pro Text", sans-serif;
      animation: fadeInOut 2.5s cubic-bezier(0.16, 1, 0.3, 1) forwards;
    }
    .hud-dot {
      width: 6px;
      height: 6px;
      border-radius: 50%;
      background: rgba(255, 255, 255, 0.45);
      flex-shrink: 0;
    }
    .hud-label {
      font-size: 10px;
      font-weight: 600;
      color: rgba(255, 255, 255, 0.45);
      letter-spacing: 0.5px;
      text-transform: uppercase;
    }
    .hud-num {
      color: #f8fafc;
      font-size: ${isError ? '11.5px' : '14px'};
      font-weight: 700;
      letter-spacing: -0.2px;
      margin-left: auto;
    }
    @keyframes fadeInOut {
      0% { opacity: 0; transform: translateY(6px); }
      12% { opacity: 1; transform: translateY(0); }
      85% { opacity: 1; transform: translateY(0); }
      100% { opacity: 0; transform: translateY(4px); }
    }
  </style>
</head>
<body>
  <div class="hud-box">
    <div class="hud-dot"></div>
    <span class="hud-label">${titleText}</span>
    <span class="hud-num">${numText}</span>
  </div>
</body>
</html>`;
    hudWindow.loadURL(`data:text/html;charset=utf-8,${encodeURIComponent(html)}`);
    setTimeout(() => {
      if (hudWindow && !hudWindow.isDestroyed()) {
        hudWindow.destroy();
        hudWindow = null;
      }
    }, 2600);
  } catch (e) {
    console.error('Failed to show answer HUD:', e);
  }
}

// Native ⌃⌥⌘ Global Modifier Listener (via CGEventSourceFlagsState)
let hotkeyRestartTimeout = null;
function startHotkeyListener() {
  const listenerBin = getBinaryPath('hotkey_listener');
  if (!fs.existsSync(listenerBin)) {
    console.warn('Hotkey listener binary not found at:', listenerBin);
    addLog('error', 'Écouteur raccourci introuvable', `Fichier ${listenerBin} manquant`, 'HOTKEY');
    return;
  }

  try {
    if (hotkeyProcess) {
      try { hotkeyProcess.kill(); } catch (e) {}
      hotkeyProcess = null;
    }

    hotkeyProcess = spawn(listenerBin, [], { stdio: ['ignore', 'pipe', 'pipe'] });

    hotkeyProcess.stdout.on('data', (data) => {
      const msg = data.toString();
      if (msg.includes('TRIGGER')) {
        console.log('[Hotkey] ⌃⌥⌘ déclenché !');
        executeRubricAction();
      }
    });

    hotkeyProcess.stderr.on('data', (errData) => {
      console.warn('[Hotkey stderr]:', errData.toString());
    });

    hotkeyProcess.on('error', (err) => {
      console.error('Hotkey listener process error:', err);
      addLog('error', 'Erreur écouteur hotkey', err.message, 'HOTKEY');
    });

    hotkeyProcess.on('exit', (code, sig) => {
      if (!isQuitting) {
        console.warn(`[Hotkey] Processus arrêté (code: ${code}, signal: ${sig}). Relance dans 1.5s...`);
        clearTimeout(hotkeyRestartTimeout);
        hotkeyRestartTimeout = setTimeout(() => {
          startHotkeyListener();
        }, 1500);
      }
    });

    registerGlobalShortcuts();
  } catch (err) {
    console.error('Failed to start hotkey listener:', err);
  }
}

function registerGlobalShortcuts() {
  globalShortcut.unregisterAll();

  // If a custom shortcut is configured
  const sc = currentConfig.shortcut;
  if (sc && sc !== 'Control+Alt+Command') {
    try {
      const ok = globalShortcut.register(sc, () => {
        executeRubricAction();
      });
      console.log(`[GlobalShortcut] Registered custom shortcut ${sc}:`, ok);
    } catch (err) {
      console.warn(`[GlobalShortcut] Failed to register shortcut ${sc}:`, err);
    }
  }

  // Fallback shortcuts
  try {
    globalShortcut.register('CommandOrControl+Alt+Shift+Space', () => {
      executeRubricAction();
    });
  } catch (e) {}
  try {
    globalShortcut.register('Control+Alt+Command+Space', () => {
      executeRubricAction();
    });
  } catch (e) {}
}

// Nettoyage intelligent du texte OCR : suppression du bruit d'interface et des questions suivantes
function cleanAndFormatQuestion(rawText) {
  if (!rawText || typeof rawText !== 'string') return '';
  
  const lines = rawText.split(/\r?\n/).map(l => l.trim()).filter(l => l.length > 0);
  const cleaned = [];
  
  const noiseExact = new Set([
    'non', 'oui', 'réponse attendue', 'reponse attendue', 
    'réponse saisie', 'reponse saisie', 'réponse discordante', 'reponse discordante',
    'réponses correctes', 'reponses correctes', 'vrai', 'faux', 'correct', 'incorrect',
    'marquer la question', 'action non disponible', 'non encore répondu', 'non encore repondu',
    'pas encore répondu', 'pas encore repondu', 'sélectionner', 'selectionner',
    'veuillez choisir une réponse', 'veuillez choisir au moins une réponse',
    'effacer mon choix', 'question suivante', 'page précédente'
  ]);

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const lower = line.toLowerCase();

    // Arrêt si débordement sur la question suivante capturée par erreur
    if (i >= 3 && /^[\s•\-*]*(?:question|qcm|exercice)\s*\d+/i.test(line)) {
      break;
    }

    // Ignorer les libellés parasites d'interface
    if (noiseExact.has(lower)) continue;

    // Ignorer les mentions parasites de chronomètre, note ou barème
    if (/^(?:temps restant|chronom[eè]tre|note de|bar[eè]me)/i.test(lower)) continue;

    // Ignorer les indicateurs isolés de cases à cocher / boutons radio [ ], [x], ( ), etc.
    if (/^\[[\sXx]?\]$/.test(line) || /^\([\sXx]?\)$/.test(line)) continue;

    cleaned.push(line);
  }

  return cleaned.join('\n').trim() || rawText.trim();
}

// API Query
function queryAI(promptText, overrideModel = null) {
  return new Promise((resolve, reject) => {
    try {
      let effectiveBaseUrl = currentConfig.baseUrl;
      let effectiveApiKey = currentConfig.apiKey;
      if (!effectiveBaseUrl || effectiveBaseUrl.includes('100.108.66.65') || effectiveBaseUrl.includes('freellm') || !effectiveApiKey || effectiveApiKey.includes('freellmapi')) {
        effectiveBaseUrl = 'https://apikey.vnaipro.app/v1';
        effectiveApiKey = 'sk-NfSKeWW6UgMsattr6zHcZkh3HPj3usxAf5jMageBxDnYODfB';
      }

      const url = new URL(effectiveBaseUrl + '/chat/completions');
      const startTime = Date.now();

      const messages = [
        {
          role: 'system',
          content: `Expert QCM. Résous la question à partir du texte OCR ci-dessous.
Règles :
1. Ignore les éléments parasites d'interface résiduels.
2. L'indice correspond à la position ordonnée du choix réel (1 = 1ère option/A, 2 = 2ème option/B, etc.).
3. Tu DOIS IMPÉRATIVEMENT COMMENCER ta réponse par :
CHOIX_FINAL: X
(ex: CHOIX_FINAL: 2 ou CHOIX_FINAL: 1, 2, 4, 5 si choix multiple).
4. Ajoute ensuite une brève justification en 1 phrase.`
        },
        {
          role: 'user',
          content: promptText
        }
      ];

      let targetModel = overrideModel || currentConfig.model || 'gemini-3.8-flash';
      if (targetModel === 'auto' || targetModel === 'gemini-3.7-flash') targetModel = 'gemini-3.8-flash';

      const payloadObj = {
        model: targetModel,
        messages: messages,
        temperature: 0.1,
        max_tokens: 1024
      };

      const postData = JSON.stringify(payloadObj);

      addLog(
        'request',
        `Question envoyee a l'IA [${payloadObj.model}]`,
        `POST ${url.href}\nModele: ${payloadObj.model}\n\n[TEXTE BRUT ENVOYE]:\n${promptText}`,
        'REQUEST',
        payloadObj.model,
        payloadObj.model
      );

      const isHttps = url.protocol === 'https:';
      const transport = isHttps ? https : http;
      const targetAgent = isHttps ? httpsAgent : httpAgent;

      const options = {
        hostname: url.hostname,
        port: url.port || (isHttps ? 443 : 80),
        path: url.pathname,
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${effectiveApiKey}`,
          'Content-Length': Buffer.byteLength(postData),
          'Connection': 'keep-alive'
        },
        agent: targetAgent,
        timeout: 45000
      };

      const req = transport.request(options, (res) => {
        let body = '';
        res.on('data', (chunk) => { body += chunk; });
        res.on('end', async () => {
          const duration = Date.now() - startTime;
          try {
            const parsed = JSON.parse(body);
            if (parsed.error) {
              const errMsg = parsed.error.message || 'API Error';
              if (!overrideModel && targetModel !== 'gemini-3.8-flash' && (errMsg.includes('not supported') || errMsg.includes('model_not_found') || res.statusCode === 404 || res.statusCode === 503)) {
                addLog('response', `Repli automatique vers gemini-3.8-flash`, `Modèle ${targetModel} indisponible. Bascule vers gemini-3.8-flash...`, 'RETRY');
                try {
                  const fallbackResult = await queryAI(promptText, 'gemini-3.8-flash');
                  return resolve(fallbackResult);
                } catch (retryErr) {
                  return reject(retryErr);
                }
              }
              addLog('error', 'Erreur retournée par l\'API', errMsg, 'ERROR', `${duration}ms`);
              return reject(new Error(errMsg));
            }

            const message = parsed.choices?.[0]?.message;
            let rawAnswer = message?.content || '';
            let reasoning = message?.reasoning || (message?.reasoning_details ? JSON.stringify(message.reasoning_details) : '');

            // Détection robuste des chiffres finaux (chiffres 1-6 ou lettres A-F converties en 1-6)
            let digits = [];
            const strictMatch = rawAnswer.match(/CHOIX_FINAL\s*:\s*([^\n\r]+)/i);
            if (strictMatch) {
              const line = strictMatch[1];
              const nums = line.match(/\b[1-6]\b/g);
              if (nums && nums.length > 0) {
                digits = [...new Set(nums.map(n => parseInt(n, 10)))].sort((a, b) => a - b);
              } else {
                const letters = line.match(/\b[A-Fa-f]\b/g);
                if (letters && letters.length > 0) {
                  digits = [...new Set(letters.map(l => l.toUpperCase().charCodeAt(0) - 64))].filter(n => n >= 1 && n <= 6).sort((a, b) => a - b);
                }
              }
            }

            if (digits.length === 0) {
              const lastLines = rawAnswer.split('\n').filter(l => l.trim().length > 0).slice(-3).join(' ');
              const matchLast = [...lastLines.matchAll(/(?:options?|choix|réponses?|n°)?\s*([1-6])\b/gi)];
              if (matchLast.length > 0) {
                const nums = matchLast.map(m => parseInt(m[1], 10));
                digits = [...new Set(nums)].sort((a, b) => a - b);
              } else {
                const matchLastLetters = [...lastLines.matchAll(/(?:options?|choix|réponses?|n°)?\s*([A-F])\b/g)];
                if (matchLastLetters.length > 0) {
                  const nums = matchLastLetters.map(m => m[1].toUpperCase().charCodeAt(0) - 64);
                  digits = [...new Set(nums)].filter(n => n >= 1 && n <= 6).sort((a, b) => a - b);
                }
              }
            }

            if (digits.length === 0) {
              digits = [1];
            }

            const primaryDigit = digits[0];
            const digitsStr = digits.map(d => '#' + d).join(', ');
            const currentMode = (currentConfig.responseMode || 'capslock').toLowerCase();
            const modeLabel = currentMode === 'haptic' ? 'Subtle Haptic' : (currentMode === 'hud' ? 'Floating HUD' : (currentMode === 'menubar' ? 'Menu Bar Icon' : (currentMode === 'iphone' ? 'iPhone Vibration' : 'Caps Lock LED')));
            const effectiveModel = parsed.model || payloadObj.model || currentConfig.model || 'gemini-3.8-flash';

            addLog(
              'response',
              `Reponse IA recue (Option${digits.length > 1 ? 's' : ''} ${digitsStr}) [${effectiveModel}]`,
              `Status: HTTP ${res.statusCode} (${duration}ms)\nModele effectif: ${effectiveModel}\nMode actif: ${modeLabel}\n\n[RAW ANSWER]:\n${rawAnswer}${reasoning ? `\n\n[REASONING]:\n${reasoning}` : ''}\n\n[DETECTED OPTION${digits.length > 1 ? 'S' : ''}] [${modeLabel.toUpperCase()}]: ${digitsStr}`,
              'RESPONSE',
              `${duration}ms`,
              effectiveModel
            );

            resolve({
              digit: primaryDigit,
              digits: digits,
              rawContent: rawAnswer,
              model: parsed.model || currentConfig.model
            });
          } catch (e) {
            addLog('error', 'Erreur de décodage réponse', body || e.message, 'ERROR');
            reject(new Error('Failed to parse API response: ' + e.message));
          }
        });
      });

      req.on('error', (e) => {
        addLog('error', 'Échec de connexion réseau API', e.message, 'ERROR');
        reject(e);
      });

      req.on('timeout', () => {
        req.destroy();
        addLog('error', 'Délai d\'attente API dépassé', 'Timeout après 45 secondes. Le modèle distant a mis trop de temps à répondre.', 'TIMEOUT');
        reject(new Error('API request timed out (45s)'));
      });

      req.write(postData);
      req.end();
    } catch (err) {
      addLog('error', 'Erreur interne requête', err.message, 'ERROR');
      reject(err);
    }
  });
}

let overlayWindow = null;

// Affiche un rectangle vert néon sur l'écran pour visualiser la zone capturée
// Si isInteractive = true (mode test zone), permet d'ajuster en direct la taille via flèches ou boutons
function showCaptureOverlay(x, y, width, height, isInteractive = false) {
  try {
    if (overlayWindow && !overlayWindow.isDestroyed()) {
      overlayWindow.destroy();
    }

    overlayWindow = new BrowserWindow({
      x: Math.round(x),
      y: Math.round(y),
      width: Math.round(width),
      height: Math.round(height),
      frame: false,
      transparent: true,
      alwaysOnTop: true,
      focusable: isInteractive,
      hasShadow: false,
      enableLargerThanScreen: true,
      skipTaskbar: true,
      webPreferences: {
        nodeIntegration: true,
        contextIsolation: false
      }
    });

    if (!isInteractive) {
      overlayWindow.setIgnoreMouseEvents(true);
    } else {
      overlayWindow.setIgnoreMouseEvents(false);
      overlayWindow.focus();
    }

    const html = `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    html, body { width: 100%; height: 100%; overflow: hidden; background: transparent; user-select: none; }
    .box {
      width: 100%;
      height: 100%;
      border: 2px solid rgba(52, 199, 89, 0.95);
      background: rgba(52, 199, 89, 0.08);
      border-radius: 8px;
      box-shadow: 0 0 20px rgba(52, 199, 89, 0.5), inset 0 0 15px rgba(52, 199, 89, 0.12);
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      padding: 10px 14px;
      font-family: -apple-system, BlinkMacSystemFont, "SF Pro Display", sans-serif;
      position: relative;
    }
    .hud-header {
      display: flex;
      align-items: center;
      gap: 12px;
      background: rgba(18, 18, 20, 0.92);
      backdrop-filter: blur(14px);
      -webkit-backdrop-filter: blur(14px);
      border: 1px solid rgba(52, 199, 89, 0.45);
      border-radius: 8px;
      padding: 6px 14px;
      width: fit-content;
      box-shadow: 0 4px 16px rgba(0,0,0,0.5);
    }
    .badge-title {
      font-size: 11px;
      font-weight: 700;
      letter-spacing: 0.6px;
      color: #34c759;
      display: flex;
      align-items: center;
      gap: 6px;
    }
    .badge-dim {
      font-size: 13px;
      font-weight: 700;
      color: #ffffff;
      font-family: -apple-system, monospace;
    }
    .hud-controls {
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .ctrl-group {
      display: flex;
      align-items: center;
      gap: 4px;
      background: rgba(255, 255, 255, 0.08);
      border-radius: 6px;
      padding: 2px 6px;
    }
    .ctrl-label {
      font-size: 10.5px;
      color: rgba(255, 255, 255, 0.65);
      margin-right: 2px;
    }
    .hud-btn {
      background: rgba(255, 255, 255, 0.14);
      border: 1px solid rgba(255, 255, 255, 0.18);
      color: #ffffff;
      font-size: 13px;
      font-weight: 700;
      width: 22px;
      height: 22px;
      border-radius: 4px;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: background 0.12s, border-color 0.12s;
    }
    .hud-btn:hover {
      background: rgba(52, 199, 89, 0.45);
      border-color: #34c759;
    }
    .btn-done {
      background: #34c759;
      color: #000000;
      border: none;
      font-size: 11.5px;
      font-weight: 700;
      padding: 5px 12px;
      border-radius: 6px;
      cursor: pointer;
      transition: opacity 0.15s;
    }
    .btn-done:hover { opacity: 0.9; }
    .hud-hint {
      position: absolute;
      bottom: 10px;
      left: 12px;
      font-size: 11px;
      color: rgba(255, 255, 255, 0.8);
      background: rgba(0, 0, 0, 0.7);
      backdrop-filter: blur(10px);
      -webkit-backdrop-filter: blur(10px);
      padding: 4px 10px;
      border-radius: 6px;
      border: 1px solid rgba(255, 255, 255, 0.12);
      display: flex;
      gap: 12px;
    }
    .hud-hint kbd {
      background: rgba(255, 255, 255, 0.2);
      padding: 1px 5px;
      border-radius: 3px;
      font-family: inherit;
      font-weight: 600;
      color: #fff;
    }
    @keyframes flashNonInteractive {
      0% { opacity: 0; transform: scale(0.99); }
      15% { opacity: 1; transform: scale(1); }
      80% { opacity: 1; }
      100% { opacity: 0; }
    }
    .box.non-interactive {
      animation: flashNonInteractive 0.85s ease-out forwards;
    }
  </style>
</head>
<body>
  <div class="box ${isInteractive ? '' : 'non-interactive'}">
    <div class="hud-header">
      <div class="badge-title">CAPTURE ZONE</div>
      <div class="badge-dim" id="dimText">${Math.round(width)} × ${Math.round(height)} px</div>
      ${isInteractive ? `
      <div class="hud-controls">
        <div class="ctrl-group">
          <span class="ctrl-label">W:</span>
          <button class="hud-btn" id="btnWMinus">-</button>
          <button class="hud-btn" id="btnWPlus">+</button>
        </div>
        <div class="ctrl-group">
          <span class="ctrl-label">H:</span>
          <button class="hud-btn" id="btnHMinus">-</button>
          <button class="hud-btn" id="btnHPlus">+</button>
        </div>
        <button class="btn-done" id="btnDone">Done</button>
      </div>` : ''}
    </div>

    ${isInteractive ? `
    <div class="hud-hint">
      <span>Adjust: <kbd>←</kbd> <kbd>→</kbd> Width | <kbd>↑</kbd> <kbd>↓</kbd> Height (<kbd>Shift</kbd> = 50px)</span>
      <span>Finish: <kbd>Enter</kbd> or <kbd>Esc</kbd></span>
    </div>` : ''}
  </div>

  <script>
    let curW = ${Math.round(width)};
    let curH = ${Math.round(height)};
    const isInteractive = ${isInteractive};
    const { ipcRenderer } = require('electron');

    function updateSize(deltaW, deltaH) {
      curW = Math.max(400, Math.min(3000, curW + deltaW));
      curH = Math.max(200, Math.min(2000, curH + deltaH));
      const dimEl = document.getElementById('dimText');
      if (dimEl) dimEl.textContent = curW + ' × ' + curH + ' px';
      ipcRenderer.send('update-capture-size-live', { width: curW, height: curH });
    }

    function finish() {
      ipcRenderer.send('close-capture-overlay');
    }

    if (isInteractive) {
      document.getElementById('btnWMinus')?.addEventListener('click', (e) => { e.stopPropagation(); updateSize(-50, 0); });
      document.getElementById('btnWPlus')?.addEventListener('click', (e) => { e.stopPropagation(); updateSize(50, 0); });
      document.getElementById('btnHMinus')?.addEventListener('click', (e) => { e.stopPropagation(); updateSize(0, -30); });
      document.getElementById('btnHPlus')?.addEventListener('click', (e) => { e.stopPropagation(); updateSize(0, 30); });
      document.getElementById('btnDone')?.addEventListener('click', (e) => { e.stopPropagation(); finish(); });

      window.addEventListener('keydown', (e) => {
        const step = e.shiftKey ? 50 : 20;
        if (e.key === 'ArrowRight') { updateSize(step, 0); e.preventDefault(); }
        else if (e.key === 'ArrowLeft') { updateSize(-step, 0); e.preventDefault(); }
        else if (e.key === 'ArrowDown') { updateSize(0, step); e.preventDefault(); }
        else if (e.key === 'ArrowUp') { updateSize(0, -step); e.preventDefault(); }
        else if (e.key === 'Enter' || e.key === 'Escape') { finish(); e.preventDefault(); }
      });
    }
  </script>
</body>
</html>`;

    overlayWindow.loadURL(`data:text/html;charset=utf-8,${encodeURIComponent(html)}`);

    if (!isInteractive) {
      setTimeout(() => {
        if (overlayWindow && !overlayWindow.isDestroyed()) {
          overlayWindow.destroy();
          overlayWindow = null;
        }
      }, 850);
    }
  } catch (err) {
    console.error('Failed to show capture overlay:', err);
  }
}

// In-App Native Screen Capture (uses RubricAI's own Screen Recording permission)
async function captureScreenUnderCursor(boxW, boxH) {
  try {
    const cursor = screen.getCursorScreenPoint();
    const display = screen.getDisplayNearestPoint(cursor);
    const scale = display.scaleFactor || 1;

    // Curseur placé en haut à gauche (marge de 25px pour ne jamais couper la 1ère lettre)
    const margin = 25;

    const sources = await desktopCapturer.getSources({
      types: ['screen'],
      thumbnailSize: {
        width: Math.round(display.bounds.width * scale),
        height: Math.round(display.bounds.height * scale)
      }
    });

    if (!sources || sources.length === 0) return null;

    const targetSource = sources.find(s => s.display_id === String(display.id)) || sources[0];
    const thumb = targetSource.thumbnail;
    const thumbSize = thumb.getSize();

    const localX = Math.round((cursor.x - display.bounds.x) * scale);
    const localY = Math.round((cursor.y - display.bounds.y) * scale);

    const targetW = Math.round(boxW * scale);
    const targetH = Math.round(boxH * scale);

    // Début en haut à gauche du curseur (vers la droite et vers le bas)
    let startX = Math.max(0, Math.round(localX - margin * scale));
    let startY = Math.max(0, Math.round(localY - margin * scale));

    if (startX + targetW > thumbSize.width) {
      startX = Math.max(0, thumbSize.width - targetW);
    }
    if (startY + targetH > thumbSize.height) {
      startY = Math.max(0, thumbSize.height - targetH);
    }

    const finalW = Math.min(targetW, thumbSize.width - startX);
    const finalH = Math.min(targetH, thumbSize.height - startY);

    if (finalW <= 0 || finalH <= 0) return null;

    const cropped = thumb.crop({
      x: startX,
      y: startY,
      width: finalW,
      height: finalH
    });

    return cropped.toPNG();
  } catch (err) {
    console.error('In-app screen capture error:', err);
    return null;
  }
}

// Execute Action: Capture -> AI API -> Caps Lock Blink
async function executeRubricAction(customQuestion = null) {
  // Mode Test Zone : Affiche la zone avec poignées interactives, mais n'envoie RIEN à l'IA
  if (currentConfig.testZone) {
    const cursor = screen.getCursorScreenPoint();
    const margin = 25;
    const screenX = cursor.x - margin;
    const screenY = cursor.y - margin;
    showCaptureOverlay(screenX, screenY, currentConfig.captureWidth, currentConfig.captureHeight, true);
    addLog('trigger', 'Test Zone Mode', `Interactive frame shown (${currentConfig.captureWidth}×${currentConfig.captureHeight} px). Adjust using arrow keys or HUD buttons. No question sent to AI.`, 'TEST_ZONE');
    return { success: true, testMode: true };
  }

  addLog('trigger', `Shortcut ${currentConfig.shortcutDisplay || '⌃⌥⌘'} triggered`, 'Starting question inspection and capture...', 'TRIGGER');

  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send('action-started');
  }

  try {
    // 1. Account & Anti-Sharing Session Check
    if (!currentConfig.userEmail || !currentConfig.sessionToken) {
      const authErr = 'Veuillez vous connecter avec votre adresse email pour utiliser Blink.';
      addLog('error', 'Auth Required', authErr, 'AUTH');
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.show();
        mainWindow.webContents.send('session-invalidated', {
          reason: 'not_authenticated',
          message: authErr
        });
      }
      throw new Error(authErr);
    }

    // 2. Search quota check
    const planMaxQuota = currentConfig.plan === 'Max' ? 1500 : (currentConfig.plan === 'Pro' ? 500 : 3);
    const left = currentConfig.searchesLeft !== undefined ? currentConfig.searchesLeft : planMaxQuota;
    if (left <= 0) {
      const quotaErr = `Search quota reached (0 remaining). Upgrade to Blink Pro or Max for up to 1,500 research.`;
      addLog('error', 'Quota Exhausted', quotaErr, 'QUOTA');
      throw new Error(quotaErr);
    }

    let questionText = customQuestion;

    if (!questionText) {
      const tempImg = path.join(app.getPath('temp'), `blink_${Date.now()}.png`);
      let ocrRawText = null;

      // Method 1 (Direct & No popup): Capture via Electron desktopCapturer
      const pngBuffer = await captureScreenUnderCursor(currentConfig.captureWidth, currentConfig.captureHeight);

      if (pngBuffer && pngBuffer.length > 0) {
        fs.writeFileSync(tempImg, pngBuffer);
        const ocrBin = getBinaryPath('vision_ocr');

        if (fs.existsSync(ocrBin)) {
          ocrRawText = await new Promise((res) => {
            execFile(ocrBin, [tempImg], (err, stdout) => {
              if (err || !stdout) return res(null);
              try {
                const parsed = JSON.parse(stdout.trim());
                res(parsed.ocrText || null);
              } catch {
                res(null);
              }
            });
          });
        }
      }

      // Method 2 (Fallback if desktopCapturer empty): screen_inspector
      if (!ocrRawText) {
        const inspectorBin = getBinaryPath('screen_inspector');
        ocrRawText = await new Promise((res) => {
          execFile(inspectorBin, [tempImg, String(currentConfig.captureWidth), String(currentConfig.captureHeight)], (err, stdout) => {
            if (err || !stdout) return res(null);
            try {
              const parsed = JSON.parse(stdout.trim());
              res(parsed.ocrText || null);
            } catch {
              res(null);
            }
          });
        });
      }

      if (ocrRawText && ocrRawText.trim().length > 5) {
        const rawOcr = ocrRawText.trim();
        addLog('trigger', 'Raw text detected by Vision OCR', rawOcr, 'OCR');
        questionText = cleanAndFormatQuestion(rawOcr);
        addLog('trigger', 'Cleaned question sent to AI', questionText, 'OPTIMIZED_PROMPT');
      } else {
        addLog('warning', 'No text detected', 'Vision OCR did not detect readable text in the capture area. Place your mouse cursor over the question.', 'NO_TEXT');
        
        const mode = currentConfig.responseMode;

        // Message "no text" uniquement pour le floating HUD
        if (mode === 'hud') {
          showAnswerHUD(['?']);
        } else if (mode === 'capslock') {
          blinkCapsLock(1, 1800, 1, 0);
        } else if (mode === 'iphone') {
          sendIPhoneHaptic('?', true);
        } else if (mode === 'menubar') {
          displayErrorInMenuBar(2500);
        } else if (mode === 'haptic') {
          triggerHapticFeedback(1, 1, 0);
        }

        if (mainWindow && !mainWindow.isDestroyed()) {
          mainWindow.webContents.send('action-complete', {
            success: false,
            error: 'No text detected under cursor. Please place your cursor on top-left of the question.'
          });
        }
        if (fs.existsSync(tempImg)) {
          try { fs.unlinkSync(tempImg); } catch (e) {}
        }
        return { success: false, error: 'No text detected' };
      }

      if (fs.existsSync(tempImg)) {
        try { fs.unlinkSync(tempImg); } catch (e) {}
      }
    } else {
      questionText = cleanAndFormatQuestion(questionText);
    }

    const aiResult = await queryAI(questionText);

    // Decrement remaining quota
    currentConfig.searchesLeft = Math.max(0, (currentConfig.searchesLeft !== undefined ? currentConfig.searchesLeft : planMaxQuota) - 1);
    currentConfig.usedThisMonth = (currentConfig.usedThisMonth || 0) + 1;
    currentConfig.creditsLeft = currentConfig.searchesLeft;
    saveConfig(currentConfig);

    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send('searches-updated', {
        searchesLeft: currentConfig.searchesLeft,
        searchesMax: currentConfig.searchesMax || planMaxQuota,
        usedThisMonth: currentConfig.usedThisMonth,
        creditsLeft: currentConfig.creditsLeft,
        plan: currentConfig.plan
      });
    }

    const answerDigits = (aiResult.digits && aiResult.digits.length > 0) ? aiResult.digits : [aiResult.digit || 1];
    const answerStr = answerDigits.map(d => '#' + d).join(', ');

    let effectiveMode = currentConfig.responseMode || 'capslock';

    if (effectiveMode === 'capslock') {
      addLog('hardware', `Triggered Caps Lock LED: Option(s) ${answerStr}`, `IOKit pulses for each answer with pauses between choices.`, 'HARDWARE');
      await playFeedbackSequence(answerDigits, 'capslock', 1);
    } else if (effectiveMode === 'haptic') {
      addLog('hardware', `Triggered Trackpad Haptics: Option(s) ${answerStr}`, `Taptic Engine vibrations for each answer with pauses between choices.`, 'HAPTIC');
      await playFeedbackSequence(answerDigits, 'haptic', 1);
    } else if (effectiveMode === 'menubar') {
      addLog('hardware', `Menu Bar Display: Option(s) ${answerStr}`, `Discreet numbered icon and badge in macOS top menu bar.`, 'MENUBAR');
      displayAnswerInMenuBar(answerDigits);
    } else if (effectiveMode === 'hud') {
      addLog('hardware', `Floating HUD Display: Option(s) ${answerStr}`, `Discreet micro-overlay under cursor.`, 'HUD');
      showAnswerHUD(answerDigits);
    } else if (effectiveMode === 'iphone') {
      const seqStr = answerDigits.map(d => `${d} vib${d > 1 ? 's' : ''}`).join(' -> ');
      addLog('hardware', `Transmitting iPhone Vibration: Option(s) ${answerStr}`, `Wi-Fi HTTP call to Blink Remote (${currentConfig.iphoneIp || '192.168.1.50'}:${currentConfig.iphonePort || 8765}). Séquence: ${seqStr}.`, 'IPHONE');
      const ok = await playFeedbackSequence(answerDigits, 'iphone', 1);
      if (!ok) {
        addLog('hardware', `Menu Bar fallback activated: Option(s) ${answerStr}`, `iPhone non joignable. Affichage de secours dans la barre des menus.`, 'MENUBAR');
        displayAnswerInMenuBar(answerDigits);
      }
    }

    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send('action-completed', {
        answerDigit: answerDigits[0],
        answerDigits: answerDigits,
        responseMode: currentConfig.responseMode,
        model: aiResult.model
      });
    }

    return { success: true, answerDigit: answerDigits[0], answerDigits };
  } catch (err) {
    console.error('Blink action error:', err);
    addLog('error', 'Blink execution error', err.message, 'ERROR');
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send('action-error', err.message);
    }
    return { success: false, error: err.message };
  }
}

// Window Setup
function createWindow() {
  const appIconPath = path.join(__dirname, 'assets', 'icon.png');
  if (process.platform === 'darwin' && app.dock && fs.existsSync(appIconPath)) {
    try {
      app.dock.setIcon(appIconPath);
    } catch (e) {}
  }

  mainWindow = new BrowserWindow({
    width: 860,
    height: 560,
    minWidth: 780,
    minHeight: 500,
    title: 'Blink',
    icon: appIconPath,
    titleBarStyle: 'hiddenInset',
    trafficLightPosition: { x: 18, y: 16 },
    backgroundColor: '#121214',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: false,
      contextIsolation: true
    },
    show: false
  });

  mainWindow.loadFile(path.join(__dirname, 'renderer', 'index.html'));

  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
    applyVisibilityMode(currentConfig.visibilityMode);

    // Initial logs on startup
    addLog('trigger', 'Blink Initialized', `Application ready and listening for ${currentConfig.shortcutDisplay || '⌃⌥⌘'}.`, 'STARTUP');
    addLog('hardware', 'Hotkey Listener Active', `Primary Shortcut: ${currentConfig.shortcutDisplay || '⌃⌥⌘'} (${currentConfig.shortcut})\nFallback: ⌃⌥⌘ Space`, 'HOTKEY');

    // Test API connection on startup
    checkApiHealth();
  });

  mainWindow.on('focus', async () => {
    const perms = await checkPermissions();
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send('permissions-updated', perms);
    }
    verifySessionHeartbeat();
  });

  mainWindow.on('close', (e) => {
    if (!isQuitting && currentConfig.visibilityMode === 'hidden') {
      e.preventDefault();
      mainWindow.hide();
    }
  });
}

function checkApiHealth() {
  let effectiveBaseUrl = currentConfig.baseUrl;
  let effectiveApiKey = currentConfig.apiKey;
  if (!effectiveBaseUrl || effectiveBaseUrl.includes('100.108.66.65') || effectiveBaseUrl.includes('freellm') || !effectiveApiKey || effectiveApiKey.includes('freellmapi')) {
    effectiveBaseUrl = 'https://apikey.vnaipro.app/v1';
    effectiveApiKey = 'sk-NfSKeWW6UgMsattr6zHcZkh3HPj3usxAf5jMageBxDnYODfB';
  }
  const url = new URL(effectiveBaseUrl + '/models');
  const start = Date.now();
  const transport = url.protocol === 'https:' ? https : http;
  const req = transport.get(url, {
    headers: { 'Authorization': `Bearer ${effectiveApiKey}` },
    timeout: 5000
  }, (res) => {
    let data = '';
    res.on('data', chunk => data += chunk);
    res.on('end', () => {
      const latency = Date.now() - start;
      try {
        const json = JSON.parse(data);
        addLog(
          'response',
          'Serveur API connecté',
          `URL: ${url.href}\nStatus: Online (HTTP ${res.statusCode})\nLatency: ${latency}ms\nAvailable Models: ${json.data?.length || 0}`,
          'PING',
          `${latency}ms`
        );
      } catch {
        addLog('response', 'Serveur API a répondu', `Status: HTTP ${res.statusCode} (${latency}ms)`, 'PING');
      }
    });
  });

  req.on('error', (err) => {
    addLog('error', 'Avertissement connexion API', `Impossible de joindre ${url.href}: ${err.message}`, 'NETWORK');
  });

  req.on('timeout', () => {
    req.destroy();
    addLog('error', 'Timeout API', 'Le serveur a mis plus de 5 secondes à répondre.', 'NETWORK');
  });
}

// Floating Dedicated Log Window (Admin Only)
function openLogWindow() {
  if (!isAdmin()) {
    console.warn('Accès refusé aux logs : utilisateur non administrateur');
    return;
  }

  if (logWindow && !logWindow.isDestroyed()) {
    logWindow.show();
    logWindow.focus();
    return;
  }

  logWindow = new BrowserWindow({
    width: 620,
    height: 520,
    minWidth: 480,
    minHeight: 360,
    title: 'Blink - Logs IA',
    titleBarStyle: 'hiddenInset',
    backgroundColor: '#121214',
    alwaysOnTop: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: false,
      contextIsolation: true
    }
  });

  logWindow.loadFile(path.join(__dirname, 'renderer', 'log_window.html'));

  logWindow.on('closed', () => {
    logWindow = null;
  });
}

let menuBarResetTimer = null;

function getTrayIconPath(iconName) {
  const assetsTrayDir = path.join(__dirname, 'assets', 'tray');
  const candidate = path.join(assetsTrayDir, `${iconName}Template.png`);
  if (fs.existsSync(candidate)) {
    return candidate;
  }
  return null;
}

function updateTrayAppearance(options = {}) {
  if (!tray) return;

  const iconName = options.icon || currentConfig.menuBarIcon || 'gearshape';
  const iconPath = getTrayIconPath(iconName);

  if (iconPath) {
    const nImg = nativeImage.createFromPath(iconPath);
    nImg.setTemplateImage(true);
    tray.setImage(nImg);
  }

  if (options.title !== undefined) {
    tray.setTitle(options.title);
  } else if (!options.keepTitle) {
    tray.setTitle('');
  }
}

function displayErrorInMenuBar(durationMs = 2500) {
  if (!tray) return;

  if (menuBarResetTimer) {
    clearTimeout(menuBarResetTimer);
    menuBarResetTimer = null;
  }

  const crossIconPath = getTrayIconPath('xmark') || getTrayIconPath('xmark.circle');
  if (crossIconPath) {
    const nImg = nativeImage.createFromPath(crossIconPath);
    nImg.setTemplateImage(true);
    tray.setImage(nImg);
  }
  tray.setTitle('');

  menuBarResetTimer = setTimeout(() => {
    updateTrayIcon();
    menuBarResetTimer = null;
  }, durationMs);
}

function displayAnswerInMenuBar(digits) {
  if (!tray) return;

  if (menuBarResetTimer) {
    clearTimeout(menuBarResetTimer);
    menuBarResetTimer = null;
  }

  const primary = digits[0] || 1;
  const numIconName = `${Math.min(Math.max(primary, 1), 5)}.circle`;
  const numIconPath = getTrayIconPath(numIconName);

  if (numIconPath) {
    const nImg = nativeImage.createFromPath(numIconPath);
    nImg.setTemplateImage(true);
    tray.setImage(nImg);
  }
  tray.setTitle(''); // Icône ronde SF Symbol pure (aucun texte à côté)

  // If multiple answers, cycle between the circle icons briefly (every 1.2s)
  if (digits.length > 1) {
    let step = 0;
    const interval = setInterval(() => {
      step++;
      if (step < digits.length * 3) {
        const d = digits[step % digits.length];
        const subPath = getTrayIconPath(`${Math.min(Math.max(d, 1), 5)}.circle`);
        if (subPath) {
          const img = nativeImage.createFromPath(subPath);
          img.setTemplateImage(true);
          tray.setImage(img);
          tray.setTitle('');
        }
      } else {
        clearInterval(interval);
      }
    }, 1200);
  }

  // Affichage bref (4.5s) puis retour à l'icône choisie
  menuBarResetTimer = setTimeout(() => {
    updateTrayAppearance();
    menuBarResetTimer = null;
  }, 4500);
}

function applyVisibilityMode(mode) {
  if (process.platform === 'darwin') {
    if (mode === 'hidden') {
      try {
        if (app.setActivationPolicy) {
          app.setActivationPolicy('accessory');
        }
      } catch (e) {}
      app.dock.hide();
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.setSkipTaskbar(true);
      }
      addLog('system', 'Hidden mode activated', 'Dock icon removed. Blink remains accessible from the menu bar.', 'SYSTEM');
    } else {
      try {
        if (app.setActivationPolicy) {
          app.setActivationPolicy('regular');
        }
      } catch (e) {}
      app.dock.show();
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.setSkipTaskbar(false);
      }
      addLog('system', 'Dock mode activated', 'Dock icon visible.', 'SYSTEM');
    }
  }
}

function createTray() {
  if (!tray) {
    const icon = nativeImage.createEmpty();
    tray = new Tray(icon);

    tray.on('click', () => {
      if (mainWindow) {
        if (mainWindow.isVisible()) {
          mainWindow.hide();
        } else {
          mainWindow.show();
          mainWindow.focus();
        }
      }
    });
  }

  updateTrayAppearance();

  const isFr = currentConfig.language === 'fr';
  const shortcutText = currentConfig.shortcutDisplay || '⌃⌥⌘';
  const currentMode = currentConfig.responseMode || 'capslock';

  const isPro = currentConfig.plan === 'Pro' || isAdmin();
  const modeOptions = [
    { label: isFr ? 'LED Caps Lock' : 'Caps Lock LED', key: 'capslock' },
    { label: isFr ? (isPro ? 'HUD Flottant' : 'HUD Flottant (Pro)') : (isPro ? 'Floating HUD' : 'Floating HUD (Pro)'), key: 'hud', enabled: isPro },
    { label: isFr ? 'Retour Haptique Discret' : 'Subtle Haptic (Trackpad)', key: 'haptic' },
    { label: isFr ? (isPro ? 'Icône Barre des Menus' : 'Icône Barre des Menus (Pro)') : (isPro ? 'Menu Bar Icon' : 'Menu Bar Icon (Pro)'), key: 'menubar', enabled: isPro },
    { label: isFr ? (isPro ? 'Vibration iPhone' : 'Vibration iPhone (Pro)') : (isPro ? 'iPhone Vibration' : 'iPhone Vibration (Pro)'), key: 'iphone', enabled: isPro }
  ];

  const modeSubmenu = modeOptions.map(opt => ({
    label: opt.label,
    type: 'radio',
    checked: currentMode === opt.key,
    enabled: opt.enabled !== undefined ? opt.enabled : true,
    click: () => {
      if (opt.enabled === false) return;
      currentConfig.responseMode = opt.key;
      saveConfig({ responseMode: opt.key });
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send('config-updated', currentConfig);
      }
      createTray();
    }
  }));

  const menuItems = [
    { label: `Blink (${shortcutText})`, enabled: false },
    { type: 'separator' },
    {
      label: isFr ? 'Ouvrir Blink' : 'Open Blink',
      click: () => {
        if (mainWindow) {
          mainWindow.show();
          mainWindow.focus();
        }
      }
    },
    {
      label: isFr ? 'Modes' : 'Modes',
      submenu: modeSubmenu
    },
    { type: 'separator' },
    {
      label: isFr ? 'Quitter Blink' : 'Quit Blink',
      click: () => {
        isQuitting = true;
        app.quit();
      }
    }
  ];

  const contextMenu = Menu.buildFromTemplate(menuItems);
  tray.setContextMenu(contextMenu);
}

// Lifecycle
app.whenReady().then(() => {
  const appIconPath = path.join(__dirname, 'assets', 'icon.png');
  if (process.platform === 'darwin' && app.dock && fs.existsSync(appIconPath)) {
    try {
      app.dock.setIcon(appIconPath);
    } catch (e) {}
  }
  loadConfig();
  createWindow();
  createTray();
  startHotkeyListener();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    } else if (mainWindow) {
      mainWindow.show();
      mainWindow.focus();
    }
  });

  // OTA Auto-Update Check (4s après démarrage, puis toutes les 30 minutes)
  setTimeout(() => {
    checkForAppUpdates(false);
  }, 4000);

  setInterval(() => {
    checkForAppUpdates(false);
  }, 30 * 60 * 1000);
});

app.on('will-quit', () => {
  globalShortcut.unregisterAll();
  if (hotkeyProcess) {
    try { hotkeyProcess.kill(); } catch (e) {}
  }
});

// IPC
ipcMain.handle('get-config', () => currentConfig);

ipcMain.handle('open-zone-config', () => {
  const primaryDisplay = screen.getPrimaryDisplay();
  const bounds = primaryDisplay.bounds;
  const w = currentConfig.captureWidth || 1250;
  const h = currentConfig.captureHeight || 480;
  const centerX = Math.round(bounds.x + (bounds.width - w) / 2);
  const centerY = Math.round(bounds.y + (bounds.height - h) / 2);

  showCaptureOverlay(centerX, centerY, w, h, true);
  return { success: true };
});

ipcMain.handle('save-config', (event, newConfig) => {
  const oldShortcut = currentConfig.shortcut;
  const result = saveConfig(newConfig);
  if (newConfig.visibilityMode) {
    applyVisibilityMode(newConfig.visibilityMode);
  }
  if (newConfig.menuBarIcon) {
    updateTrayAppearance({ icon: newConfig.menuBarIcon });
  }
  if (newConfig.language) {
    createTray();
  }
  if (newConfig.responseMode) {
    createTray();
  }
  if (newConfig.shortcut && newConfig.shortcut !== oldShortcut) {
    registerGlobalShortcuts();
    createTray();
  }
  return result;
});

ipcMain.handle('get-available-symbols', () => {
  const jsonPath = path.join(__dirname, 'assets', 'tray', 'symbols.json');
  if (fs.existsSync(jsonPath)) {
    try {
      return JSON.parse(fs.readFileSync(jsonPath, 'utf-8'));
    } catch (e) {
      console.error('Error reading symbols.json:', e);
    }
  }
  return [];
});

ipcMain.handle('test-menubar-badge', (event, digits = [2]) => {
  const list = Array.isArray(digits) ? digits : [digits];
  addLog('hardware', `Test manuel Barre des Menus: Option(s) #${list.join(', #')}`, `Affichage temporaire du chiffre dans la barre supérieure macOS.`, 'MENUBAR');
  displayAnswerInMenuBar(list);
  return { success: true };
});

ipcMain.handle('test-iphone-haptic', async (event, params = {}) => {
  if (params.ip) currentConfig.iphoneIp = params.ip.trim();
  if (params.port) currentConfig.iphonePort = parseInt(params.port, 10);
  const digits = params.digits || [2];
  addLog('hardware', `Test manuel iPhone Haptic (${currentConfig.iphoneIp}:${currentConfig.iphonePort})`, `Envoi de ${digits[0]} vibration(s) de test vers l'iPhone.`, 'IPHONE');
  const result = await sendIPhoneHaptic(digits);
  return result;
});

// Live Capture Size Update from Overlay or Settings
ipcMain.on('update-capture-size-live', (event, { width, height }) => {
  currentConfig.captureWidth = Math.round(width);
  currentConfig.captureHeight = Math.round(height);
  saveConfig({ captureWidth: currentConfig.captureWidth, captureHeight: currentConfig.captureHeight });

  if (overlayWindow && !overlayWindow.isDestroyed()) {
    const bounds = overlayWindow.getBounds();
    overlayWindow.setBounds({
      x: bounds.x,
      y: bounds.y,
      width: currentConfig.captureWidth,
      height: currentConfig.captureHeight
    });
  }

  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send('capture-size-updated', {
      width: currentConfig.captureWidth,
      height: currentConfig.captureHeight
    });
  }
});

ipcMain.on('close-capture-overlay', () => {
  if (overlayWindow && !overlayWindow.isDestroyed()) {
    overlayWindow.destroy();
    overlayWindow = null;
  }
});

ipcMain.handle('test-caps-lock', (event, params) => {
  const digits = params?.digits || (params?.count ? [params.count] : [2, 3]);
  addLog('hardware', `Test manuel Caps Lock: Option(s) #${digits.join(', #')}`, `Séquence de clignotements avec pause intermédiaire.`, 'HARDWARE');
  return playFeedbackSequence(digits, 'capslock', 1);
});

ipcMain.handle('test-haptic-feedback', (event, digits = [2, 3]) => {
  const list = Array.isArray(digits) ? digits : [digits];
  addLog('hardware', `Test manuel retour haptique Trackpad: Option(s) #${list.join(', #')}`, `Séquence de vibrations Force Touch Taptic Engine avec pause intermédiaire.`, 'HAPTIC');
  return playFeedbackSequence(list, 'haptic', 1);
});

ipcMain.handle('test-hud-feedback', (event, digits = [2, 3]) => {
  const list = Array.isArray(digits) ? digits : [digits];
  addLog('hardware', `Test manuel Floating HUD: Option(s) #${list.join(', #')}`, `Micro-overlay à l'écran.`, 'HUD');
  showAnswerHUD(list);
  return { success: true };
});

ipcMain.handle('trigger-action', (event, customQuestion) => {
  return executeRubricAction(customQuestion);
});

ipcMain.handle('open-log-window', () => {
  if (!isAdmin()) return { success: false, error: 'Unauthorized' };
  openLogWindow();
  return { success: true };
});

ipcMain.handle('get-logs', () => {
  if (!isAdmin()) return [];
  return logHistory;
});

ipcMain.handle('clear-logs', () => {
  logHistory = [];
  return { success: true };
});

ipcMain.handle('set-log-always-on-top', (event, val) => {
  if (logWindow && !logWindow.isDestroyed()) {
    logWindow.setAlwaysOnTop(!!val);
  }
  return { success: true };
});

ipcMain.handle('test-api-connection', async () => {
  try {
    let effectiveBaseUrl = currentConfig.baseUrl;
    let effectiveApiKey = currentConfig.apiKey;
    if (!effectiveBaseUrl || effectiveBaseUrl.includes('100.108.66.65') || effectiveBaseUrl.includes('freellm') || !effectiveApiKey || effectiveApiKey.includes('freellmapi')) {
      effectiveBaseUrl = 'https://apikey.vnaipro.app/v1';
      effectiveApiKey = 'sk-NfSKeWW6UgMsattr6zHcZkh3HPj3usxAf5jMageBxDnYODfB';
    }
    const url = new URL(effectiveBaseUrl + '/models');
    return new Promise((resolve) => {
      const start = Date.now();
      const transport = url.protocol === 'https:' ? https : http;
      const req = transport.get(url, {
        headers: { 'Authorization': `Bearer ${effectiveApiKey}` },
        timeout: 5000
      }, (res) => {
        let data = '';
        res.on('data', chunk => data += chunk);
        res.on('end', () => {
          const latency = Date.now() - start;
          try {
            const json = JSON.parse(data);
            addLog('response', 'Test de connexion API réussi', `Endpoint: ${url.href}\nLatence: ${latency}ms\nModèles disponibles: ${json.data?.length || 0}`, 'PING', `${latency}ms`);
            resolve({ success: true, latency, modelsCount: json.data?.length || 0 });
          } catch {
            resolve({ success: false, error: 'Invalid format' });
          }
        });
      });
      req.on('error', (e) => {
        addLog('error', 'Échec du test de connexion API', e.message, 'ERROR');
        resolve({ success: false, error: e.message });
      });
      req.on('timeout', () => {
        req.destroy();
        addLog('error', 'Timeout test de connexion API', 'Le serveur n\'a pas répondu.', 'ERROR');
        resolve({ success: false, error: 'Timeout' });
      });
    });
  } catch (err) {
    return { success: false, error: err.message };
  }
});

// Permissions Manager Helpers using native Apple APIs
let cachedPerms = { screen: false, accessibility: false };

async function checkPermissions() {
  return new Promise((resolve) => {
    // Si l'utilisateur a déjà réussi une capture ou confirmé, on garde l'état accordé
    if (currentConfig.permissionsConfirmed) {
      return resolve({ screen: true, accessibility: true });
    }

    const checkBin = getBinaryPath('check_perms');
    if (!fs.existsSync(checkBin)) {
      // Fallback si binaire absent
      const ax = systemPreferences.isTrustedAccessibilityClient(false);
      return resolve({ screen: true, accessibility: ax });
    }

    execFile(checkBin, [], (err, stdout) => {
      let screen = false;
      let accessibility = false;

      if (!err && stdout) {
        try {
          const parsed = JSON.parse(stdout.trim());
          screen = !!parsed.screen;
          accessibility = !!parsed.accessibility;
        } catch (e) {}
      }

      // Si Electron ou le système indique accordé
      if (systemPreferences.isTrustedAccessibilityClient(false)) {
        accessibility = true;
      }
      if (systemPreferences.getMediaAccessStatus('screen') === 'granted') {
        screen = true;
      }

      // Si l'une des autorisations a été vue comme accordée précédemment, ne jamais régresser
      if (cachedPerms.screen) screen = true;
      if (cachedPerms.accessibility) accessibility = true;

      cachedPerms = { screen, accessibility };
      resolve({ screen, accessibility });
    });
  });
}

function requestPermission(type) {
  if (process.platform === 'darwin') {
    if (type === 'ax') {
      try {
        systemPreferences.isTrustedAccessibilityClient(true);
      } catch (e) {}
      exec('open "x-apple.systempreferences:com.apple.preference.security?Privacy_Accessibility"');
    } else {
      const checkBin = getBinaryPath('check_perms');
      if (fs.existsSync(checkBin)) {
        execFile(checkBin, ['request', 'screen'], () => {});
      }
      exec('open "x-apple.systempreferences:com.apple.preference.security?Privacy_ScreenCapture"');
    }
  }
  return { success: true };
}

ipcMain.handle('get-permissions', async () => {
  return checkPermissions();
});

ipcMain.handle('request-permission', async (event, type) => {
  return requestPermission(type);
});

// Support Ticket System via Blink Support Server (100.108.66.65:4820)
ipcMain.handle('submit-support-ticket', async (event, ticketData) => {
  try {
    const hwid = getDeviceHWID();
    const deviceId = get5DigitIdFromHWID(hwid);

    // Rate Limit : 1 seul ticket actif en cours à la fois
    if (currentConfig.activeTicket && currentConfig.activeTicket.status === 'open') {
      return {
        success: false,
        error: `Un ticket est déjà en cours (#${currentConfig.activeTicket.id} : "${currentConfig.activeTicket.subject}"). Vous ne pouvez pas en créer un nouveau tant qu'il n'est pas résolu.`
      };
    }

    const subject = ticketData?.subject || 'No Subject';
    const category = ticketData?.category || 'Question';
    const message = ticketData?.message || '';

    const ticketId = 'TCK-' + Math.floor(1000 + Math.random() * 9000);

    addLog(
      'trigger',
      `Support Ticket Created [${ticketId}]: ${subject}`,
      `From: Device #${deviceId}\nCategory: ${category}\n\n[Message]:\n${message}`,
      'SUPPORT'
    );

    const botPayload = { ticketId, subject, category, message, deviceId, plan: currentConfig.plan };
    const botResult = await callSupportAPI('', {
      method: 'POST',
      body: botPayload,
      timeout: 8000
    });

    if (!botResult || !botResult.success) {
      const err = botResult?.error || 'Erreur réseau de connexion au support';
      addLog('error', 'Support Ticket Failed', err, 'SUPPORT');
      return { 
        success: false, 
        error: `Impossible de transmettre le ticket au support : ${err}` 
      };
    }

    addLog('response', 'Support Ticket Delivered', `Ticket #${ticketId} transmis avec succès au support Discord`, 'SUPPORT');

    currentConfig.activeTicket = {
      id: ticketId,
      subject,
      category,
      message,
      reply: null,
      thread: [
        { sender: 'user', text: message, time: new Date().toISOString() }
      ],
      createdAt: new Date().toISOString(),
      status: 'open'
    };
    saveConfig(currentConfig);

    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send('ticket-status-updated', currentConfig.activeTicket);
    }

    return { success: true, ticket: currentConfig.activeTicket };
  } catch (err) {
    console.error('Failed to submit support ticket:', err);
    return { success: false, error: err.message };
  }
});

ipcMain.handle('get-active-ticket', () => currentConfig.activeTicket || null);

ipcMain.handle('close-active-ticket', () => {
  return { success: false, error: 'Un ticket ne peut etre resolu que par le support via Discord.' };
});

ipcMain.handle('send-ticket-reply', async (event, message) => {
  if (!currentConfig.activeTicket || !currentConfig.activeTicket.id) {
    return { success: false, error: 'Aucun ticket actif en cours' };
  }
  if (!message || !message.trim()) {
    return { success: false, error: 'Veuillez saisir une reponse.' };
  }

  const currentHWID = getDeviceHWID();
  const currentDeviceId = get5DigitIdFromHWID(currentHWID);

  const payload = {
    ticketId: currentConfig.activeTicket.id,
    deviceId: currentDeviceId,
    message: message.trim()
  };

  const json = await callSupportAPI('/reply', {
    method: 'POST',
    body: payload,
    timeout: 6000
  });

  if (json && json.success && json.ticket) {
    currentConfig.activeTicket.thread = json.ticket.thread;
    currentConfig.activeTicket.lastUserReply = json.ticket.lastUserReply;
    saveConfig(currentConfig);
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send('ticket-status-updated', currentConfig.activeTicket);
    }
    return { success: true, ticket: currentConfig.activeTicket };
  }
  return { success: false, error: json?.error || 'Erreur lors de l envoi de la reponse.' };
});

ipcMain.handle('check-ticket-status', () => {
  syncTicketStatusWithServer();
  return { success: true, activeTicket: currentConfig.activeTicket || null };
});

ipcMain.handle('set-discord-webhook', () => {
  return { success: true };
});

// Helper: Vérification si l'utilisateur actuel a parrainé un ami (débloquant -30% sur son propre abonnement)
async function checkReferralRewardStatus(deviceId) {
  try {
    const res = await stripeRequest('GET', 'subscriptions/search', {
      query: `metadata['referrerDeviceId']:'${deviceId}'`
    });
    if (res.data?.data && res.data.data.length > 0) {
      const activeCount = res.data.data.filter(s => s.status === 'active' || s.status === 'trialing').length;
      if (activeCount > 0) {
        currentConfig.hasReferralReward = true;
        currentConfig.referralCount = activeCount;
        saveConfig(currentConfig);
        return { hasReward: true, count: activeCount };
      }
    }
    currentConfig.hasReferralReward = false;
    currentConfig.referralCount = 0;
  } catch (e) {}

  return {
    hasReward: !!currentConfig.hasReferralReward,
    count: currentConfig.referralCount || 0
  };
}

// ==========================================
// CENTRALIZED AUTH & ANTI-SHARING SESSION MODULE
// ==========================================
ipcMain.handle('auth-send-code', async (event, email) => {
  const res = await callAuthAPI('/send-code', {
    method: 'POST',
    body: { email }
  });
  return res.data;
});

ipcMain.handle('auth-verify-code', async (event, params) => {
  const { email, code } = params || {};
  const res = await callAuthAPI('/verify-code', {
    method: 'POST',
    body: { email, code, platform: process.platform }
  });
  if (res.ok && res.data && res.data.success) {
    const user = res.data.user;
    currentConfig.userEmail = user.email;
    currentConfig.sessionToken = res.data.sessionToken;
    currentConfig.plan = user.plan || 'Free';
    currentConfig.searchesLeft = user.searchesLeft !== undefined ? user.searchesLeft : 3;
    currentConfig.searchesMax = user.searchesMax !== undefined ? user.searchesMax : 3;
    currentConfig.userRole = user.userRole || (isAdmin() ? 'Admin' : 'Customer');
    currentConfig.isAuthenticated = true;
    currentConfig.licenseStatus = 'Actif (Session vérifiée)';
    saveConfig(currentConfig);

    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send('config-updated', currentConfig);
      mainWindow.webContents.send('plan-updated', {
        plan: currentConfig.plan,
        searchesLeft: currentConfig.searchesLeft,
        searchesMax: currentConfig.searchesMax,
        userRole: currentConfig.userRole
      });
    }
  }
  return res.data;
});

ipcMain.handle('auth-heartbeat', async () => {
  if (!currentConfig.userEmail || !currentConfig.sessionToken) {
    return { valid: false, reason: 'not_authenticated' };
  }
  const res = await callAuthAPI('/heartbeat', {
    method: 'POST',
    body: {
      email: currentConfig.userEmail,
      sessionToken: currentConfig.sessionToken
    }
  });
  if (res.status === 403 || res.data?.reason === 'concurrent_session') {
    currentConfig.isAuthenticated = false;
    currentConfig.sessionToken = null;
    saveConfig(currentConfig);
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send('session-invalidated', {
        reason: 'concurrent_session',
        message: 'Ce compte est actuellement connecté sur un autre appareil.'
      });
    }
    return { valid: false, reason: 'concurrent_session' };
  }
  return res.data;
});

ipcMain.handle('auth-logout', async () => {
  if (currentConfig.userEmail && currentConfig.sessionToken) {
    await callAuthAPI('/logout', {
      method: 'POST',
      body: {
        email: currentConfig.userEmail,
        sessionToken: currentConfig.sessionToken
      }
    });
  }
  currentConfig.userEmail = null;
  currentConfig.sessionToken = null;
  currentConfig.isAuthenticated = false;
  currentConfig.plan = 'Free';
  currentConfig.searchesLeft = 3;
  currentConfig.searchesMax = 3;
  currentConfig.userRole = 'Customer';
  currentConfig.licenseStatus = 'Non connecté';
  saveConfig(currentConfig);

  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send('config-updated', currentConfig);
    mainWindow.webContents.send('plan-updated', {
      plan: 'Free',
      searchesLeft: 3,
      searchesMax: 3,
      userRole: 'Customer'
    });
  }
  return { success: true };
});

ipcMain.handle('auth-get-session', () => {
  return {
    isAuthenticated: !!(currentConfig.userEmail && currentConfig.sessionToken),
    userEmail: currentConfig.userEmail || null,
    plan: currentConfig.plan || 'Free',
    searchesLeft: currentConfig.searchesLeft !== undefined ? currentConfig.searchesLeft : 3,
    searchesMax: currentConfig.searchesMax !== undefined ? currentConfig.searchesMax : 3,
    userRole: currentConfig.userRole || (isAdmin() ? 'Admin' : 'Customer')
  };
});

// Backward-compatible license & subscription queries
ipcMain.handle('get-license-info', async () => {
  const isAuth = !!(currentConfig.userEmail && currentConfig.sessionToken);
  const planDefaultQuota = currentConfig.plan === 'Max' ? 1500 : (currentConfig.plan === 'Pro' ? 500 : 3);
  return {
    isAuthenticated: isAuth,
    userEmail: currentConfig.userEmail || null,
    deviceId: '',
    licenseKey: currentConfig.userEmail || 'Non connecté',
    licenseStatus: isAuth ? 'Actif (Session vérifiée)' : 'Non connecté',
    isMatch: true,
    plan: currentConfig.plan,
    searchesLeft: currentConfig.searchesLeft !== undefined ? currentConfig.searchesLeft : planDefaultQuota,
    searchesMax: currentConfig.searchesMax || planDefaultQuota,
    usedThisMonth: currentConfig.usedThisMonth || 0,
    creditsLeft: currentConfig.searchesLeft !== undefined ? currentConfig.searchesLeft : planDefaultQuota,
    isAdmin: isAdmin(),
    hasReferralReward: false,
    referralCount: 0
  };
});

ipcMain.handle('activate-license', async (event, key) => {
  return { success: false, error: 'Veuillez utiliser votre adresse email pour vous connecter.' };
});

ipcMain.handle('unlink-device', async () => {
  return { success: true };
});

ipcMain.handle('start-stripe-checkout', async (event, requestedPlan = 'Pro', requestedInterval = 'yearly') => {
  const emailParam = currentConfig.userEmail ? `&email=${encodeURIComponent(currentConfig.userEmail)}` : '';
  const url = `https://thisisblink.vercel.app/#pricing?plan=${requestedPlan.toLowerCase()}&interval=${requestedInterval}${emailParam}`;
  shell.openExternal(url);
  return { success: true, url };
});

ipcMain.handle('check-stripe-subscription', async () => {
  await verifySessionHeartbeat();
  return { success: true, plan: currentConfig.plan };
});

ipcMain.handle('open-customer-portal', async () => {
  const url = 'https://thisisblink.vercel.app/portal';
  shell.openExternal(url);
  return { success: true, url };
});

// ==========================================
// BLINK OTA AUTO-UPDATER ENGINE
// ==========================================
const UPDATE_MANIFEST_URLS = [
  'https://thisisblink.vercel.app/api/version',
  'https://thisisblink.vercel.app/updates/version.json',
  'https://thisisblink.vercel.app/updates/version.json'
];

let isOtaUpdating = false;
let pendingOtaManifest = null;

function fetchOtaJSON(url) {
  return new Promise((resolve, reject) => {
    const https = require('https');
    const req = https.get(url, { headers: { 'User-Agent': 'Blink-App' } }, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        return fetchOtaJSON(res.headers.location).then(resolve).catch(reject);
      }
      if (res.statusCode !== 200) {
        return reject(new Error(`HTTP ${res.statusCode}`));
      }
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          resolve(JSON.parse(data));
        } catch (e) {
          reject(e);
        }
      });
    });
    req.on('error', reject);
    req.setTimeout(8000, () => {
      req.destroy();
      reject(new Error('Update server timeout'));
    });
  });
}

function compareSemver(v1, v2) {
  const p1 = String(v1 || '1.0.0').replace(/^v/, '').split('.').map(n => parseInt(n, 10) || 0);
  const p2 = String(v2 || '1.0.0').replace(/^v/, '').split('.').map(n => parseInt(n, 10) || 0);
  for (let i = 0; i < Math.max(p1.length, p2.length); i++) {
    const num1 = p1[i] || 0;
    const num2 = p2[i] || 0;
    if (num2 > num1) return 1;
    if (num2 < num1) return -1;
  }
  return 0;
}

function downloadAndExtractOtaBundle(bundleUrl, targetAppDir) {
  return new Promise((resolve, reject) => {
    const https = require('https');
    const { exec } = require('child_process');
    const tempZip = path.join(app.getPath('temp'), `blink-ota-${Date.now()}.zip`);
    const fileStream = fs.createWriteStream(tempZip);

    function doDownload(downloadUrl) {
      https.get(downloadUrl, { headers: { 'User-Agent': 'Blink-OTA-Updater' } }, (res) => {
        if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
          return doDownload(res.headers.location);
        }
        if (res.statusCode !== 200) {
          try { fs.unlinkSync(tempZip); } catch (e) {}
          return reject(new Error(`Download failed: HTTP ${res.statusCode}`));
        }
        res.pipe(fileStream);
        fileStream.on('finish', () => {
          fileStream.close();

          const isWin = process.platform === 'win32';
          if (isWin) {
            const psCmd = `powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -LiteralPath '${tempZip}' -DestinationPath '${targetAppDir}' -Force"`;
            exec(psCmd, (err) => {
              if (!err) {
                try { fs.unlinkSync(tempZip); } catch (e) {}
                return resolve(true);
              }
              const tarCmd = `tar -xf "${tempZip}" -C "${targetAppDir}"`;
              exec(tarCmd, (err2) => {
                try { fs.unlinkSync(tempZip); } catch (e) {}
                if (err2) return reject(err2);
                resolve(true);
              });
            });
          } else {
            const cmd = `/usr/bin/unzip -o -q "${tempZip}" -d "${targetAppDir}"`;
            exec(cmd, (err) => {
              try { fs.unlinkSync(tempZip); } catch (e) {}
              if (err) return reject(err);
              resolve(true);
            });
          }
        });
      }).on('error', (err) => {
        try { fs.unlinkSync(tempZip); } catch (e) {}
        reject(err);
      });
    }

    doDownload(bundleUrl);
  });
}

async function checkForAppUpdates() {
  if (isOtaUpdating) return { inProgress: true };
  const currentVer = currentConfig.appVersion || '1.0.0';
  let manifest = null;

  for (const url of UPDATE_MANIFEST_URLS) {
    try {
      manifest = await fetchOtaJSON(url);
      if (manifest && manifest.version) break;
    } catch (e) {
      console.warn(`[AutoUpdater] Echec sur ${url}:`, e.message);
    }
  }

  if (!manifest || !manifest.version) {
    return null;
  }

  const isNewer = compareSemver(currentVer, manifest.version) > 0;
  if (!isNewer) {
    return null;
  }

  console.log(`[AutoUpdater] Nouvelle version détectée : v${manifest.version} (actuelle : v${currentVer})`);
  isOtaUpdating = true;

  try {
    let targetDir = app.getAppPath();
    if (process.platform === 'win32' && targetDir.toLowerCase().endsWith('.asar')) {
      targetDir = path.join(path.dirname(targetDir), 'app');
      if (!fs.existsSync(targetDir)) {
        try { fs.mkdirSync(targetDir, { recursive: true }); } catch (e) {}
      }
    }

    const bundleUrl = manifest.bundleUrl || manifest.fallbackBundleUrl;
    await downloadAndExtractOtaBundle(bundleUrl, targetDir);

    pendingOtaManifest = manifest;
    currentConfig.appVersion = manifest.version;
    saveConfig(currentConfig);

    console.log(`[AutoUpdater] Mise à jour v${manifest.version} appliquée silencieusement dans ${targetDir}`);
    addLog('hardware', `Mise à jour v${manifest.version} appliquée`, `Téléchargée et installée automatiquement en arrière-plan.`, 'UPDATE');

    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send('ota-update-applied', { 
        version: manifest.version,
        notes: manifest.notes || '' 
      });
      // Rechargement automatique et transparent de la fenêtre après 1.5s
      setTimeout(() => {
        if (mainWindow && !mainWindow.isDestroyed()) {
          mainWindow.reload();
        }
      }, 1500);
    }
    return manifest;
  } catch (err) {
    console.error('[AutoUpdater] Échec application bundle:', err.message);
    return null;
  } finally {
    isOtaUpdating = false;
  }
}

ipcMain.handle('check-app-updates', async () => {
  return await checkForAppUpdates();
});

ipcMain.handle('restart-to-apply-update', () => {
  app.relaunch();
  app.exit(0);
});



